/* ÉduGestion Pro — service worker : l'application démarre sans réseau. */
const CACHE = 'edugestion-v5.8.0';
const RESSOURCES = [
  './', './index.html', './verification.html', './manifest.webmanifest', './css/app.css',
  './js/schema.js', './js/db.js', './js/rules.js', './js/tableur.js', './js/seed.js',
  './js/ui.js', './js/qr.js', './js/documents.js', './js/screens.js', './js/screens2.js', './js/screens3.js', './js/screens4.js', './js/screens5.js', './js/app.js',
  './assets/entete-memp.jpg', './assets/armoiries-benin.png', './icons/favicon.ico', './icons/icon-180.png', './icons/icon-192.png',
  './icons/icon-512.png', './icons/icon-maskable-192.png', './icons/icon-maskable-512.png'
];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(RESSOURCES)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', e => {
  e.waitUntil(caches.keys()
    .then(cles => Promise.all(cles.filter(k => k !== CACHE).map(k => caches.delete(k))))
    .then(() => self.clients.claim()));
});

self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  const url = new URL(e.request.url);
  if (url.origin !== location.origin) return;
  e.respondWith(
    caches.match(e.request).then(reponse => reponse || fetch(e.request)
      .then(r => {
        const copie = r.clone();
        caches.open(CACHE).then(c => c.put(e.request, copie));
        return r;
      })
      .catch(() => caches.match('./index.html')))
  );
});
