/* ÉduGestion Pro — données de démarrage.
   Référentiels nationaux + une circonscription de démonstration.
   Tout est modifiable dans l'application : rien n'est figé dans le code. */
(function (global) {
  'use strict';
  const EG = global.EG;
  const DB = EG.DB;

  let graine = 20260828;
  function rnd() { graine = (graine * 1103515245 + 12345) % 2147483648; return graine / 2147483648; }
  function pick(a) { return a[Math.floor(rnd() * a.length)]; }
  function entre(a, b) { return a + Math.floor(rnd() * (b - a + 1)); }

  const NOMS = ['ADJOVI', 'AGBOTON', 'AHOUANSOU', 'AKPOVI', 'ALLAGBE', 'AMOUSSOU', 'ASSOGBA', 'BIO', 'DOSSOU', 'GBAGUIDI', 'HOUNKPATIN', 'KOUAGOU', 'LAWANI', 'MAMA', 'N\'TCHA', 'OROU', 'SAGBOHAN', 'SOSSOU', 'TCHAOU', 'YAROU', 'ZOSSOU', 'DEGUENON', 'HOUNSOU', 'KPADONOU'];
  const PRENOMS_M = ['Marc', 'Jean', 'Émile', 'Rodrigue', 'Bienvenu', 'Sylvain', 'Cyriaque', 'Ismaël', 'Théodore', 'Justin', 'Abdoulaye', 'Serge', 'Hervé', 'Boni'];
  const PRENOMS_F = ['Adjoua', 'Bernadette', 'Chantal', 'Delphine', 'Estelle', 'Fatima', 'Grâce', 'Huguette', 'Irène', 'Judith', 'Karimatou', 'Léontine', 'Mireille', 'Nadège'];

  const DEPARTEMENTS = ['Alibori', 'Atacora', 'Atlantique', 'Borgou', 'Collines', 'Couffo', 'Donga', 'Littoral', 'Mono', 'Ouémé', 'Plateau', 'Zou'];

  /* Les neuf matières officielles du primaire. C'est sur ce total que se calcule
     la règle des six maîtrises aux examens blancs (six sur huit si l'EPS est dispensée). */
  const MATIERES = [
    { code: 'DICT', nom: 'Dictée', cycle: 'PRIMAIRE', ordre: 1 },
    { code: 'COMM_ECR', nom: 'Communication écrite', cycle: 'PRIMAIRE', ordre: 2 },
    { code: 'COMP_ECR', nom: 'Compréhension de l\u2019écrit', cycle: 'PRIMAIRE', ordre: 3 },
    { code: 'MATH', nom: 'Mathématiques', cycle: 'PRIMAIRE', ordre: 4 },
    { code: 'ESC', nom: 'Éducation sociale', cycle: 'PRIMAIRE', ordre: 5 },
    { code: 'EST', nom: 'Éducation scientifique et technologique', cycle: 'PRIMAIRE', ordre: 6 },
    { code: 'EA_PLAST', nom: 'EA Plastique', cycle: 'PRIMAIRE', ordre: 7 },
    { code: 'EA_VIV', nom: 'EA Vivant', cycle: 'PRIMAIRE', ordre: 8 },
    { code: 'EPS', nom: 'Éducation physique et sportive', cycle: 'PRIMAIRE', ordre: 9 },
    { code: 'EVE', nom: 'Éveil et découverte du milieu', cycle: 'MATERNELLE', ordre: 10 },
    { code: 'GRAPH', nom: 'Graphisme et langage', cycle: 'MATERNELLE', ordre: 11 }
  ];

  /* Codes utilisés dans les versions précédentes : on renomme l'enregistrement
     existant plutôt que d'en créer un nouveau, pour que les notes déjà saisies
     restent rattachées à leur matière. */
  const ANCIENS_CODES = {
    FR_LAN: 'DICT', FR_EXP: 'COMM_ECR', FR_LEC: 'COMP_ECR',
    FR_ECR: 'EA_VIV', EA: 'EA_PLAST'
  };

  /**
   * Aligne le référentiel des matières sur la liste officielle, à chaque démarrage.
   * Les appareils déjà installés sont mis à jour sans perdre leurs notes.
   */
  function majMatieres() {
    return DB.all('matieres').then(existantes => {
      const parCode = {};
      existantes.forEach(m => { parCode[m.code] = m; });
      const taches = [];

      Object.keys(ANCIENS_CODES).forEach(ancien => {
        const cible = ANCIENS_CODES[ancien];
        if (parCode[ancien] && !parCode[cible]) {
          parCode[cible] = parCode[ancien];
          delete parCode[ancien];
        }
      });

      MATIERES.forEach(m => {
        const actuelle = parCode[m.code];
        if (!actuelle) {
          taches.push(DB.put('matieres', {
            code: m.code, nom: m.nom, cycle: m.cycle, ordre: m.ordre, actif: true
          }, { silencieux: true, synced: true }));
        } else if (actuelle.code !== m.code || actuelle.nom !== m.nom || actuelle.ordre !== m.ordre) {
          taches.push(DB.put('matieres', Object.assign({}, actuelle, {
            code: m.code, nom: m.nom, cycle: m.cycle, ordre: m.ordre, actif: true
          }), { silencieux: true, synced: true }));
        }
      });

      /* Les matières hors référentiel officiel sont désactivées, jamais supprimées :
         les notes des années passées doivent rester lisibles. */
      const officiels = {};
      MATIERES.forEach(m => { officiels[m.code] = true; });
      Object.keys(parCode).forEach(code => {
        if (!officiels[code] && parCode[code].actif !== false) {
          taches.push(DB.put('matieres', Object.assign({}, parCode[code], { actif: false }),
            { silencieux: true, synced: true }));
        }
      });

      return Promise.all(taches).then(() => taches.length);
    });
  }
  EG.majMatieres = majMatieres;

  function hash(txt) {
    // Empreinte locale des mots de passe. Sur appareil, sans serveur : SHA-256 si
    // le contexte est sécurisé, repli déterministe sinon.
    if (global.crypto && crypto.subtle && global.isSecureContext) {
      return crypto.subtle.digest('SHA-256', new TextEncoder().encode('egp:' + txt))
        .then(b => Array.from(new Uint8Array(b)).map(x => x.toString(16).padStart(2, '0')).join(''));
    }
    let h = 5381;
    for (let i = 0; i < txt.length; i++) h = ((h * 33) ^ txt.charCodeAt(i)) >>> 0;
    return Promise.resolve('local$' + h.toString(16));
  }
  EG.hashMotDePasse = hash;

  function seed() {
    return DB.meta('amorce_faite').then(fait => {
      if (fait) return false;
      return construire().then(() => DB.setMeta('amorce_faite', true)).then(() => true);
    });
  }

  function construire() {
    const ids = {};
    const p = [];
    const auj = new Date();
    const anneeDebut = auj.getMonth() >= 8 ? auj.getFullYear() : auj.getFullYear() - 1;
    const codeAnnee = anneeDebut + '-' + (anneeDebut + 1);

    const push = (store, obj) => DB.put(store, obj, { silencieux: true, synced: true });

    /* --- Années scolaires --- */
    return push('annees_scolaires', {
      code: (anneeDebut - 1) + '-' + anneeDebut, date_debut: (anneeDebut - 1) + '-09-14',
      date_fin: anneeDebut + '-07-10', statut: 'CLOTUREE'
    }).then(a0 => {
      ids.anneePrec = a0.id;
      return push('annees_scolaires', {
        code: codeAnnee, date_debut: anneeDebut + '-09-14', date_fin: (anneeDebut + 1) + '-07-10', statut: 'OUVERTE'
      });
    }).then(a1 => {
      ids.annee = a1.id;
      return DB.setMeta('annee_active', a1.id);
    })

    /* --- Territoires --- */
      .then(() => push('territoires', { type: 'NATIONAL', code: 'BJ', nom: 'République du Bénin', actif: true }))
      .then(nat => {
        ids.national = nat.id;
        return Promise.all(DEPARTEMENTS.map(d =>
          push('territoires', { type: 'DEPARTEMENT', code: d.slice(0, 3).toUpperCase(), nom: d, parent_id: nat.id, actif: true })
        ));
      })
      .then(deps => {
        ids.departements = deps;
        ids.atacora = deps.filter(d => d.nom === 'Atacora')[0].id;
        return Promise.all([
          push('territoires', { type: 'COMMUNE', code: 'NAT', nom: 'Natitingou', parent_id: ids.atacora, actif: true }),
          push('territoires', { type: 'CIRCONSCRIPTION', code: 'CS-NAT1', nom: 'CS Natitingou 1', parent_id: ids.atacora, actif: true }),
          push('territoires', { type: 'ZONE_PEDAGOGIQUE', code: 'ZP-NAT1A', nom: 'Zone pédagogique Natitingou 1A', parent_id: ids.atacora, actif: true }),
        push('territoires', { type: 'UNITE_PEDAGOGIQUE', code: 'UP-NAT1A1', nom: 'Unité pédagogique Natitingou 1A-1', parent_id: ids.atacora, actif: true })
        ]);
      })
      .then(t => { ids.commune = t[0].id; ids.circo = t[1].id; ids.zone = t[2].id; ids.up = t[3].id; })

    /* --- Écoles --- */
      .then(() => Promise.all([
        push('ecoles', { code_ecole: 'EP001', nom: 'EPP Natitingou Centre', cycle: 'PRIMAIRE', territoire_id: ids.circo, zone_id: ids.zone, up_id: ids.up, commune: 'Natitingou', statut: 'PUBLIQUE', adresse: 'Quartier Yimporima, Natitingou', telephone: '+229 61 00 00 01', directeur_nom: 'ADJOVI Marc', directeur_telephone: '+229 97 12 34 56', latitude: 10.3042, longitude: 1.3796, actif: true }),
        push('ecoles', { code_ecole: 'EP002', nom: 'EPP Perma', cycle: 'MIXTE', territoire_id: ids.circo, zone_id: ids.zone, commune: 'Natitingou', statut: 'PUBLIQUE', adresse: 'Perma', telephone: '+229 61 00 00 02', latitude: 9.9333, longitude: 1.4667, actif: true }),
        push('ecoles', { code_ecole: 'EM010', nom: 'École maternelle Kotopounga', cycle: 'MATERNELLE', territoire_id: ids.circo, statut: 'PUBLIQUE', adresse: 'Kotopounga', actif: true })
      ]))
      .then(ec => { ids.ecoles = ec.map(e => e.id); ids.ecole1 = ec[0].id; ids.ecole2 = ec[1].id; ids.ecoleMat = ec[2].id; })

    /* --- Matières et programmes --- */
      .then(() => Promise.all(MATIERES.map(m => push('matieres', {
        code: m.code, nom: m.nom, cycle: m.cycle, ordre: m.ordre, actif: true
      }))))
      .then(ms => {
        ids.matieres = ms;
        const prim = ms.filter(m => m.cycle === 'PRIMAIRE');
        const tasks = [];
        EG.NIVEAUX_PRIM.forEach(niv => {
          prim.forEach(m => tasks.push(push('niveau_matieres', {
            annee_scolaire_id: ids.annee, cycle: 'PRIMAIRE', niveau: niv, matiere_id: m.id,
            coefficient: (m.code === 'MATH' || m.code === 'FR_LEC') ? 2 : 1, obligatoire: true
          })));
        });
        return Promise.all(tasks);
      })

    /* --- Classes --- */
      .then(() => {
        const tasks = [];
        EG.NIVEAUX_PRIM.forEach(niv => {
          tasks.push(push('classes', { ecole_id: ids.ecole1, annee_scolaire_id: ids.annee, niveau: niv, code: niv + '-A', libelle: niv + ' A', effectif_max: 60, actif: true }));
        });
        ['EM1', 'EM2'].forEach(niv => {
          tasks.push(push('classes', { ecole_id: ids.ecoleMat, annee_scolaire_id: ids.annee, niveau: niv, code: niv, libelle: niv, effectif_max: 40, actif: true }));
        });
        return Promise.all(tasks);
      })
      .then(cl => { ids.classes = cl; })

    /* --- Comptes utilisateurs --- */
      .then(() => {
        const comptes = [
          { identifiant: 'admin', nom: 'ADMIN', prenoms: 'MEMP', role: 'ADMIN_MEMP', mdp: 'admin123', territoire_id: ids.national },
          { identifiant: 'ddemp.atacora', nom: 'KOUAGOU', prenoms: 'Théodore', role: 'DDEMP', mdp: 'demo123', territoire_id: ids.atacora },
          { identifiant: 'cs.natitingou', nom: 'N\'TCHA', prenoms: 'Bienvenu', role: 'CS', mdp: 'demo123', territoire_id: ids.circo },
          { identifiant: 'cp.zone1a', nom: 'YAROU', prenoms: 'Judith', role: 'CP', mdp: 'demo123', territoire_id: ids.zone },
          { identifiant: 'dir.ep001', nom: 'ADJOVI', prenoms: 'Marc', role: 'DIRECTEUR', mdp: 'demo123', ecole_id: ids.ecole1 },
          { identifiant: 'ens.cm2', nom: 'SOSSOU', prenoms: 'Estelle', role: 'ENSEIGNANT', mdp: 'demo123', ecole_id: ids.ecole1 },
          { identifiant: 'parent.demo', nom: 'GBAGUIDI', prenoms: 'Chantal', role: 'PARENT', mdp: 'demo123' }
        ];
        return Promise.all(comptes.map(c =>
          hash(c.mdp).then(h => push('users', {
            identifiant: c.identifiant, password_hash: h, nom: c.nom, prenoms: c.prenoms,
            role: c.role, ecole_id: c.ecole_id || null, territoire_id: c.territoire_id || null,
            telephone: '+229 9' + entre(1000000, 9999999), actif: true
          }))
        ));
      })
      .then(us => { ids.users = us; ids.userParent = us.filter(u => u.role === 'PARENT')[0]; })

    /* --- Personnel --- */
      .then(() => {
        const agents = [];
        const cats = ['A1', 'A2', 'A3', 'B1', 'C1'];
        for (let i = 0; i < 14; i++) {
          const sexe = rnd() > 0.5 ? 'M' : 'F';
          const cat = i < 3 ? 'C1' : (i < 6 ? 'B1' : pick(cats));
          const naissance = new Date(entre(1966, 1996), entre(0, 11), entre(1, 28));
          agents.push({
            matricule: 'MAT' + (100200 + i),
            nip: String(entre(100000000, 999999999)),
            adresse: pick(['Quartier Yimporima', 'Quartier Tchirimina', 'Perma centre']) + ', Natitingou',
            situation_familiale: pick(['CELIBATAIRE', 'MARIE', 'MARIE', 'VEUF']),
            situation_militaire: 'Dégagé des obligations',
            diplome_recrutement: pick(['BEPC + CEAP', 'BAC + CAP', 'Licence + CAP']),
            diplome_plus_eleve: pick(['CEAP', 'CAP', 'Licence']),
            grade: 'Instituteur', echelle: pick(['B1', 'C1', 'A3']),
            emploi: 'Enseignant du primaire', qualite: 'Titulaire',
            contrat_initial: 'Contrat n° ' + entre(100, 999) + '/MEMP/DAF',
            nom: pick(NOMS), prenoms: sexe === 'M' ? pick(PRENOMS_M) : pick(PRENOMS_F),
            sexe, date_naissance: naissance.toISOString().slice(0, 10),
            lieu_naissance: pick(['Natitingou', 'Perma', 'Kotopounga', 'Tanguiéta']),
            telephone: '+229 9' + entre(1000000, 9999999),
            ecole_id: i < 9 ? ids.ecole1 : (i < 12 ? ids.ecole2 : ids.ecoleMat),
            fonction: i === 0 ? 'DIRECTEUR' : 'ENSEIGNANT',
            categorie: cat, echelon: entre(1, 12),
            date_premiere_prise_service: (naissance.getFullYear() + 24) + '-10-01',
            ph: false, actif: true
          });
        }
        return Promise.all(agents.map(a => push('personnels', a)));
      })
      .then(ps => {
        ids.personnels = ps;
        /* Chaque classe reçoit un titulaire : c'est son nom qui figurera au
           pied des documents de son cours. */
        const parEcole = {};
        ps.filter(x => x.fonction === 'ENSEIGNANT').forEach(x => {
          (parEcole[x.ecole_id] = parEcole[x.ecole_id] || []).push(x);
        });
        const pris = {};
        return Promise.all(ids.classes.map(c => {
          const dispo = (parEcole[c.ecole_id] || []).filter(x => !pris[x.id]);
          if (!dispo.length) return Promise.resolve(c);
          pris[dispo[0].id] = true;
          return push('classes', Object.assign({}, c, { titulaire_id: dispo[0].id }));
        }))
          .then(maj => { ids.classes = maj; return ps; });
      })
      .then(ps => {
        return Promise.all(ps.slice(0, 6).map(a => push('carrieres_personnel', {
          personnel_id: a.id, statut_code: 'APE', categorie: a.categorie, echelon: a.echelon,
          grade: 'Instituteur', date_effet: (new Date().getFullYear() - 2) + '-01-01',
          reference_acte: 'Arrêté n°' + entre(100, 999) + '/MEMP/DRH'
        })));
      })

    /* --- Règles de retraite --- */
      .then(() => Promise.all([
        push('regles_retraite', { categorie: 'C1', echelon_min: 1, echelon_max: 12, age_retraite: 55, date_effet: '2025-01-01', actif: true, reference_reglementaire: 'Statut général de la fonction publique' }),
        push('regles_retraite', { categorie: 'B1', echelon_min: 1, echelon_max: 12, age_retraite: 58, date_effet: '2025-01-01', actif: true }),
        push('regles_retraite', { categorie: 'A1', echelon_min: 1, echelon_max: 12, age_retraite: 60, date_effet: '2025-01-01', actif: true }),
        push('regles_retraite', { categorie: 'A2', echelon_min: 1, echelon_max: 12, age_retraite: 60, date_effet: '2025-01-01', actif: true }),
        push('regles_retraite', { categorie: 'A3', echelon_min: 1, echelon_max: 12, age_retraite: 60, date_effet: '2025-01-01', actif: true })
      ]))

    /* --- Élèves et inscriptions --- */
      .then(() => {
        const eleves = [];
        EG.NIVEAUX_PRIM.forEach((niv, idx) => {
          const n = niv === 'CM2' ? 22 : 16;
          for (let i = 0; i < n; i++) {
            const sexe = rnd() > 0.48 ? 'M' : 'F';
            const ageCible = 6 + idx + (rnd() > 0.8 ? 1 : 0);
            const an = new Date().getFullYear() - ageCible;
            eleves.push({
              niveau: niv,
              rec: {
                nom: pick(NOMS), prenoms: sexe === 'M' ? pick(PRENOMS_M) : pick(PRENOMS_F),
                sexe, date_naissance: an + '-' + String(entre(1, 12)).padStart(2, '0') + '-' + String(entre(1, 28)).padStart(2, '0'),
                date_naissance_precision: rnd() > 0.85 ? 'APPROXIMATIVE' : 'EXACTE',
                lieu_naissance: pick(['Natitingou', 'Perma', 'Kouandé', 'Tanguiéta', 'Boukoumbé']),
                acte_naissance: rnd() > 0.2, nationalite: 'Béninoise',
                npi: rnd() > 0.35 ? String(entre(100000000, 999999999)) : null,
                matricule_ecole: String(entre(1000, 9999)),
                nom_pere: pick(NOMS) + ' ' + pick(PRENOMS_M),
                nom_mere: pick(NOMS) + ' ' + pick(PRENOMS_F),
                commune_naissance: pick(['Natitingou', 'Kouandé', 'Toucountouna', 'Boukoumbé']),
                educmaster_matricule: rnd() > 0.4 ? 'EM' + entre(1000000, 9999999) : null,
                educmaster_statut: rnd() > 0.4 ? 'SYNCHRONISE' : 'NON_SYNCHRONISE',
                statut_identite: 'ACTIF'
              }
            });
          }
        });
        return Promise.all(eleves.map(e => push('eleves', e.rec).then(r => ({ niveau: e.niveau, eleve: r }))));
      })
      .then(list => {
        ids.eleves = list;
        const tasks = list.map(x => {
          const cl = ids.classes.filter(c => c.niveau === x.niveau && c.ecole_id === ids.ecole1)[0];
          return push('inscriptions_eleves', {
            eleve_id: x.eleve.id, ecole_id: ids.ecole1, annee_scolaire_id: ids.annee,
            cycle: 'PRIMAIRE', niveau: x.niveau, classe_id: cl ? cl.id : null,
            type_inscription: rnd() > 0.7 ? 'NOUVELLE' : 'REINSCRIPTION',
            redoublant: rnd() > 0.86, a_suivi_maternelle: rnd() > 0.5,
            date_inscription: new Date().getFullYear() + '-09-16',
            statut: 'ACTIF', principale: true
          }).then(ins => ({ ins, eleve: x.eleve, niveau: x.niveau }));
        });
        return Promise.all(tasks);
      })
      .then(insc => { ids.inscriptions = insc; })

    /* --- Handicaps déclarés --- */
      .then(() => Promise.all(ids.inscriptions.slice(0, 3).map((x, i) => push('eleve_handicaps', {
        eleve_id: x.eleve.id, type: ['VISUEL', 'MOTEUR', 'AUDITIF'][i],
        amenagements: 'Place au premier rang, supports adaptés', actif: true
      }))))

    /* --- Évaluations et notes (3 premières évaluations) --- */
      .then(() => {
        const tasks = [];
        EG.NIVEAUX_PRIM.forEach(niv => {
          for (let num = 1; num <= 3; num++) {
            tasks.push(push('evaluations', {
              annee_scolaire_id: ids.annee, ecole_id: ids.ecole1, niveau: niv,
              classe_id: (ids.classes.filter(c => c.niveau === niv && c.ecole_id === ids.ecole1)[0] || {}).id,
              numero: num, mois: [10, 11, 12][num - 1], libelle: 'Évaluation ' + num,
              statut: num < 3 ? 'VALIDEE' : 'OUVERTE'
            }));
          }
        });
        return Promise.all(tasks);
      })
      .then(evals => {
        ids.evaluations = evals;
        const matPrim = ids.matieres.filter(m => m.cycle === 'PRIMAIRE');
        const notes = [];
        evals.forEach(ev => {
          const insc = ids.inscriptions.filter(i => i.niveau === ev.niveau);
          insc.forEach(i => {
            matPrim.forEach(m => {
              const base = 6 + rnd() * 12;
              notes.push({
                evaluation_id: ev.id, inscription_id: i.ins.id, matiere_id: m.id,
                note: Math.round(base * 4) / 4, statut_special: null
              });
            });
          });
        });
        return DB.putBatch('notes', notes, { silencieux: true });
      })

    /* --- Présences des 15 derniers jours ouvrables --- */
      .then(() => {
        const lignes = [];
        /* Les quinze derniers jours ouvrables, jour courant compris : à
           l'ouverture, l'application montre la situation du jour même. */
        const jours = [];
        const d = new Date();
        while (jours.length < 15) {
          const j = d.getDay();
          if (j !== 0 && j !== 6) jours.push(d.toISOString().slice(0, 10));
          d.setDate(d.getDate() - 1);
        }
        ids.inscriptions.forEach(i => {
          jours.forEach(j => {
            const r = rnd();
            lignes.push({
              inscription_id: i.ins.id, date_presence: j, periode: 'JOURNEE',
              statut: r > 0.92 ? 'ABSENT' : (r > 0.88 ? 'RETARD' : 'PRESENT'),
              justifie: r > 0.96
            });
          });
        });
        return DB.putBatch('presences', lignes, { silencieux: true });
      })

    /* --- Repas de cantine des trois dernières semaines --- */
      .then(() => {
        const lignes = [];
        /* Les quinze derniers jours ouvrables, jour courant compris : à
           l'ouverture, l'application montre la situation du jour même. */
        const jours = [];
        const d = new Date();
        while (jours.length < 15) {
          const j = d.getDay();
          if (j !== 0 && j !== 6) jours.push(d.toISOString().slice(0, 10));
          d.setDate(d.getDate() - 1);
        }
        ids.inscriptions.forEach(i => {
          jours.forEach(j => {
            const present = rnd() > 0.14;
            lignes.push({
              inscription_id: i.ins.id, date_repas: j, a_mange: present,
              montant: present ? 100 : 0,
              paye: present && rnd() > 0.35,
              date_paiement: null
            });
          });
        });
        return DB.putBatch('participations_cantine', lignes, { silencieux: true });
      })

    /* --- Examen blanc et résultats CEP du CM2 --- */
      .then(() => push('examens_blancs', {
        annee_scolaire_id: ids.annee, ecole_id: ids.ecole1, niveau: 'CM2', numero: 1,
        date_examen: (new Date().getFullYear()) + '-02-12', statut: 'VALIDE'
      }))
      .then(ex => {
        ids.examenBlanc = ex;
        const cm2 = ids.inscriptions.filter(i => i.niveau === 'CM2');
        const matPrim = ids.matieres.filter(m => m.cycle === 'PRIMAIRE');
        const lignes = [];
        cm2.forEach(i => matPrim.forEach(m => lignes.push({
          examen_id: ex.id, inscription_id: i.ins.id, matiere_id: m.id,
          note: Math.round((5 + rnd() * 13) * 4) / 4, dispense: false
        })));
        return DB.putBatch('notes_examens_blancs', lignes, { silencieux: true });
      })
      .then(() => {
        const cm2 = ids.inscriptions.filter(i => i.niveau === 'CM2');
        return Promise.all(cm2.map(i => push('resultats_cep', {
          inscription_id: i.ins.id, numero_table: 'T' + entre(10000, 99999),
          inscrit: true, a_compose: false, admis: null, statut: 'BROUILLON'
        })));
      })

    /* --- Patrimoine, services, budget --- */
      .then(() => {
        const tasks = [];
        for (let i = 1; i <= 8; i++) {
          tasks.push(push('infrastructures', {
            ecole_id: ids.ecole1, code_local: 'L' + String(i).padStart(2, '0'),
            type_local: i <= 6 ? 'SALLE_CLASSE' : (i === 7 ? 'BUREAU' : 'LATRINES'),
            designation: i <= 6 ? ('Salle de classe ' + i) : (i === 7 ? 'Bureau du directeur' : 'Bloc de latrines'),
            annee_mise_service: entre(1985, 2022), superficie_m2: entre(40, 60), utilise: true,
            nature_murs: pick(['DUR', 'SEMI_DUR', 'BANCO']), etat_murs: pick(['BON', 'PASSABLE', 'MAUVAIS']),
            nature_toit: 'TOLE', etat_toit: pick(['BON', 'PASSABLE', 'MAUVAIS']),
            etat_portes: pick(['BON', 'PASSABLE']), etat_fenetres: pick(['BON', 'PASSABLE', 'MAUVAIS']),
            financeur: pick(['État', 'PDDSE', 'Commune', 'ONG'])
          }));
        }
        return Promise.all(tasks);
      })
      .then(() => Promise.all(EG.NIVEAUX_PRIM.map(niv => push('inventaires_mobilier', {
        ecole_id: ids.ecole1, annee_scolaire_id: ids.annee, type_mobilier: 'TABLE_BANC',
        niveau: niv, quantite: entre(14, 26), bon_etat: entre(8, 20), a_reparer: entre(0, 5),
        hors_service: entre(0, 4), adapte: false, confirme: true
      }))))
      .then(() => push('services_ecole', {
        ecole_id: ids.ecole1, annee_scolaire_id: ids.annee, eau_potable: true, eau_forage: true,
        electricite: true, solaire: false, cantine: true, latrines: true, nb_blocs_latrines: 2,
        nb_cabines_latrines: 6, latrines_separees_fg: true, latrines_handicap: false, lavage_mains: true
      }))
      .then(() => push('cantines', {
        ecole_id: ids.ecole1, annee_scolaire_id: ids.annee, fonctionnelle: true,
        organisme_soutien: 'PNASI', tarif_repas: 100, equipement_cuisine: true, magasin_vivres_bon_etat: true,
        responsable: 'Comité de gestion de la cantine'
      }))
      .then(() => push('budgets_ecoles', {
        ecole_id: ids.ecole1, annee_scolaire_id: ids.annee,
        budget_execute_precedent: 2450000, solde_exercice_anterieur: 180000,
        subvention_etat: 1900000, cotisation_parents: 640000, autres_ressources: 120000,
        statut: 'SOUMIS'
      }))
      .then(b => Promise.all([
        push('mouvements_budget', { budget_id: b.id, type: 'SUBVENTION_ETAT', libelle: 'Subvention 1er trimestre', montant: 950000, date_operation: new Date().getFullYear() + '-10-15', categorie: 'Ressources' }),
        push('mouvements_budget', { budget_id: b.id, type: 'DEPENSE', libelle: 'Achat de craie et registres', montant: 148000, date_operation: new Date().getFullYear() + '-10-22', categorie: 'Fonctionnement' }),
        push('mouvements_budget', { budget_id: b.id, type: 'DEPENSE', libelle: 'Réparation de tables-bancs', montant: 260000, date_operation: new Date().getFullYear() + '-11-05', categorie: 'Entretien' })
      ]))
      .then(() => push('gestion_participative', {
        ecole_id: ids.ecole1, annee_scolaire_id: ids.annee, ape_existe: true, ape_fonctionnel: true,
        ame_existe: true, comite_direction: true, conseil_maitres: true, comite_sante: false,
        nombre_reunions_ape: 3, nombre_ag: 2, projet_ecole_verte: true
      }))

    /* --- Recensement --- */
      .then(() => push('campagnes_recensement', {
        annee_scolaire_id: ids.annee, type: 'PRIMAIRE',
        date_reference_age: new Date().getFullYear() + '-12-31',
        date_ouverture: new Date().getFullYear() + '-10-01',
        date_cloture: new Date().getFullYear() + '-11-30',
        version_formulaire: 'MEMP-2026-P8', statut: 'OUVERTE'
      }))
      .then(c => {
        ids.campagne = c;
        return Promise.all(ids.ecoles.map(e => push('recensements_ecoles', {
          campagne_id: c.id, ecole_id: e, statut: 'A_COMPLETER', taux_completion: 0
        })));
      })

    /* --- Référentiels d'alertes, documents, modèle de risque --- */
      .then(() => Promise.all([
        push('types_alertes', { code: 'ABSENTEISME_ELEVE', categorie: 'Scolarité', libelle: 'Absentéisme élevé', severite_defaut: 'ELEVEE', actif: true }),
        push('types_alertes', { code: 'EFFECTIF_PLETHORIQUE', categorie: 'Structure', libelle: 'Effectif de classe pléthorique', severite_defaut: 'MOYENNE', actif: true }),
        push('types_alertes', { code: 'LOCAL_DEGRADE', categorie: 'Patrimoine', libelle: 'Local en mauvais état', severite_defaut: 'ELEVEE', actif: true }),
        push('types_alertes', { code: 'RETRAITE_PROCHE', categorie: 'Personnel', libelle: 'Départ à la retraite dans moins d\'un an', severite_defaut: 'MOYENNE', actif: true }),
        push('types_alertes', { code: 'RECENSEMENT_RETARD', categorie: 'Recensement', libelle: 'Recensement non transmis', severite_defaut: 'ELEVEE', actif: true }),
        push('types_alertes', { code: 'DEFICIT_MOBILIER', categorie: 'Patrimoine', libelle: 'Déficit de places assises', severite_defaut: 'MOYENNE', actif: true })
      ]))
      .then(() => Promise.all([
        push('types_documents', { code: 'BULLETIN', nom: 'Bulletin de notes', categorie: 'Scolarité', signature_requise: true, verification_qr: true }),
        push('types_documents', { code: 'CERT_SCOLARITE', nom: 'Certificat de scolarité', categorie: 'Scolarité', signature_requise: true, verification_qr: true }),
        push('types_documents', { code: 'LISTE_CLASSE', nom: 'Liste de classe', categorie: 'Scolarité', signature_requise: false, verification_qr: false }),
        push('types_documents', { code: 'FICHE_RECENSEMENT', nom: 'Fiche de recensement', categorie: 'Recensement', signature_requise: true, verification_qr: true }),
        push('types_documents', { code: 'PV_VISITE', nom: 'Procès-verbal de visite', categorie: 'Pédagogie', signature_requise: true, verification_qr: false }),
        push('types_documents', { code: 'ETAT_BUDGET', nom: 'État d\'exécution budgétaire', categorie: 'Finances', signature_requise: true, verification_qr: true }),
        push('types_documents', { code: 'CARTE_SCOLAIRE', nom: 'Carte d\'identité scolaire', categorie: 'Scolarité', signature_requise: false, verification_qr: true }),
        push('types_documents', { code: 'FICHE_CEP', nom: 'Fiche d\'inscription au CEP', categorie: 'Examens', signature_requise: true, verification_qr: true }),
        push('types_documents', { code: 'LISTE_PAIEMENT', nom: 'Liste de paiement de la cantine', categorie: 'Finances', signature_requise: true, verification_qr: true }),
        push('types_documents', { code: 'BILAN_PRESENCE', nom: 'Bilan de présence par cours', categorie: 'Scolarité', signature_requise: true, verification_qr: true }),
        push('types_documents', { code: 'AFFICHAGE_CLASSE', nom: 'Tableau d\'affichage de classe', categorie: 'Scolarité', signature_requise: false, verification_qr: true }),
        push('types_documents', { code: 'SYNTHESE_EVAL', nom: 'Synthèse d\'évaluation', categorie: 'Pédagogie', signature_requise: true, verification_qr: true }),
        push('types_documents', { code: 'RELEVE_CENTRE', nom: 'Relevé de centre d\'examen blanc', categorie: 'Examens', signature_requise: true, verification_qr: true }),
        push('types_documents', { code: 'RELEVE_PERSONNEL', nom: 'Relevé de présence du personnel', categorie: 'Personnel', signature_requise: true, verification_qr: true }),
        push('types_documents', { code: 'FICHE_EVAL_AGENT', nom: 'Fiche d\'évaluation de l\'agent', categorie: 'Personnel', signature_requise: true, verification_qr: true })
      ]))
      .then(() => push('modeles_risque', {
        code: 'DECROCHAGE', version: '1.0', actif: true,
        configuration: { absenteisme: 40, resultats: 25, redoublement: 15, retards: 10, cantine: 10 },
        date_activation: new Date().toISOString().slice(0, 10)
      }))
      .then(() => Promise.all([
        push('definitions_indicateurs', { code: 'TBS', nom: 'Taux brut de scolarisation', description: 'Effectif total scolarisé rapporté à la population d\'âge officiel.', formule: 'effectif / population × 100', unite: '%' }),
        push('definitions_indicateurs', { code: 'RATIO_ELEVES_MAITRE', nom: 'Ratio élèves-maître', description: 'Nombre d\'élèves par enseignant en poste.', formule: 'élèves / enseignants', unite: 'élèves' }),
        push('definitions_indicateurs', { code: 'TAUX_REUSSITE_CEP', nom: 'Taux de réussite au CEP', description: 'Admis rapportés aux candidats ayant composé.', formule: 'admis / composants × 100', unite: '%' }),
        push('definitions_indicateurs', { code: 'PARITE', nom: 'Indice de parité filles/garçons', description: 'Effectif des filles rapporté à celui des garçons.', formule: 'filles / garçons', unite: 'ratio' })
      ]))

    /* --- Portail parents --- */
      .then(() => push('profils_parents', {
        nom: 'GBAGUIDI', prenoms: 'Chantal', telephone: '+229 97 45 12 08',
        telephone_verifie: true, user_id: ids.userParent.id, actif: true
      }))
      .then(par => {
        ids.parent = par;
        const enfants = ids.inscriptions.filter(i => i.niveau === 'CM2').slice(0, 2)
          .concat(ids.inscriptions.filter(i => i.niveau === 'CE1').slice(0, 1));
        return Promise.all(enfants.map(e => push('liens_parent_enfant', {
          parent_id: par.id, eleve_id: e.eleve.id, relation: 'MERE',
          statut: 'VALIDE', methode_validation: 'Validation par le directeur'
        })));
      })
      .then(() => push('communications_ecole', {
        ecole_id: ids.ecole1, titre: 'Réunion de rentrée des parents',
        contenu: 'La réunion de rentrée se tient samedi à 9 h dans la cour de l\'école. Ordre du jour : résultats de l\'année écoulée, budget, cantine.',
        audience: 'TOUS_PARENTS', date_publication: new Date().toISOString().slice(0, 10), statut: 'PUBLIEE'
      }))

    /* --- Modèles de rapports --- */
      .then(() => Promise.all([
        push('modeles_rapports', { code: 'EFFECTIFS_NIVEAU', nom: 'Effectifs par niveau et par sexe', type: 'OFFICIEL', description: 'Répartition des élèves inscrits, par niveau et par sexe.', actif: true }),
        push('modeles_rapports', { code: 'ASSIDUITE', nom: 'Assiduité par classe', type: 'OFFICIEL', description: 'Taux de présence sur une période donnée.', actif: true }),
        push('modeles_rapports', { code: 'RESULTATS_EVAL', nom: 'Résultats par évaluation', type: 'OFFICIEL', description: 'Moyennes, maîtrises et rangs.', actif: true }),
        push('modeles_rapports', { code: 'PATRIMOINE', nom: 'État du patrimoine', type: 'OFFICIEL', description: 'Locaux, mobilier et services.', actif: true }),
        push('modeles_rapports', { code: 'RETRAITES_5ANS', nom: 'Départs à la retraite à 5 ans', type: 'OFFICIEL', description: 'Prévisions par école et catégorie.', actif: true })
      ]))
      .then(() => DB.audit('AMORCE', 'systeme', null, { message: 'Jeu de données initial installé' }));
  }

  EG.seed = seed;
})(window);
