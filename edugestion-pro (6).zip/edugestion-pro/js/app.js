/* ÉduGestion Pro — démarrage, session, droits et navigation. */
(function (global) {
  'use strict';
  const EG = global.EG, DB = EG.DB, U = EG.UI;
  const el = U.el, Routeur = U.Routeur;

  EG.session = null;

  /* ---------------- Droits ---------------- */
  const DROITS = {
    ADMIN_MEMP: { ecrire: true, modules: '*' },
    ADMIN_TECHNIQUE: { ecrire: true, modules: '*' },
    DDEMP: { ecrire: true, modules: '*', sauf: ['securite'] },
    CS: { ecrire: true, modules: '*', sauf: ['securite'] },
    CP: {
      ecrire: true, modules: ['eleves', 'inscriptions', 'presences', 'evaluations', 'cep', 'personnel',
        'visites', 'risques', 'alertes', 'analytics', 'rapports', 'documents', 'recensement']
    },
    DIRECTEUR: {
      ecrire: true, modules: '*', sauf: ['securite', 'support']
    },
    ENSEIGNANT: {
      ecrire: true, modules: ['eleves', 'inscriptions', 'presences', 'evaluations', 'cep', 'cantine',
        'risques', 'documents', 'parents', 'educmaster']
    },
    PARENT: { ecrire: false, modules: ['parents'] }
  };

  EG.peutEcrire = function () {
    const d = DROITS[EG.session.user.role];
    return !!(d && d.ecrire);
  };
  EG.peutVoirModule = function (code) {
    const d = DROITS[EG.session.user.role];
    if (!d) return false;
    if (d.sauf && d.sauf.indexOf(code) >= 0) return false;
    return d.modules === '*' || d.modules.indexOf(code) >= 0;
  };

  /* ---------------- Navigation ---------------- */
  const NAV = {
    ENSEIGNANT: [
      ['accueil', '🏠', 'Accueil'], ['presences', '✅', 'Présences'],
      ['evaluations', '📝', 'Notes'], ['cantine', '🍚', 'Cantine'], ['modules', '☰', 'Plus']
    ],
    DIRECTEUR: [
      ['accueil', '🏠', 'Accueil'], ['eleves', '🎒', 'Élèves'],
      ['patrimoine', '🏫', 'École'], ['alertes', '🔔', 'Alertes'], ['modules', '☰', 'Plus']
    ],
    PARENT: [
      ['accueil', '🏠', 'Accueil'], ['parents', '👧', 'Mes enfants']
    ],
    DEFAUT: [
      ['accueil', '🏠', 'Accueil'], ['analytics', '📊', 'Statistiques'],
      ['alertes', '🔔', 'Alertes'], ['recensement', '🧮', 'Recensement'], ['modules', '☰', 'Plus']
    ]
  };

  /* ---------------- Authentification ---------------- */
  function ecranConnexion() {
    document.body.className = 'connexion';
    const racine = document.getElementById('app');
    racine.textContent = '';

    const identifiant = el('input', { type: 'text', id: 'id', autocomplete: 'username', required: true, placeholder: 'dir.ep001' });
    const motdepasse = el('input', { type: 'password', id: 'mdp', autocomplete: 'current-password', required: true });
    const erreur = el('p', { class: 'erreur-connexion' });

    function tenter() {
      erreur.textContent = '';
      const ident = identifiant.value.trim();
      if (!ident || !motdepasse.value) { erreur.textContent = 'Saisissez votre identifiant et votre mot de passe.'; return; }
      DB.where('users', u => u.identifiant === ident && u.actif !== false).then(users => {
        if (!users.length) { erreur.textContent = 'Identifiant inconnu.'; return; }
        const u = users[0];
        return EG.hashMotDePasse(motdepasse.value).then(h => {
          if (h !== u.password_hash) { erreur.textContent = 'Mot de passe incorrect.'; return; }
          return ouvrirSession(u);
        });
      });
    }

    const form = el('form', {
      class: 'carte-connexion', onsubmit: e => { e.preventDefault(); tenter(); }
    }, [
      el('div', { class: 'marque' }, [
        el('span', { class: 'marque-drapeau', 'aria-hidden': 'true' }),
        el('div', {}, [
          el('h1', { text: 'ÉduGestion Pro' }),
          el('p', { text: 'Gestion des écoles maternelles et primaires — Bénin' })
        ])
      ]),
      el('div', { class: 'champ' }, [el('label', { for: 'id', text: 'Identifiant' }), identifiant]),
      el('div', { class: 'champ' }, [el('label', { for: 'mdp', text: 'Mot de passe' }), motdepasse]),
      erreur,
      el('button', { class: 'btn btn-primaire pleine', type: 'submit', text: 'Se connecter' }),
      el('details', { class: 'comptes' }, [
        el('summary', { text: 'Comptes de démonstration' }),
        el('ul', {}, [
          ['dir.ep001', 'demo123', 'Directeur d’école'],
          ['ens.cm2', 'demo123', 'Enseignant de CM2'],
          ['cs.natitingou', 'demo123', 'Circonscription scolaire'],
          ['ddemp.atacora', 'demo123', 'Direction départementale'],
          ['parent.demo', 'demo123', 'Parent d’élève'],
          ['admin', 'admin123', 'Administrateur MEMP']
        ].map(([i, m, r]) => el('li', {}, el('button', {
          type: 'button', class: 'lien-compte',
          onclick: () => { identifiant.value = i; motdepasse.value = m; tenter(); }
        }, [el('strong', { text: r }), el('span', { class: 'muet petit', text: ' — ' + i })]))))
      ])
    ]);

    racine.appendChild(el('div', { class: 'ecran-connexion' }, form));
    identifiant.focus();
  }

  function ouvrirSession(user) {
    return Promise.all([
      user.ecole_id ? DB.get('ecoles', user.ecole_id) : Promise.resolve(null),
      DB.meta('annee_active').then(id => id ? DB.get('annees_scolaires', id) : null)
    ]).then(([ecole, annee]) => {
      if (!annee) {
        return DB.where('annees_scolaires', { statut: 'OUVERTE' }).then(a => {
          annee = a[0];
          return annee ? DB.setMeta('annee_active', annee.id) : null;
        }).then(() => finaliser(user, ecole, annee));
      }
      return finaliser(user, ecole, annee);
    });
  }

  function finaliser(user, ecole, annee) {
    EG.session = {
      user,
      ecole_id: ecole ? ecole.id : null,
      ecole_nom: ecole ? ecole.nom : 'Toutes les écoles',
      annee_id: annee ? annee.id : null,
      annee_code: annee ? annee.code : '—'
    };
    return DB.setMeta('session_utilisateur', user.id)
      .then(() => DB.audit('CONNEXION', 'users', user.id))
      .then(() => { construireCoquille(); Routeur.aller('accueil'); });
  }

  function deconnecter() {
    DB.setMeta('session_utilisateur', null).then(() => {
      EG.session = null;
      ecranConnexion();
    });
  }

  /* ---------------- Coquille applicative ---------------- */
  function construireCoquille() {
    document.body.className = 'connecte';
    const racine = document.getElementById('app');
    racine.textContent = '';

    const indicateur = el('button', {
      class: 'synchro', id: 'indicateur-synchro', onclick: () => Routeur.aller('sync'),
      'aria-label': 'État de la synchronisation'
    });

    const barre = el('header', { class: 'barre-haut' }, [
      el('button', {
        class: 'marque-mini', onclick: () => Routeur.aller('accueil'), 'aria-label': 'Accueil'
      }, [el('span', { class: 'marque-drapeau petit-drapeau', 'aria-hidden': 'true' }), el('span', { text: 'ÉduGestion Pro' })]),
      el('div', { class: 'barre-droite' }, [
        indicateur,
        el('button', {
          class: 'icone-btn', 'aria-label': 'Compte et déconnexion', text: '⋯',
          onclick: menuCompte
        })
      ])
    ]);

    const contenu = el('main', { id: 'contenu', tabindex: '-1' });

    const items = NAV[EG.session.user.role] || NAV.DEFAUT;
    const nav = el('nav', { class: 'barre-onglets', 'aria-label': 'Navigation principale' },
      items.map(([route, icone, libelle]) => el('button', {
        class: 'onglet', dataset: { route: route.split('/')[0] }, onclick: () => Routeur.aller(route)
      }, [el('span', { class: 'onglet-icone', text: icone, 'aria-hidden': 'true' }), el('span', { text: libelle })])));

    racine.appendChild(barre);
    racine.appendChild(contenu);
    racine.appendChild(nav);
    EG.majSynchro();
  }

  function menuCompte() {
    const u = EG.session.user;
    U.modal('Mon compte', el('div', {}, [
      el('p', {}, [el('strong', { text: (u.prenoms || '') + ' ' + u.nom }), el('br'), document.createTextNode(U.libelle(u.role))]),
      el('p', { class: 'muet', text: EG.session.ecole_nom + ' • année ' + EG.session.annee_code }),
      el('p', { class: 'muet petit', text: 'ÉduGestion Pro V5.2 — fonctionne hors ligne, les données restent sur cet appareil jusqu’à la synchronisation.' }),
      el('p', { class: 'muet petit', text: u.signature_image ? 'Signature enregistrée : elle est apposée sur les documents que vous éditez.' : 'Aucune signature enregistrée : vos documents porteront un emplacement à signer à la main.' }),
      el('div', { class: 'barre-actions' }, [
        el('button', {
          class: 'btn btn-fantome', text: u.signature_image ? 'Modifier ma signature' : 'Enregistrer ma signature',
          onclick: () => { document.querySelector('.modal-fond').remove(); EG.Docs.capturerSignature(u, null, { table: 'users' }); }
        }),
        el('button', { class: 'btn btn-fantome', text: 'Synchronisation', onclick: () => { document.querySelector('.modal-fond').remove(); Routeur.aller('sync'); } }),
        el('button', { class: 'btn btn-fantome', text: 'Tous les modules', onclick: () => { document.querySelector('.modal-fond').remove(); Routeur.aller('modules'); } })
      ])
    ]), fermer => [
      el('button', { class: 'btn btn-fantome', text: 'Fermer', onclick: fermer }),
      el('button', { class: 'btn btn-danger', text: 'Se déconnecter', onclick: () => { fermer(); deconnecter(); } })
    ]);
  }

  EG.majSynchro = function () {
    const n = document.getElementById('indicateur-synchro');
    if (!n) return;
    DB.outboxCount().then(c => {
      if (!navigator.onLine) { n.className = 'synchro hors-ligne'; n.textContent = '⚡ Hors ligne' + (c ? ' · ' + c : ''); }
      else if (c) { n.className = 'synchro attente'; n.textContent = '☁ ' + c + ' en attente'; }
      else { n.className = 'synchro ok'; n.textContent = '✓ À jour'; }
    });
  };

  /* ---------------- Rendu des routes ---------------- */
  function rendre() {
    if (!EG.session) return;
    const { vue, args, params } = Routeur.lire();
    const contenu = document.getElementById('contenu');
    if (!contenu) return;
    contenu.textContent = '';
    contenu.scrollTop = 0;

    Array.prototype.forEach.call(document.querySelectorAll('.onglet'), o => {
      o.classList.toggle('actif', o.dataset.route === vue);
    });

    const rendu = Routeur.routes[vue];
    if (!rendu) { contenu.appendChild(U.vide('Cette page n’existe pas.')); return; }
    try {
      rendu(contenu, args, params);
    } catch (e) {
      contenu.appendChild(U.vide('Une erreur est survenue : ' + e.message));
      console.error(e);
    }
    contenu.focus({ preventScroll: true });
  }

  window.addEventListener('hashchange', rendre);
  window.addEventListener('online', EG.majSynchro);
  window.addEventListener('offline', EG.majSynchro);

  /* ---------------- Installation sur l'appareil ---------------- */
  let promptInstall = null;
  window.addEventListener('beforeinstallprompt', e => {
    e.preventDefault();
    promptInstall = e;
    const b = el('button', {
      class: 'bandeau-install', onclick: () => {
        promptInstall.prompt();
        promptInstall.userChoice.then(() => { b.remove(); promptInstall = null; });
      },
      text: '📲 Installer ÉduGestion Pro sur cet appareil'
    });
    document.body.appendChild(b);
    setTimeout(() => { if (b.parentNode) b.remove(); }, 20000);
  });

  /* ---------------- Amorçage ---------------- */
  function demarrer() {
    if ('serviceWorker' in navigator && location.protocol !== 'file:') {
      navigator.serviceWorker.register('sw.js').catch(() => { /* hors ligne indisponible sans HTTPS */ });
    }
    DB.open()
      .then(() => EG.seed())
      .then(() => EG.majMatieres())
      .then(() => DB.meta('session_utilisateur'))
      .then(id => id ? DB.get('users', id) : null)
      .then(u => (u && u.actif !== false) ? ouvrirSession(u) : ecranConnexion())
      .then(() => rendre())
      .catch(e => {
        console.error(e);
        document.getElementById('app').appendChild(el('div', { class: 'ecran-connexion' },
          el('div', { class: 'carte-connexion' }, [
            el('h1', { text: 'Démarrage impossible' }),
            el('p', { text: 'Le stockage local n’est pas accessible sur cet appareil : ' + e.message }),
            el('p', { class: 'muet petit', text: 'Vérifiez que la navigation privée est désactivée, puis rechargez la page.' })
          ])));
      });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', demarrer);
  else demarrer();
})(window);
