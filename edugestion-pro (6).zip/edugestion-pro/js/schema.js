/* ÉduGestion Pro V5.2 — Schéma de données
   Chaque entité = un magasin IndexedDB + un écran CRUD généré.
   t: text|textarea|number|money|date|datetime|bool|select|ref|json
*/
(function (global) {
  'use strict';

  const CYCLES = ['MATERNELLE', 'PRIMAIRE'];
  const NIVEAUX_MAT = ['EM1', 'EM2', 'PETITS', 'MOYENS', 'GRANDS'];
  const NIVEAUX_PRIM = ['CI', 'CP', 'CE1', 'CE2', 'CM1', 'CM2'];
  const NIVEAUX = NIVEAUX_MAT.concat(NIVEAUX_PRIM);
  const ETATS = ['BON', 'PASSABLE', 'MAUVAIS', 'HORS_SERVICE'];

  // Modules métier (26) — utilisés pour la navigation « Plus »
  const MODULES = [
    { code: 'socle', nom: 'Socle & référentiels', icone: '🏛️', entites: ['annees_scolaires', 'territoires', 'ecoles', 'classes', 'matieres', 'niveau_matieres', 'referentiels', 'rollover_jobs'],
      ecran: 'cloture', annexes: [['attribution-classes', 'Attribution des classes aux enseignants']] },
    { code: 'securite', nom: 'Utilisateurs & sécurité', icone: '🔐', entites: ['users', 'user_assignments', 'audit_events'] },
    { code: 'eleves', nom: 'Élèves', icone: '🎒', entites: ['eleves', 'eleve_handicaps', 'liens_eleves'], ecran: 'eleves' },
    { code: 'inscriptions', nom: 'Inscriptions', icone: '📋', entites: ['inscriptions_eleves', 'profils_annuels_eleves', 'statuts_scolarite', 'transferts_eleves', 'preinscriptions'] },
    { code: 'presences', nom: 'Présences', icone: '✅', entites: ['presences', 'presences_personnel', 'calendriers_scolaires'], ecran: 'presences',
      annexes: [['calendrier', 'Calendrier scolaire'], ['bilan-presences', 'Bilan de présence par cours'],
        ['presences-personnel', 'Présence du personnel']] },
    { code: 'evaluations', nom: 'Évaluations & notes', icone: '📝', entites: ['evaluations', 'notes', 'decisions_annuelles'], ecran: 'evaluations',
      annexes: [['synthese-evaluations', 'Panneau de synthèse des évaluations']] },
    { code: 'cep', nom: 'CEP & examens blancs', icone: '🎓', entites: ['examens_blancs', 'notes_examens_blancs', 'centres_examen', 'compositions_centre', 'fiches_cep', 'resultats_cep'],
      ecran: 'cep', annexes: [['cep-blanc-centre', 'Examen blanc en centre de circonscription']] },
    { code: 'personnel', nom: 'Personnel', icone: '👩‍🏫', entites: ['personnels', 'carrieres_personnel', 'affectations_personnel', 'diplomes_personnel', 'formations_personnel', 'evaluations_personnel', 'participations_up'], ecran: 'personnel' },
    { code: 'retraite', nom: 'Retraite', icone: '⏳', entites: ['regles_retraite', 'notifications_retraite'], ecran: 'retraite' },
    { code: 'infrastructure', nom: 'Infrastructures', icone: '🏫', entites: ['infrastructures', 'accessibilite_infrastructure', 'inspections_infrastructure'], ecran: 'patrimoine' },
    { code: 'mobilier', nom: 'Mobilier', icone: '🪑', entites: ['inventaires_mobilier', 'mouvements_mobilier'], ecran: 'patrimoine' },
    { code: 'didactique', nom: 'Matériel didactique', icone: '📚', entites: ['inventaires_equipements', 'ressources_pedagogiques'], ecran: 'patrimoine' },
    { code: 'services', nom: 'Services & structure', icone: '🚰', entites: ['services_ecole', 'structure_pedagogique'], ecran: 'patrimoine' },
    { code: 'cantine', nom: 'Cantine', icone: '🍚', entites: ['cantines', 'participations_cantine'], ecran: 'cantine',
      annexes: [['cantine-paiements', 'Contributions et listes de paiement']] },
    { code: 'budget', nom: 'Budget', icone: '💰', entites: ['budgets_ecoles', 'mouvements_budget', 'pieces_financieres'], ecran: 'budget' },
    { code: 'gouvernance', nom: 'Gestion participative', icone: '🤝', entites: ['gestion_participative', 'reunions_gestion', 'communication_resultats'], ecran: 'gouvernance' },
    { code: 'recensement', nom: 'Recensement', icone: '🧮', entites: ['campagnes_recensement', 'recensements_ecoles', 'recensement_valeurs', 'bilans_recensement'], ecran: 'recensement' },
    { code: 'parents', nom: 'Portail parents', icone: '👨‍👩‍👧', entites: ['profils_parents', 'liens_parent_enfant', 'communications_ecole', 'messages'], ecran: 'parents' },
    { code: 'risques', nom: 'Risques & décrochage', icone: '⚠️', entites: ['modeles_risque', 'scores_risque', 'alertes_scolaires', 'accompagnements_eleves', 'actions_accompagnement'], ecran: 'risques' },
    { code: 'alertes', nom: 'Centre d\'alertes', icone: '🔔', entites: ['types_alertes', 'alertes', 'actions_alertes'], ecran: 'alertes' },
    { code: 'visites', nom: 'Visites & recommandations', icone: '🧭', entites: ['visites', 'observations_visites', 'recommandations', 'plans_amelioration', 'actions_plan_amelioration'], ecran: 'visites' },
    { code: 'documents', nom: 'Documents & archives', icone: '📄', entites: ['types_documents', 'documents', 'signatures_documents'], ecran: 'documents' },
    { code: 'analytics', nom: 'Statistiques', icone: '📊', entites: ['statistiques_agregees', 'populations_scolarisables', 'definitions_indicateurs', 'projections'], ecran: 'analytics',
      annexes: [['affichage', 'Tableau d’affichage de classe']] },
    { code: 'rapports', nom: 'Rapports', icone: '🗂️', entites: ['modeles_rapports', 'generations_rapports'], ecran: 'rapports' },
    { code: 'educmaster', nom: 'EDUCMaster & synchro', icone: '🔄', entites: ['educmaster_sync_queue', 'conflits_synchronisation', 'rapprochements_eleves', 'fusions_eleves', 'device_sync_status'], ecran: 'educmaster' },
    { code: 'support', nom: 'Support & exploitation', icone: '🛠️', entites: ['support_tickets', 'maintenances', 'feature_flags'] }
  ];

  const f = (n, l, t, extra) => Object.assign({ n, l, t: t || 'text' }, extra || {});

  const SCHEMA = {
    /* ---------------- SOCLE ---------------- */
    annees_scolaires: {
      label: 'Années scolaires', singulier: 'Année scolaire', icone: '📅',
      titre: r => r.code,
      champs: [
        f('code', 'Code', 'text', { req: 1, list: 1, ph: '2026-2027' }),
        f('date_debut', 'Début', 'date', { req: 1, list: 1 }),
        f('date_fin', 'Fin', 'date', { req: 1, list: 1 }),
        f('statut', 'Statut', 'select', { list: 1, o: ['PREPARATION', 'OUVERTE', 'CLOTURE_EN_COURS', 'CLOTUREE', 'ARCHIVEE'], def: 'PREPARATION' })
      ]
    },
    territoires: {
      label: 'Territoires', singulier: 'Territoire', icone: '🗺️',
      titre: r => r.nom,
      champs: [
        f('type', 'Type', 'select', { req: 1, list: 1, o: ['NATIONAL', 'DEPARTEMENT', 'COMMUNE', 'CIRCONSCRIPTION', 'ZONE_PEDAGOGIQUE', 'UNITE_PEDAGOGIQUE'] }),
        f('code', 'Code', 'text', { list: 1 }),
        f('nom', 'Nom', 'text', { req: 1, list: 1 }),
        f('parent_id', 'Rattaché à', 'ref', { ref: 'territoires' }),
        f('actif', 'Actif', 'bool', { def: true })
      ]
    },
    ecoles: {
      label: 'Écoles', singulier: 'École', icone: '🏫',
      titre: r => r.nom,
      champs: [
        f('code_ecole', 'Code école', 'text', { req: 1, list: 1 }),
        f('nom', 'Nom', 'text', { req: 1, list: 1 }),
        f('cycle', 'Cycle', 'select', { req: 1, list: 1, o: ['MATERNELLE', 'PRIMAIRE', 'MIXTE'] }),
        f('territoire_id', 'Circonscription', 'ref', { ref: 'territoires', list: 1 }),
        f('commune', 'Commune', 'text', { list: 1 }),
        f('zone_id', 'Zone pédagogique', 'ref', { ref: 'territoires' }),
        f('up_id', 'Unité pédagogique', 'ref', { ref: 'territoires' }),
        f('directeur_nom', 'Nom du directeur', 'text'),
        f('directeur_telephone', 'Téléphone du directeur', 'text'),
        f('statut', 'Statut', 'select', { o: ['PUBLIQUE', 'PRIVEE', 'COMMUNAUTAIRE'] }),
        f('adresse', 'Adresse', 'text'),
        f('telephone', 'Téléphone', 'text'),
        f('email', 'E-mail', 'text'),
        f('latitude', 'Latitude', 'number'),
        f('longitude', 'Longitude', 'number'),
        f('actif', 'Active', 'bool', { def: true })
      ]
    },
    classes: {
      label: 'Classes', singulier: 'Classe', icone: '🚪',
      titre: r => r.libelle || r.code,
      champs: [
        f('ecole_id', 'École', 'ref', { ref: 'ecoles', req: 1, scope: 1 }),
        f('annee_scolaire_id', 'Année', 'ref', { ref: 'annees_scolaires', req: 1, annee: 1 }),
        f('niveau', 'Niveau', 'select', { req: 1, list: 1, o: NIVEAUX }),
        f('code', 'Code', 'text', { list: 1 }),
        f('libelle', 'Libellé', 'text', { list: 1 }),
        f('titulaire_id', 'Enseignant titulaire', 'ref', { ref: 'personnels', list: 1 }),
        f('effectif_max', 'Effectif maximum', 'number', { def: 60 }),
        f('actif', 'Active', 'bool', { def: true })
      ]
    },
    matieres: {
      label: 'Matières', singulier: 'Matière', icone: '📖',
      titre: r => r.nom,
      champs: [
        f('code', 'Code', 'text', { req: 1, list: 1 }),
        f('nom', 'Nom', 'text', { req: 1, list: 1 }),
        f('cycle', 'Cycle', 'select', { list: 1, o: CYCLES }),
        f('ordre', 'Ordre', 'number', { list: 1 }),
        f('actif', 'Active', 'bool', { def: true })
      ]
    },
    niveau_matieres: {
      label: 'Matières par niveau', singulier: 'Matière du niveau', icone: '🧩',
      champs: [
        f('annee_scolaire_id', 'Année', 'ref', { ref: 'annees_scolaires', annee: 1 }),
        f('niveau', 'Niveau', 'select', { req: 1, list: 1, o: NIVEAUX }),
        f('matiere_id', 'Matière', 'ref', { ref: 'matieres', req: 1, list: 1 }),
        f('coefficient', 'Coefficient', 'number', { def: 1, list: 1 }),
        f('obligatoire', 'Obligatoire', 'bool', { def: true })
      ]
    },
    rapprochements_eleves: {
      label: 'Rapprochements d’élèves', singulier: 'Rapprochement', icone: '🔎',
      champs: [
        f('eleve_local_id', 'Dossier examiné', 'ref', { ref: 'eleves', req: 1, list: 1 }),
        f('candidat_id', 'Dossier candidat', 'ref', { ref: 'eleves', list: 1 }),
        f('score', 'Ressemblance (%)', 'number', { list: 1 }),
        f('raisons', 'Critères concordants', 'json'),
        f('statut', 'Statut', 'select', { list: 1, o: ['A_EXAMINER', 'FUSIONNE', 'DISTINCTS'], def: 'A_EXAMINER' })
      ]
    },
    fusions_eleves: {
      label: 'Fusions de dossiers', singulier: 'Fusion', icone: '🧬', lectureSeule: true,
      champs: [
        f('eleve_source_id', 'Dossier absorbé', 'ref', { ref: 'eleves', list: 1 }),
        f('eleve_cible_id', 'Dossier conservé', 'ref', { ref: 'eleves', list: 1 }),
        f('justification', 'Justification', 'textarea', { list: 1 }),
        f('effectuee_par_label', 'Effectuée par', 'text', { list: 1 }),
        f('elements_deplaces', 'Éléments déplacés', 'json'),
        f('created_at', 'Date', 'datetime', { list: 1 })
      ]
    },
    rollover_jobs: {
      label: 'Clôtures d’année', singulier: 'Clôture', icone: '🔁', lectureSeule: true,
      champs: [
        f('from_year_id', 'Année clôturée', 'ref', { ref: 'annees_scolaires', list: 1 }),
        f('to_year_id', 'Année ouverte', 'ref', { ref: 'annees_scolaires', list: 1 }),
        f('statut', 'Statut', 'select', { list: 1, o: ['EN_COURS', 'TERMINE', 'ECHEC'] }),
        f('current_step', 'Étape', 'text', { list: 1 }),
        f('progress', 'Avancement (%)', 'number', { list: 1 }),
        f('resume', 'Résumé', 'json'),
        f('completed_at', 'Terminée le', 'datetime', { list: 1 })
      ]
    },
    referentiels: {
      label: 'Référentiels', singulier: 'Référentiel', icone: '📕',
      titre: r => r.nom,
      champs: [
        f('code', 'Code', 'text', { req: 1, list: 1 }),
        f('nom', 'Nom', 'text', { req: 1, list: 1 }),
        f('domaine', 'Domaine', 'text', { list: 1 }),
        f('version', 'Version', 'text', { list: 1 }),
        f('statut', 'Statut', 'select', { list: 1, o: ['BROUILLON', 'EN_REVUE', 'APPROUVE', 'PUBLIE', 'RETIRE'], def: 'BROUILLON' }),
        f('date_effet', 'Date d\'effet', 'date'),
        f('contenu', 'Contenu', 'json'),
        f('reference_officielle', 'Référence officielle', 'textarea')
      ]
    },

    /* ---------------- SÉCURITÉ ---------------- */
    users: {
      label: 'Utilisateurs', singulier: 'Utilisateur', icone: '👤',
      titre: r => (r.nom || '') + ' ' + (r.prenoms || ''),
      champs: [
        f('identifiant', 'Identifiant', 'text', { req: 1, list: 1 }),
        f('nom', 'Nom', 'text', { req: 1, list: 1 }),
        f('prenoms', 'Prénoms', 'text', { list: 1 }),
        f('role', 'Rôle', 'select', { req: 1, list: 1, o: ['ADMIN_MEMP', 'ADMIN_TECHNIQUE', 'DDEMP', 'CS', 'CP', 'DIRECTEUR', 'ENSEIGNANT', 'PARENT'] }),
        f('ecole_id', 'École', 'ref', { ref: 'ecoles' }),
        f('territoire_id', 'Territoire', 'ref', { ref: 'territoires' }),
        f('telephone', 'Téléphone', 'text'),
        f('email', 'E-mail', 'text'),
        f('mot_de_passe', 'Mot de passe (réinitialiser)', 'password'),
        f('actif', 'Actif', 'bool', { def: true, list: 1 })
      ]
    },
    user_assignments: {
      label: 'Affectations de rôle', singulier: 'Affectation', icone: '🔑',
      champs: [
        f('user_id', 'Utilisateur', 'ref', { ref: 'users', req: 1, list: 1 }),
        f('role', 'Rôle', 'select', { req: 1, list: 1, o: ['ADMIN_MEMP', 'ADMIN_TECHNIQUE', 'DDEMP', 'CS', 'CP', 'DIRECTEUR', 'ENSEIGNANT', 'PARENT'] }),
        f('ecole_id', 'École', 'ref', { ref: 'ecoles' }),
        f('territoire_id', 'Territoire', 'ref', { ref: 'territoires' }),
        f('date_debut', 'Début', 'date', { list: 1 }),
        f('date_fin', 'Fin', 'date'),
        f('actif', 'Active', 'bool', { def: true })
      ]
    },
    audit_events: {
      label: 'Journal d\'audit', singulier: 'Événement', icone: '🧾', lectureSeule: true,
      champs: [
        f('occurred_at', 'Horodatage', 'datetime', { list: 1 }),
        f('user_label', 'Utilisateur', 'text', { list: 1 }),
        f('action', 'Action', 'text', { list: 1 }),
        f('entity_type', 'Entité', 'text', { list: 1 }),
        f('entity_id', 'Identifiant', 'text'),
        f('metadata', 'Détails', 'json')
      ]
    },

    /* ---------------- ÉLÈVES ---------------- */
    eleves: {
      label: 'Élèves', singulier: 'Élève', icone: '🎒',
      titre: r => (r.nom || '').toUpperCase() + ' ' + (r.prenoms || ''),
      champs: [
        f('nom', 'Nom', 'text', { req: 1, list: 1 }),
        f('prenoms', 'Prénoms', 'text', { req: 1, list: 1 }),
        f('sexe', 'Sexe', 'select', { req: 1, list: 1, o: ['M', 'F'] }),
        f('date_naissance', 'Date de naissance', 'date', { list: 1 }),
        f('date_naissance_precision', 'Précision de la date', 'select', { o: ['EXACTE', 'APPROXIMATIVE', 'INCONNUE'], def: 'EXACTE' }),
        f('lieu_naissance', 'Lieu de naissance', 'text'),
        f('acte_naissance', 'Acte de naissance', 'bool'),
        f('npi', 'NPI (numéro personnel d’identification)', 'text', { list: 1 }),
        f('matricule_ecole', 'Numéro matricule de l’école', 'text', { list: 1 }),
        f('nom_pere', 'Nom et prénoms du père', 'text'),
        f('nom_mere', 'Nom et prénoms de la mère', 'text'),
        f('commune_naissance', 'Commune de naissance', 'text'),
        f('educmaster_matricule', 'Matricule EDUCMaster', 'text', { list: 1 }),
        f('educmaster_statut', 'Statut EDUCMaster', 'select', { o: ['NON_SYNCHRONISE', 'EN_ATTENTE', 'SYNCHRONISE', 'CONFLIT', 'REJETE'], def: 'NON_SYNCHRONISE' }),
        f('nationalite', 'Nationalité', 'text', { def: 'Béninoise' }),
        f('statut_identite', 'Statut', 'select', { o: ['ACTIF', 'FUSIONNE', 'INACTIF'], def: 'ACTIF' })
      ]
    },
    eleve_handicaps: {
      label: 'Situations de handicap', singulier: 'Situation de handicap', icone: '♿',
      champs: [
        f('eleve_id', 'Élève', 'ref', { ref: 'eleves', req: 1, list: 1 }),
        f('type', 'Type', 'select', { req: 1, list: 1, o: ['MOTEUR', 'VISUEL', 'AUDITIF', 'INTELLECTUEL', 'AUTRE'] }),
        f('precision_autre', 'Précision', 'text'),
        f('amenagements', 'Aménagements prévus', 'textarea'),
        f('actif', 'Actif', 'bool', { def: true })
      ]
    },
    liens_eleves: {
      label: 'Liens entre élèves', singulier: 'Lien', icone: '🔗',
      champs: [
        f('eleve_id', 'Élève', 'ref', { ref: 'eleves', req: 1, list: 1 }),
        f('autre_eleve_id', 'Autre élève', 'ref', { ref: 'eleves', req: 1, list: 1 }),
        f('type', 'Type', 'select', { o: ['FRERE_SOEUR', 'AUTRE'], list: 1 }),
        f('confirme', 'Confirmé', 'bool')
      ]
    },

    /* ---------------- INSCRIPTIONS ---------------- */
    inscriptions_eleves: {
      label: 'Inscriptions', singulier: 'Inscription', icone: '📋',
      champs: [
        f('eleve_id', 'Élève', 'ref', { ref: 'eleves', req: 1, list: 1 }),
        f('ecole_id', 'École', 'ref', { ref: 'ecoles', req: 1, scope: 1 }),
        f('annee_scolaire_id', 'Année', 'ref', { ref: 'annees_scolaires', req: 1, annee: 1 }),
        f('cycle', 'Cycle', 'select', { req: 1, o: CYCLES }),
        f('niveau', 'Niveau', 'select', { req: 1, list: 1, o: NIVEAUX }),
        f('classe_id', 'Classe', 'ref', { ref: 'classes', list: 1 }),
        f('type_inscription', 'Type', 'select', { req: 1, o: ['NOUVELLE', 'REINSCRIPTION', 'TRANSFERT_ENTRANT'], def: 'NOUVELLE' }),
        f('redoublant', 'Redoublant', 'bool', { list: 1 }),
        f('a_suivi_maternelle', 'A suivi la maternelle', 'bool'),
        f('date_inscription', 'Date d\'inscription', 'date', { req: 1 }),
        f('statut', 'Statut', 'select', { list: 1, o: ['ACTIF', 'TRANSFERE', 'ABANDON', 'SORTIE_PRIMAIRE_CEP', 'CLOTURE'], def: 'ACTIF' }),
        f('principale', 'Inscription principale', 'bool', { def: true })
      ]
    },
    profils_annuels_eleves: {
      label: 'Profils annuels', singulier: 'Profil annuel', icone: '🧷',
      champs: [
        f('inscription_id', 'Inscription', 'ref', { ref: 'inscriptions_eleves', req: 1, list: 1 }),
        f('orphelin', 'Orphelin', 'bool', { list: 1 }),
        f('vulnerable', 'Vulnérable', 'bool', { list: 1 }),
        f('etranger', 'Étranger', 'bool'),
        f('venu_autre_ecole', 'Vient d\'une autre école', 'bool')
      ]
    },
    transferts_eleves: {
      label: 'Transferts', singulier: 'Transfert', icone: '↔️',
      champs: [
        f('eleve_id', 'Élève', 'ref', { ref: 'eleves', req: 1, list: 1 }),
        f('ecole_origine_id', 'École d\'origine', 'ref', { ref: 'ecoles', req: 1, list: 1 }),
        f('ecole_destination_id', 'École de destination', 'ref', { ref: 'ecoles', req: 1, list: 1 }),
        f('annee_scolaire_id', 'Année', 'ref', { ref: 'annees_scolaires', annee: 1 }),
        f('motif', 'Motif', 'text'),
        f('statut', 'Statut', 'select', { list: 1, o: ['DEMANDE', 'ACCEPTE', 'REFUSE', 'ANNULE', 'TERMINE'], def: 'DEMANDE' })
      ]
    },
    statuts_scolarite: {
      label: 'Statuts de scolarité', singulier: 'Statut de scolarité', icone: '📍',
      champs: [
        f('inscription_id', 'Inscription', 'ref', { ref: 'inscriptions_eleves', req: 1, list: 1 }),
        f('statut', 'Statut', 'select', { req: 1, list: 1, o: ['SCOLARISE', 'RISQUE_DECROCHAGE', 'DECROCHAGE_CONFIRME', 'ABANDON', 'TRANSFERE', 'SORTIE_PRIMAIRE_CEP', 'SITUATION_INCONNUE'] }),
        f('source', 'Source', 'text', { list: 1 }),
        f('date_statut', 'Date du constat', 'date', { req: 1, list: 1 }),
        f('motif', 'Motif', 'textarea')
      ]
    },
    preinscriptions: {
      label: 'Préinscriptions', singulier: 'Préinscription', icone: '📨',
      champs: [
        f('eleve_id', 'Élève', 'ref', { ref: 'eleves', req: 1, list: 1 }),
        f('annee_scolaire_id', 'Année visée', 'ref', { ref: 'annees_scolaires', list: 1 }),
        f('ecole_destination_id', 'École proposée', 'ref', { ref: 'ecoles', list: 1 }),
        f('niveau_origine', 'Niveau d\'origine', 'select', { o: NIVEAUX }),
        f('niveau_propose', 'Niveau proposé', 'select', { o: NIVEAUX, list: 1 }),
        f('decision_origine', 'Décision d\'origine', 'text'),
        f('statut', 'Statut', 'select', { list: 1, o: ['PROPOSEE', 'CONFIRMEE', 'EXPIREE', 'ANNULEE'], def: 'PROPOSEE' })
      ]
    },

    /* ---------------- PRÉSENCES ---------------- */
    presences: {
      label: 'Présences', singulier: 'Présence', icone: '✅',
      champs: [
        f('inscription_id', 'Inscription', 'ref', { ref: 'inscriptions_eleves', req: 1, list: 1 }),
        f('date_presence', 'Date', 'date', { req: 1, list: 1 }),
        f('periode', 'Période', 'select', { o: ['JOURNEE', 'MATIN', 'APRES_MIDI'], def: 'JOURNEE' }),
        f('statut', 'Statut', 'select', { req: 1, list: 1, o: ['PRESENT', 'ABSENT', 'RETARD'] }),
        f('justifie', 'Justifié', 'bool', { list: 1 }),
        f('motif_justification', 'Motif', 'text'),
        f('commentaire', 'Commentaire', 'textarea')
      ]
    },
    calendriers_scolaires: {
      label: 'Calendrier scolaire', singulier: 'Jour du calendrier', icone: '🗓️',
      champs: [
        f('annee_scolaire_id', 'Année', 'ref', { ref: 'annees_scolaires', annee: 1 }),
        f('cycle', 'Cycle', 'select', { o: CYCLES, list: 1 }),
        f('date_jour', 'Date', 'date', { req: 1, list: 1 }),
        f('ouvrable', 'Jour ouvrable', 'bool', { def: true, list: 1 }),
        f('coefficient', 'Coefficient', 'number', { def: 1 }),
        f('motif', 'Motif', 'text', { list: 1 })
      ]
    },

    /* ---------------- ÉVALUATIONS ---------------- */
    evaluations: {
      label: 'Évaluations', singulier: 'Évaluation', icone: '📝',
      titre: r => (r.libelle || ('Évaluation ' + r.numero)),
      champs: [
        f('annee_scolaire_id', 'Année', 'ref', { ref: 'annees_scolaires', req: 1, annee: 1 }),
        f('ecole_id', 'École', 'ref', { ref: 'ecoles', req: 1, scope: 1 }),
        f('niveau', 'Niveau', 'select', { req: 1, list: 1, o: NIVEAUX }),
        f('classe_id', 'Classe', 'ref', { ref: 'classes', list: 1 }),
        f('numero', 'Numéro (1 à 9)', 'number', { req: 1, list: 1, min: 1, max: 9 }),
        f('mois', 'Mois', 'number', { min: 1, max: 12 }),
        f('libelle', 'Libellé', 'text', { list: 1 }),
        f('statut', 'Statut', 'select', { list: 1, o: ['BROUILLON', 'OUVERTE', 'VALIDEE', 'VERROUILLEE'], def: 'BROUILLON' })
      ]
    },
    notes: {
      label: 'Notes', singulier: 'Note', icone: '🔢',
      champs: [
        f('evaluation_id', 'Évaluation', 'ref', { ref: 'evaluations', req: 1, list: 1 }),
        f('inscription_id', 'Inscription', 'ref', { ref: 'inscriptions_eleves', req: 1, list: 1 }),
        f('matiere_id', 'Matière', 'ref', { ref: 'matieres', req: 1, list: 1 }),
        f('note', 'Note /20', 'number', { list: 1, min: 0, max: 20, step: 0.25 }),
        f('statut_special', 'Statut particulier', 'select', { o: ['', 'DISPENSE', 'ABSENT', 'NON_NOTE'] })
      ]
    },
    decisions_annuelles: {
      label: 'Décisions annuelles', singulier: 'Décision', icone: '⚖️',
      champs: [
        f('inscription_id', 'Inscription', 'ref', { ref: 'inscriptions_eleves', req: 1, list: 1 }),
        f('decision_pedagogique', 'Décision pédagogique', 'select', { list: 1, o: ['PASSAGE', 'REDOUBLEMENT', 'SORTIE_PRIMAIRE'] }),
        f('decision_finale', 'Décision finale', 'select', { list: 1, o: ['PASSAGE', 'REDOUBLEMENT', 'SORTIE_PRIMAIRE'] }),
        f('motif', 'Motif', 'text', { list: 1 }),
        f('force_par_cep', 'Forcée par le CEP', 'bool', { list: 1 }),
        f('regle_version', 'Version de règle', 'text'),
        f('statut', 'Statut', 'select', { o: ['BROUILLON', 'A_CONFIRMER', 'VALIDEE', 'VERROUILLEE'], def: 'BROUILLON' })
      ]
    },

    /* ---------------- CEP ---------------- */
    presences_personnel: {
      label: 'Présences du personnel', singulier: 'Présence d’un agent', icone: '🕗',
      champs: [
        f('personnel_id', 'Agent', 'ref', { ref: 'personnels', req: 1, list: 1 }),
        f('ecole_id', 'École', 'ref', { ref: 'ecoles', scope: 1 }),
        f('date_jour', 'Date', 'date', { req: 1, list: 1 }),
        f('statut', 'Statut', 'select', { req: 1, list: 1, o: ['PRESENT', 'ABSENT', 'RETARD', 'MISSION', 'CONGE', 'FORMATION', 'MALADIE'] }),
        f('justifie', 'Justifié', 'bool', { list: 1 }),
        f('motif', 'Motif', 'text', { list: 1 }),
        f('heure_arrivee', 'Heure d’arrivée', 'text'),
        f('reference_acte', 'Référence de l’acte', 'text')
      ]
    },
    centres_examen: {
      label: 'Centres d’examen blanc', singulier: 'Centre', icone: '🏟️',
      titre: r => r.nom,
      champs: [
        f('nom', 'Centre de composition', 'text', { req: 1, list: 1 }),
        f('annee_scolaire_id', 'Année', 'ref', { ref: 'annees_scolaires', annee: 1 }),
        f('territoire_id', 'Circonscription', 'ref', { ref: 'territoires', list: 1 }),
        f('commune', 'Commune', 'text', { list: 1 }),
        f('chef_centre', 'Chef de centre', 'text', { list: 1 }),
        f('date_composition', 'Date de composition', 'date', { list: 1 }),
        f('numero', 'Numéro de l’épreuve blanche', 'number', { def: 1, list: 1 }),
        f('statut', 'Statut', 'select', { list: 1, o: ['PREPARATION', 'OUVERT', 'CORRIGE', 'VALIDE', 'VERROUILLE'], def: 'PREPARATION' })
      ]
    },
    compositions_centre: {
      label: 'Compositions en centre', singulier: 'Composition', icone: '🖊️',
      champs: [
        f('centre_id', 'Centre', 'ref', { ref: 'centres_examen', req: 1, list: 1 }),
        f('inscription_id', 'Candidat', 'ref', { ref: 'inscriptions_eleves', req: 1, list: 1 }),
        f('ecole_id', 'École de provenance', 'ref', { ref: 'ecoles', list: 1 }),
        f('numero_ordre', 'N° d’ordre', 'number', { list: 1 }),
        f('notes', 'Notes par épreuve', 'json'),
        f('total', 'Total', 'number', { list: 1 }),
        f('moyenne', 'Moyenne', 'number', { list: 1 }),
        f('maitrises', 'Nombre de maîtrises', 'number', { list: 1 }),
        f('rang', 'Rang', 'number', { list: 1 }),
        f('absent', 'Absent', 'bool', { list: 1 })
      ]
    },
    examens_blancs: {
      label: 'Examens blancs', singulier: 'Examen blanc', icone: '🧪',
      titre: r => 'Examen blanc n°' + (r.numero || 1),
      champs: [
        f('annee_scolaire_id', 'Année', 'ref', { ref: 'annees_scolaires', annee: 1 }),
        f('ecole_id', 'École', 'ref', { ref: 'ecoles', req: 1, scope: 1 }),
        f('niveau', 'Niveau', 'select', { o: ['CM2'], def: 'CM2', list: 1 }),
        f('numero', 'Numéro', 'number', { def: 1, list: 1 }),
        f('date_examen', 'Date', 'date', { list: 1 }),
        f('statut', 'Statut', 'select', { list: 1, o: ['BROUILLON', 'OUVERT', 'VALIDE', 'VERROUILLE'], def: 'BROUILLON' })
      ]
    },
    notes_examens_blancs: {
      label: 'Notes d\'examens blancs', singulier: 'Note d\'examen blanc', icone: '🧾',
      champs: [
        f('examen_id', 'Examen', 'ref', { ref: 'examens_blancs', req: 1, list: 1 }),
        f('inscription_id', 'Inscription', 'ref', { ref: 'inscriptions_eleves', req: 1, list: 1 }),
        f('matiere_id', 'Matière', 'ref', { ref: 'matieres', req: 1, list: 1 }),
        f('note', 'Note /20', 'number', { list: 1, min: 0, max: 20 }),
        f('dispense', 'Dispensé', 'bool')
      ]
    },
    fiches_cep: {
      label: 'Fiches d’inscription au CEP', singulier: 'Fiche d’inscription', icone: '🗳️',
      champs: [
        f('inscription_id', 'Candidat', 'ref', { ref: 'inscriptions_eleves', req: 1, list: 1 }),
        f('session', 'Session', 'text', { list: 1, ph: 'JUIN 2027' }),
        f('centre', 'Centre de composition', 'text', { list: 1 }),
        f('option_6e', 'Option CEP + entrée en 6ᵉ', 'bool', { list: 1, def: true }),
        f('etablissement_1', 'Établissement choisi 1', 'text'),
        f('etablissement_2', 'Établissement choisi 2', 'text'),
        f('etablissement_3', 'Établissement choisi 3', 'text'),
        f('residence_parents', 'Résidence des parents', 'text', { list: 1 }),
        f('dispense_age', 'Dispense d’âge', 'bool', { list: 1 }),
        f('dispense_sport', 'Dispense de sport', 'bool', { list: 1 }),
        f('parent_nom', 'Nom et prénom du parent', 'text'),
        f('parent_contact', 'Contact du parent', 'text'),
        f('degre_parente', 'Degré de parenté', 'text'),
        f('dossier_etudie_par', 'Dossier étudié par (DDEMP)', 'text'),
        f('code_ddemp', 'Code DDEMP', 'text'),
        f('collationne_par', 'Collationné par', 'text'),
        f('statut', 'Statut', 'select', { list: 1, o: ['BROUILLON', 'COMPLETE', 'TRANSMISE'], def: 'BROUILLON' })
      ]
    },
    resultats_cep: {
      label: 'Résultats CEP', singulier: 'Résultat CEP', icone: '🎓',
      champs: [
        f('inscription_id', 'Inscription', 'ref', { ref: 'inscriptions_eleves', req: 1, list: 1 }),
        f('numero_table', 'Numéro de table', 'text', { list: 1 }),
        f('inscrit', 'Inscrit', 'bool', { list: 1 }),
        f('a_compose', 'A composé', 'bool', { list: 1 }),
        f('admis', 'Admis', 'bool', { list: 1 }),
        f('statut', 'Statut', 'select', { req: 1, list: 1, o: ['BROUILLON', 'PROVISOIRE', 'OFFICIEL'], def: 'BROUILLON' }),
        f('source', 'Source', 'text'),
        f('date_publication', 'Date de publication', 'date')
      ]
    },

    /* ---------------- PERSONNEL ---------------- */
    personnels: {
      label: 'Personnel', singulier: 'Agent', icone: '👩‍🏫',
      titre: r => (r.nom || '').toUpperCase() + ' ' + (r.prenoms || ''),
      champs: [
        f('matricule', 'Matricule', 'text', { list: 1 }),
        f('nip', 'NIP (numéro d’identification personnel)', 'text', { list: 1 }),
        f('nom', 'Nom', 'text', { req: 1, list: 1 }),
        f('prenoms', 'Prénoms', 'text', { req: 1, list: 1 }),
        f('sexe', 'Sexe', 'select', { o: ['M', 'F'], list: 1 }),
        f('date_naissance', 'Date de naissance', 'date', { req: 1, list: 1 }),
        f('lieu_naissance', 'Lieu de naissance', 'text'),
        f('telephone', 'Téléphone', 'text', { list: 1 }),
        f('email', 'E-mail', 'text'),
        f('ecole_id', 'École d\'affectation', 'ref', { ref: 'ecoles', scope: 1 }),
        f('fonction', 'Fonction', 'select', { list: 1, o: ['DIRECTEUR', 'ENSEIGNANT', 'CP', 'CS', 'ADMINISTRATIF', 'AUTRE'] }),
        f('categorie', 'Catégorie', 'select', { list: 1, o: ['A1', 'A2', 'A3', 'B1', 'C1'] }),
        f('echelon', 'Échelon', 'number', { min: 1, max: 15, list: 1 }),
        f('date_premiere_prise_service', 'Première prise de service', 'date'),
        f('date_arrivee_poste', 'Arrivée au poste', 'date'),
        f('adresse', 'Adresse', 'text'),
        f('situation_familiale', 'Situation familiale', 'select', { o: ['CELIBATAIRE', 'MARIE', 'DIVORCE', 'VEUF'] }),
        f('situation_militaire', 'Situation militaire', 'text'),
        f('diplome_recrutement', 'Diplôme de recrutement', 'text'),
        f('diplome_plus_eleve', 'Diplôme le plus élevé', 'text'),
        f('grade', 'Grade', 'text'),
        f('echelle', 'Échelle', 'text'),
        f('indice_reel', 'Indice réel', 'number'),
        f('emploi', 'Emploi', 'text'),
        f('qualite', 'Qualité', 'text'),
        f('contrat_initial', 'Contrat initial', 'text'),
        f('contrat_renouvele', 'Contrat renouvelé', 'text'),
        f('contrat_indetermine', 'Contrat à durée indéterminée', 'text'),
        f('avenant', 'Avenant', 'text'),
        f('langue_des_signes', 'Langue des signes', 'bool'),
        f('ecriture_braille', 'Écriture braille', 'bool'),
        f('pedagogie_inclusive', 'Pédagogie inclusive', 'bool'),
        f('ph', 'Personne handicapée', 'bool'),
        f('actif', 'En activité', 'bool', { def: true })
      ]
    },
    carrieres_personnel: {
      label: 'Carrière', singulier: 'Événement de carrière', icone: '📈',
      champs: [
        f('personnel_id', 'Agent', 'ref', { ref: 'personnels', req: 1, list: 1 }),
        f('statut_code', 'Statut', 'select', { o: ['APE', 'ACE', 'CONTRACTUEL_ETAT', 'COMMUNAUTAIRE', 'AUTRE'], list: 1 }),
        f('categorie', 'Catégorie', 'select', { o: ['A1', 'A2', 'A3', 'B1', 'C1'], list: 1 }),
        f('echelon', 'Échelon', 'number', { min: 1, max: 15, list: 1 }),
        f('grade', 'Grade', 'text'),
        f('indice_reel', 'Indice réel', 'number'),
        f('date_effet', 'Date d\'effet', 'date', { req: 1, list: 1 }),
        f('reference_acte', 'Référence de l\'acte', 'text')
      ]
    },
    affectations_personnel: {
      label: 'Affectations', singulier: 'Affectation', icone: '📌',
      champs: [
        f('personnel_id', 'Agent', 'ref', { ref: 'personnels', req: 1, list: 1 }),
        f('ecole_id', 'École', 'ref', { ref: 'ecoles', list: 1, scope: 1 }),
        f('classe_id', 'Classe', 'ref', { ref: 'classes', list: 1 }),
        f('fonction', 'Fonction', 'text', { req: 1, list: 1 }),
        f('date_debut', 'Début', 'date', { req: 1, list: 1 }),
        f('date_fin', 'Fin', 'date'),
        f('reference_acte', 'Référence de l\'acte', 'text')
      ]
    },
    diplomes_personnel: {
      label: 'Diplômes', singulier: 'Diplôme', icone: '📜',
      champs: [
        f('personnel_id', 'Agent', 'ref', { ref: 'personnels', req: 1, list: 1 }),
        f('type', 'Type', 'select', { o: ['ACADEMIQUE', 'PROFESSIONNEL'], list: 1 }),
        f('libelle', 'Libellé', 'text', { req: 1, list: 1 }),
        f('annee_obtention', 'Année d\'obtention', 'number', { list: 1 }),
        f('principal', 'Principal', 'bool')
      ]
    },
    formations_personnel: {
      label: 'Formations', singulier: 'Formation', icone: '🎯',
      champs: [
        f('personnel_id', 'Agent', 'ref', { ref: 'personnels', req: 1, list: 1 }),
        f('type', 'Type', 'select', { o: ['INITIALE', 'CONTINUE', 'RECYCLAGE', 'UNITE_PEDAGOGIQUE'], list: 1 }),
        f('intitule', 'Intitulé', 'text', { list: 1 }),
        f('date_debut', 'Début', 'date', { list: 1 }),
        f('date_fin', 'Fin', 'date'),
        f('organisme', 'Organisme', 'text')
      ]
    },
    evaluations_personnel: {
      label: 'Évaluations du personnel', singulier: 'Évaluation d\'agent', icone: '⭐',
      champs: [
        f('personnel_id', 'Agent', 'ref', { ref: 'personnels', req: 1, list: 1 }),
        f('annee_scolaire_id', 'Année', 'ref', { ref: 'annees_scolaires', annee: 1 }),
        f('periode_debut', 'Période du', 'date', { list: 1 }),
        f('periode_fin', 'au', 'date', { list: 1 }),
        f('objectifs', 'Objectifs de la période', 'textarea'),
        f('resultats', 'Résultats de la période', 'textarea'),
        f('contraintes', 'Contraintes et difficultés', 'textarea'),
        f('notes_hierarchique', 'Notes du supérieur hiérarchique', 'json'),
        f('notes_comite', 'Notes du comité de direction', 'json'),
        f('note_proposee', 'Note proposée', 'number', { list: 1 }),
        f('note_hierarchique', 'Note hiérarchique', 'number'),
        f('note_finale', 'Note finale', 'number', { list: 1 }),
        f('observations', 'Observations', 'textarea'),
        f('statut', 'Statut', 'select', { list: 1, o: ['BROUILLON', 'SOUMISE', 'CONTRESIGNEE', 'VERROUILLEE'], def: 'BROUILLON' })
      ]
    },
    participations_up: {
      label: 'Unités pédagogiques', singulier: 'Participation UP', icone: '🧑‍🤝‍🧑',
      champs: [
        f('personnel_id', 'Agent', 'ref', { ref: 'personnels', req: 1, list: 1 }),
        f('annee_scolaire_id', 'Année', 'ref', { ref: 'annees_scolaires', annee: 1 }),
        f('nombre_up_total', 'UP organisées', 'number', { list: 1 }),
        f('nombre_participations', 'Participations', 'number', { list: 1 })
      ]
    },

    /* ---------------- RETRAITE ---------------- */
    regles_retraite: {
      label: 'Règles de retraite', singulier: 'Règle de retraite', icone: '📏',
      titre: r => r.categorie + ' — ' + r.age_retraite + ' ans',
      champs: [
        f('categorie', 'Catégorie', 'select', { req: 1, list: 1, o: ['A1', 'A2', 'A3', 'B1', 'C1'] }),
        f('echelon_min', 'Échelon minimum', 'number', { def: 1, list: 1 }),
        f('echelon_max', 'Échelon maximum', 'number', { def: 12, list: 1 }),
        f('age_retraite', 'Âge de départ', 'number', { req: 1, list: 1 }),
        f('date_effet', 'Date d\'effet', 'date', { list: 1 }),
        f('reference_reglementaire', 'Référence réglementaire', 'text'),
        f('actif', 'Active', 'bool', { def: true })
      ]
    },
    notifications_retraite: {
      label: 'Notifications de retraite', singulier: 'Notification', icone: '📱',
      champs: [
        f('personnel_id', 'Agent', 'ref', { ref: 'personnels', req: 1, list: 1 }),
        f('annee_scolaire_id', 'Année', 'ref', { ref: 'annees_scolaires', annee: 1 }),
        f('type_notification', 'Type', 'select', { o: ['ANNUELLE', 'J_365', 'J_180', 'J_90', 'J_30'], list: 1 }),
        f('date_retraite_prevue', 'Date prévue', 'date', { list: 1 }),
        f('annees_restantes', 'Années restantes', 'number', { list: 1 }),
        f('message', 'Message', 'textarea'),
        f('statut', 'Statut', 'select', { list: 1, o: ['PLANIFIE', 'EN_COURS', 'ENVOYE', 'LIVRE', 'ECHEC', 'ANNULE'], def: 'PLANIFIE' })
      ]
    },

    /* ---------------- PATRIMOINE ---------------- */
    infrastructures: {
      label: 'Infrastructures', singulier: 'Local', icone: '🏫',
      titre: r => r.designation || r.code_local || r.type_local,
      champs: [
        f('ecole_id', 'École', 'ref', { ref: 'ecoles', req: 1, scope: 1 }),
        f('code_local', 'Code du local', 'text', { list: 1 }),
        f('type_local', 'Type', 'select', { req: 1, list: 1, o: ['SALLE_CLASSE', 'BUREAU', 'MAGASIN', 'CANTINE', 'LATRINES', 'BIBLIOTHEQUE', 'LOGEMENT', 'AUTRE'] }),
        f('designation', 'Désignation', 'text', { list: 1 }),
        f('annee_mise_service', 'Année de mise en service', 'number'),
        f('superficie_m2', 'Superficie (m²)', 'number'),
        f('utilise', 'Utilisé', 'bool', { def: true }),
        f('nature_murs', 'Nature des murs', 'select', { o: ['DUR', 'SEMI_DUR', 'BANCO', 'PAILLE', 'AUTRE'] }),
        f('etat_murs', 'État des murs', 'select', { o: ETATS, list: 1 }),
        f('nature_toit', 'Nature du toit', 'select', { o: ['TOLE', 'DALLE', 'PAILLE', 'AUTRE'] }),
        f('etat_toit', 'État du toit', 'select', { o: ETATS }),
        f('etat_portes', 'État des portes', 'select', { o: ETATS }),
        f('etat_fenetres', 'État des fenêtres', 'select', { o: ETATS }),
        f('financeur', 'Financeur', 'text'),
        f('observations', 'Observations', 'textarea')
      ]
    },
    accessibilite_infrastructure: {
      label: 'Accessibilité', singulier: 'Fiche d\'accessibilité', icone: '♿',
      champs: [
        f('infrastructure_id', 'Local', 'ref', { ref: 'infrastructures', req: 1, list: 1 }),
        f('rampe', 'Rampe d\'accès', 'bool', { list: 1 }),
        f('antiderapante', 'Surface antidérapante', 'bool'),
        f('main_courante', 'Main courante', 'bool'),
        f('inclinaison_moins_5', 'Inclinaison < 5 %', 'bool'),
        f('porte_adaptee', 'Porte adaptée', 'bool', { list: 1 }),
        f('circulation_fauteuil', 'Circulation en fauteuil', 'bool', { list: 1 }),
        f('observations', 'Observations', 'textarea')
      ]
    },
    inspections_infrastructure: {
      label: 'Inspections de locaux', singulier: 'Inspection', icone: '🔍',
      champs: [
        f('infrastructure_id', 'Local', 'ref', { ref: 'infrastructures', req: 1, list: 1 }),
        f('annee_scolaire_id', 'Année', 'ref', { ref: 'annees_scolaires', annee: 1 }),
        f('etat_global', 'État global', 'select', { o: ETATS, list: 1 }),
        f('observations', 'Observations', 'textarea'),
        f('inspecte_at', 'Date d\'inspection', 'date', { list: 1 })
      ]
    },
    inventaires_mobilier: {
      label: 'Inventaire du mobilier', singulier: 'Ligne d\'inventaire', icone: '🪑',
      champs: [
        f('ecole_id', 'École', 'ref', { ref: 'ecoles', req: 1, scope: 1 }),
        f('annee_scolaire_id', 'Année', 'ref', { ref: 'annees_scolaires', annee: 1 }),
        f('type_mobilier', 'Type', 'select', { req: 1, list: 1, o: ['TABLE_BANC', 'CHAISE', 'TABLE_MAITRE', 'ARMOIRE', 'ETAGERE', 'TABLEAU', 'NATTE', 'AUTRE'] }),
        f('niveau', 'Niveau', 'select', { o: NIVEAUX, list: 1 }),
        f('quantite', 'Quantité', 'number', { list: 1 }),
        f('bon_etat', 'En bon état', 'number', { list: 1 }),
        f('a_reparer', 'À réparer', 'number'),
        f('hors_service', 'Hors service', 'number'),
        f('adapte', 'Adapté au handicap', 'bool'),
        f('confirme', 'Confirmé', 'bool')
      ]
    },
    mouvements_mobilier: {
      label: 'Mouvements de mobilier', singulier: 'Mouvement', icone: '🚚',
      champs: [
        f('ecole_id', 'École', 'ref', { ref: 'ecoles', req: 1, scope: 1 }),
        f('type_mobilier', 'Type', 'text', { req: 1, list: 1 }),
        f('type_mouvement', 'Mouvement', 'select', { req: 1, list: 1, o: ['ENTREE', 'TRANSFERT_ENTRANT', 'TRANSFERT_SORTANT', 'REPARATION', 'REFORME', 'PERTE', 'CORRECTION'] }),
        f('quantite', 'Quantité', 'number', { req: 1, list: 1 }),
        f('date_mouvement', 'Date', 'date', { req: 1, list: 1 }),
        f('provenance_destination', 'Provenance / destination', 'text'),
        f('reference_document', 'Référence du document', 'text'),
        f('commentaire', 'Commentaire', 'textarea')
      ]
    },
    inventaires_equipements: {
      label: 'Équipements', singulier: 'Équipement', icone: '🧰',
      champs: [
        f('ecole_id', 'École', 'ref', { ref: 'ecoles', req: 1, scope: 1 }),
        f('annee_scolaire_id', 'Année', 'ref', { ref: 'annees_scolaires', annee: 1 }),
        f('categorie', 'Catégorie', 'select', { req: 1, list: 1, o: ['ORDINAIRE', 'ADAPTE', 'INFORMATIQUE', 'SPORTIF'] }),
        f('code_equipement', 'Équipement', 'text', { req: 1, list: 1 }),
        f('quantite', 'Quantité', 'number', { list: 1 }),
        f('bon_etat', 'En bon état', 'number', { list: 1 }),
        f('mauvais_etat', 'En mauvais état', 'number'),
        f('adapte', 'Adapté au handicap', 'bool')
      ]
    },
    ressources_pedagogiques: {
      label: 'Ressources pédagogiques', singulier: 'Ressource', icone: '📚',
      champs: [
        f('ecole_id', 'École', 'ref', { ref: 'ecoles', req: 1, scope: 1 }),
        f('annee_scolaire_id', 'Année', 'ref', { ref: 'annees_scolaires', annee: 1 }),
        f('categorie', 'Catégorie', 'select', { req: 1, list: 1, o: ['PROGRAMME', 'GUIDE', 'MANUEL', 'BRAILLE', 'AUTRE'] }),
        f('code_ressource', 'Ressource', 'text', { req: 1, list: 1 }),
        f('cours', 'Cours', 'select', { o: NIVEAUX, list: 1 }),
        f('quantite', 'Quantité', 'number', { list: 1 }),
        f('adapte_handicap', 'Adaptée au handicap', 'bool')
      ]
    },
    services_ecole: {
      label: 'Services de l\'école', singulier: 'Fiche de services', icone: '🚰',
      champs: [
        f('ecole_id', 'École', 'ref', { ref: 'ecoles', req: 1, scope: 1, list: 1 }),
        f('annee_scolaire_id', 'Année', 'ref', { ref: 'annees_scolaires', annee: 1 }),
        f('eau_potable', 'Eau potable', 'bool', { list: 1 }),
        f('eau_forage', 'Forage', 'bool'),
        f('eau_puits', 'Puits', 'bool'),
        f('electricite', 'Électricité', 'bool', { list: 1 }),
        f('solaire', 'Solaire', 'bool'),
        f('cantine', 'Cantine', 'bool', { list: 1 }),
        f('latrines', 'Latrines', 'bool', { list: 1 }),
        f('nb_blocs_latrines', 'Blocs de latrines', 'number'),
        f('nb_cabines_latrines', 'Cabines', 'number'),
        f('latrines_separees_fg', 'Latrines séparées filles/garçons', 'bool'),
        f('latrines_handicap', 'Latrines accessibles', 'bool'),
        f('lavage_mains', 'Dispositif de lavage des mains', 'bool')
      ]
    },
    structure_pedagogique: {
      label: 'Structure pédagogique', singulier: 'Ligne de structure', icone: '🧱',
      champs: [
        f('ecole_id', 'École', 'ref', { ref: 'ecoles', req: 1, scope: 1 }),
        f('annee_scolaire_id', 'Année', 'ref', { ref: 'annees_scolaires', annee: 1 }),
        f('cycle', 'Cycle', 'select', { o: CYCLES, list: 1 }),
        f('niveau', 'Niveau', 'select', { o: NIVEAUX, list: 1 }),
        f('structure', 'Structure', 'select', { o: ['SIMPLE', 'JUMELEE', 'MULTIGRADE'], list: 1 }),
        f('nombre', 'Nombre', 'number', { list: 1 })
      ]
    },

    /* ---------------- CANTINE / BUDGET / GOUVERNANCE ---------------- */
    cantines: {
      label: 'Cantines', singulier: 'Cantine', icone: '🍚',
      champs: [
        f('ecole_id', 'École', 'ref', { ref: 'ecoles', req: 1, scope: 1, list: 1 }),
        f('annee_scolaire_id', 'Année', 'ref', { ref: 'annees_scolaires', annee: 1 }),
        f('fonctionnelle', 'Fonctionnelle', 'bool', { list: 1 }),
        f('tarif_repas', 'Contribution par repas', 'money', { list: 1, def: 0 }),
        f('organisme_soutien', 'Organisme de soutien', 'text', { list: 1 }),
        f('equipement_cuisine', 'Équipement de cuisine', 'bool'),
        f('magasin_vivres_bon_etat', 'Magasin de vivres en bon état', 'bool'),
        f('responsable', 'Responsable', 'text')
      ]
    },
    participations_cantine: {
      label: 'Repas servis', singulier: 'Participation', icone: '🍽️',
      champs: [
        f('inscription_id', 'Inscription', 'ref', { ref: 'inscriptions_eleves', req: 1, list: 1 }),
        f('date_repas', 'Date', 'date', { req: 1, list: 1 }),
        f('a_mange', 'A mangé', 'bool', { list: 1 }),
        f('montant', 'Contribution due', 'money', { list: 1 }),
        f('paye', 'Réglée', 'bool', { list: 1 }),
        f('date_paiement', 'Date de règlement', 'date')
      ]
    },
    budgets_ecoles: {
      label: 'Budgets', singulier: 'Budget', icone: '💰',
      champs: [
        f('ecole_id', 'École', 'ref', { ref: 'ecoles', req: 1, scope: 1, list: 1 }),
        f('annee_scolaire_id', 'Année', 'ref', { ref: 'annees_scolaires', annee: 1, list: 1 }),
        f('budget_execute_precedent', 'Budget exécuté (n-1)', 'money'),
        f('solde_exercice_anterieur', 'Solde antérieur', 'money', { list: 1 }),
        f('subvention_etat', 'Subvention de l\'État', 'money', { list: 1 }),
        f('cotisation_parents', 'Cotisations des parents', 'money', { list: 1 }),
        f('autres_ressources', 'Autres ressources', 'money'),
        f('statut', 'Statut', 'select', { list: 1, o: ['BROUILLON', 'SOUMIS', 'VALIDE', 'VERROUILLE'], def: 'BROUILLON' })
      ]
    },
    mouvements_budget: {
      label: 'Mouvements budgétaires', singulier: 'Mouvement', icone: '📒',
      champs: [
        f('budget_id', 'Budget', 'ref', { ref: 'budgets_ecoles', req: 1, list: 1 }),
        f('type', 'Type', 'select', { req: 1, list: 1, o: ['SUBVENTION_ETAT', 'COTISATION_PARENT', 'AUTRE_RESSOURCE', 'DEPENSE', 'AJUSTEMENT'] }),
        f('categorie', 'Catégorie', 'text'),
        f('libelle', 'Libellé', 'text', { req: 1, list: 1 }),
        f('montant', 'Montant', 'money', { req: 1, list: 1 }),
        f('date_operation', 'Date', 'date', { req: 1, list: 1 }),
        f('reference_piece', 'Référence de la pièce', 'text'),
        f('commentaire', 'Commentaire', 'textarea')
      ]
    },
    pieces_financieres: {
      label: 'Pièces financières', singulier: 'Pièce', icone: '🧾',
      champs: [
        f('ecole_id', 'École', 'ref', { ref: 'ecoles', scope: 1 }),
        f('annee_scolaire_id', 'Année', 'ref', { ref: 'annees_scolaires', annee: 1 }),
        f('type_piece', 'Type', 'text', { list: 1 }),
        f('numero_piece', 'Numéro', 'text', { list: 1 }),
        f('date_piece', 'Date', 'date', { list: 1 }),
        f('fichier_nom', 'Fichier', 'text')
      ]
    },
    gestion_participative: {
      label: 'Gestion participative', singulier: 'Fiche de gouvernance', icone: '🤝',
      champs: [
        f('ecole_id', 'École', 'ref', { ref: 'ecoles', req: 1, scope: 1, list: 1 }),
        f('annee_scolaire_id', 'Année', 'ref', { ref: 'annees_scolaires', annee: 1 }),
        f('ape_existe', 'APE constituée', 'bool', { list: 1 }),
        f('ape_fonctionnel', 'APE fonctionnelle', 'bool', { list: 1 }),
        f('ame_existe', 'AME constituée', 'bool'),
        f('comite_direction', 'Comité de direction', 'bool'),
        f('conseil_maitres', 'Conseil des maîtres', 'bool'),
        f('comite_sante', 'Comité de santé', 'bool'),
        f('nombre_reunions_ape', 'Réunions APE', 'number', { list: 1 }),
        f('nombre_ag', 'Assemblées générales', 'number'),
        f('projet_ecole_verte', 'Projet école verte', 'bool')
      ]
    },
    reunions_gestion: {
      label: 'Réunions', singulier: 'Réunion', icone: '🗣️',
      champs: [
        f('ecole_id', 'École', 'ref', { ref: 'ecoles', req: 1, scope: 1 }),
        f('annee_scolaire_id', 'Année', 'ref', { ref: 'annees_scolaires', annee: 1 }),
        f('type', 'Type', 'select', { list: 1, o: ['REUNION_APE', 'AG', 'AME', 'COMITE_DIRECTION', 'CONSEIL_MAITRES', 'AUTRE'] }),
        f('date_reunion', 'Date', 'date', { req: 1, list: 1 }),
        f('nombre_participants', 'Participants', 'number', { list: 1 }),
        f('objet', 'Objet', 'text', { list: 1 }),
        f('compte_rendu', 'Compte rendu', 'textarea'),
        f('budget_aborde', 'Budget abordé', 'bool'),
        f('resultats_abordes', 'Résultats abordés', 'bool')
      ]
    },
    communication_resultats: {
      label: 'Communication des résultats', singulier: 'Fiche de communication', icone: '📣',
      champs: [
        f('ecole_id', 'École', 'ref', { ref: 'ecoles', req: 1, scope: 1, list: 1 }),
        f('annee_scolaire_id', 'Année', 'ref', { ref: 'annees_scolaires', annee: 1 }),
        f('carnet_correspondance', 'Carnet de correspondance', 'bool', { list: 1 }),
        f('assemblee_generale', 'Assemblée générale', 'bool', { list: 1 }),
        f('reunion_ape', 'Réunion APE', 'bool'),
        f('echange_parent', 'Échange direct avec le parent', 'bool'),
        f('precision_autre', 'Autre moyen', 'text')
      ]
    },

    /* ---------------- RECENSEMENT & STATS ---------------- */
    campagnes_recensement: {
      label: 'Campagnes de recensement', singulier: 'Campagne', icone: '🧮',
      titre: r => (r.type || '') + ' ' + (r.version_formulaire || ''),
      champs: [
        f('annee_scolaire_id', 'Année', 'ref', { ref: 'annees_scolaires', annee: 1, list: 1 }),
        f('type', 'Type', 'select', { req: 1, list: 1, o: ['MATERNELLE', 'PRIMAIRE'] }),
        f('date_reference_age', 'Date de référence pour l\'âge', 'date', { req: 1 }),
        f('date_ouverture', 'Ouverture', 'date', { list: 1 }),
        f('date_cloture', 'Clôture', 'date', { list: 1 }),
        f('version_formulaire', 'Version du formulaire', 'text'),
        f('statut', 'Statut', 'select', { list: 1, o: ['BROUILLON', 'OUVERTE', 'CLOTUREE', 'VERROUILLEE'], def: 'BROUILLON' })
      ]
    },
    recensements_ecoles: {
      label: 'Recensements par école', singulier: 'Recensement', icone: '📥',
      champs: [
        f('campagne_id', 'Campagne', 'ref', { ref: 'campagnes_recensement', req: 1, list: 1 }),
        f('ecole_id', 'École', 'ref', { ref: 'ecoles', req: 1, scope: 1, list: 1 }),
        f('statut', 'Statut', 'select', { list: 1, o: ['BROUILLON', 'A_COMPLETER', 'PRET', 'SOUMIS', 'A_CORRIGER', 'VALIDE', 'VERROUILLE'], def: 'BROUILLON' }),
        f('taux_completion', 'Taux de complétion (%)', 'number', { list: 1 })
      ]
    },
    recensement_valeurs: {
      label: 'Valeurs de recensement', singulier: 'Valeur', icone: '🔢',
      champs: [
        f('recensement_id', 'Recensement', 'ref', { ref: 'recensements_ecoles', req: 1 }),
        f('rubrique', 'Rubrique', 'text', { req: 1, list: 1 }),
        f('champ', 'Champ', 'text', { req: 1, list: 1 }),
        f('valeur', 'Valeur', 'text', { list: 1 }),
        f('origine', 'Origine', 'select', { list: 1, o: ['AUTO', 'CONFIRMEE', 'SAISIE'], def: 'SAISIE' }),
        f('source_table', 'Table source', 'text')
      ]
    },
    bilans_recensement: {
      label: 'Bilans de recensement', singulier: 'Bilan', icone: '📊',
      champs: [
        f('campagne_id', 'Campagne', 'ref', { ref: 'campagnes_recensement', req: 1, list: 1 }),
        f('niveau', 'Niveau', 'select', { req: 1, list: 1, o: ['CIRCONSCRIPTION', 'DDEMP', 'NATIONAL'] }),
        f('territoire_id', 'Territoire', 'ref', { ref: 'territoires', list: 1 }),
        f('cycle', 'Cycle', 'select', { o: ['MATERNELLE', 'PRIMAIRE', 'ENSEMBLE'], list: 1 }),
        f('nb_ecoles_attendues', 'Écoles attendues', 'number', { list: 1 }),
        f('nb_ecoles_repondues', 'Écoles ayant répondu', 'number', { list: 1 }),
        f('taux_couverture', 'Couverture (%)', 'number', { list: 1 }),
        f('statut', 'Statut', 'select', { o: ['BROUILLON', 'CALCULE', 'A_CONTROLER', 'VALIDE', 'VERROUILLE'], def: 'BROUILLON' })
      ]
    },
    statistiques_agregees: {
      label: 'Statistiques agrégées', singulier: 'Statistique', icone: '📈', lectureSeule: true,
      champs: [
        f('annee_scolaire_id', 'Année', 'ref', { ref: 'annees_scolaires', list: 1 }),
        f('territoire_type', 'Niveau territorial', 'text', { list: 1 }),
        f('territoire_id', 'Territoire', 'ref', { ref: 'territoires', list: 1 }),
        f('indicateur', 'Indicateur', 'text', { list: 1 }),
        f('cycle', 'Cycle', 'text', { list: 1 }),
        f('sexe', 'Sexe', 'text', { list: 1 }),
        f('valeur', 'Valeur', 'number', { list: 1 })
      ]
    },
    populations_scolarisables: {
      label: 'Populations scolarisables', singulier: 'Population', icone: '👶',
      champs: [
        f('annee', 'Année', 'number', { req: 1, list: 1 }),
        f('territoire_id', 'Territoire', 'ref', { ref: 'territoires', list: 1 }),
        f('age_min', 'Âge minimum', 'number', { req: 1, list: 1 }),
        f('age_max', 'Âge maximum', 'number', { list: 1 }),
        f('sexe', 'Sexe', 'select', { o: ['M', 'F'], req: 1, list: 1 }),
        f('population', 'Population', 'number', { req: 1, list: 1 }),
        f('source', 'Source', 'text')
      ]
    },
    definitions_indicateurs: {
      label: 'Définitions d\'indicateurs', singulier: 'Indicateur', icone: '📐',
      titre: r => r.nom,
      champs: [
        f('code', 'Code', 'text', { req: 1, list: 1 }),
        f('nom', 'Nom', 'text', { req: 1, list: 1 }),
        f('description', 'Description', 'textarea'),
        f('formule', 'Formule', 'text', { list: 1 }),
        f('unite', 'Unité', 'text', { list: 1 })
      ]
    },
    projections: {
      label: 'Projections', singulier: 'Projection', icone: '🔮',
      champs: [
        f('modele', 'Modèle', 'text', { req: 1, list: 1 }),
        f('version', 'Version', 'text'),
        f('territoire_id', 'Territoire', 'ref', { ref: 'territoires', list: 1 }),
        f('indicateur', 'Indicateur', 'text', { req: 1, list: 1 }),
        f('annee_cible', 'Année cible', 'number', { req: 1, list: 1 }),
        f('valeur_proj', 'Valeur projetée', 'number', { list: 1 }),
        f('intervalle_bas', 'Borne basse', 'number'),
        f('intervalle_haut', 'Borne haute', 'number')
      ]
    },

    /* ---------------- PARENTS ---------------- */
    profils_parents: {
      label: 'Parents', singulier: 'Parent', icone: '👨‍👩‍👧',
      titre: r => (r.nom || '').toUpperCase() + ' ' + (r.prenoms || ''),
      champs: [
        f('nom', 'Nom', 'text', { req: 1, list: 1 }),
        f('prenoms', 'Prénoms', 'text', { list: 1 }),
        f('telephone', 'Téléphone', 'text', { req: 1, list: 1 }),
        f('telephone_verifie', 'Téléphone vérifié', 'bool', { list: 1 }),
        f('email', 'E-mail', 'text'),
        f('user_id', 'Compte utilisateur', 'ref', { ref: 'users' }),
        f('actif', 'Actif', 'bool', { def: true })
      ]
    },
    liens_parent_enfant: {
      label: 'Liens parent-enfant', singulier: 'Lien', icone: '🔗',
      champs: [
        f('parent_id', 'Parent', 'ref', { ref: 'profils_parents', req: 1, list: 1 }),
        f('eleve_id', 'Élève', 'ref', { ref: 'eleves', req: 1, list: 1 }),
        f('relation', 'Relation', 'select', { list: 1, o: ['PERE', 'MERE', 'TUTEUR', 'RESPONSABLE', 'AUTRE'] }),
        f('statut', 'Statut', 'select', { list: 1, o: ['EN_ATTENTE', 'VALIDE', 'REFUSE', 'REVOQUE'], def: 'EN_ATTENTE' }),
        f('methode_validation', 'Méthode de validation', 'text')
      ]
    },
    communications_ecole: {
      label: 'Communications de l\'école', singulier: 'Communication', icone: '📢',
      titre: r => r.titre,
      champs: [
        f('ecole_id', 'École', 'ref', { ref: 'ecoles', req: 1, scope: 1 }),
        f('titre', 'Titre', 'text', { req: 1, list: 1 }),
        f('contenu', 'Contenu', 'textarea', { req: 1 }),
        f('audience', 'Audience', 'select', { list: 1, o: ['TOUS_PARENTS', 'NIVEAU', 'CLASSE', 'PERSONNEL'], def: 'TOUS_PARENTS' }),
        f('niveau', 'Niveau', 'select', { o: NIVEAUX }),
        f('date_publication', 'Publication', 'date', { list: 1 }),
        f('statut', 'Statut', 'select', { list: 1, o: ['BROUILLON', 'PUBLIEE', 'ARCHIVEE'], def: 'BROUILLON' })
      ]
    },
    messages: {
      label: 'Messages école-famille', singulier: 'Message', icone: '💬',
      champs: [
        f('ecole_id', 'École', 'ref', { ref: 'ecoles', scope: 1 }),
        f('eleve_id', 'Élève concerné', 'ref', { ref: 'eleves', list: 1 }),
        f('auteur_label', 'Auteur', 'text', { list: 1 }),
        f('destinataire_label', 'Destinataire', 'text', { list: 1 }),
        f('contenu', 'Message', 'textarea', { req: 1, list: 1 }),
        f('lu', 'Lu', 'bool')
      ]
    },

    /* ---------------- RISQUES & ALERTES ---------------- */
    modeles_risque: {
      label: 'Modèles de risque', singulier: 'Modèle', icone: '🧠',
      titre: r => r.code + ' ' + (r.version || ''),
      champs: [
        f('code', 'Code', 'text', { req: 1, list: 1 }),
        f('version', 'Version', 'text', { req: 1, list: 1 }),
        f('actif', 'Actif', 'bool', { list: 1 }),
        f('configuration', 'Pondérations', 'json'),
        f('date_activation', 'Date d\'activation', 'date')
      ]
    },
    scores_risque: {
      label: 'Scores de risque', singulier: 'Score', icone: '📉', lectureSeule: true,
      champs: [
        f('inscription_id', 'Inscription', 'ref', { ref: 'inscriptions_eleves', list: 1 }),
        f('score', 'Score /100', 'number', { list: 1 }),
        f('niveau', 'Niveau', 'select', { list: 1, o: ['FAIBLE', 'MOYEN', 'ELEVE', 'CRITIQUE'] }),
        f('facteurs', 'Facteurs', 'json'),
        f('calcule_at', 'Calculé le', 'datetime', { list: 1 })
      ]
    },
    alertes_scolaires: {
      label: 'Alertes de décrochage', singulier: 'Alerte de décrochage', icone: '🚸',
      champs: [
        f('inscription_id', 'Inscription', 'ref', { ref: 'inscriptions_eleves', req: 1, list: 1 }),
        f('niveau', 'Niveau', 'select', { req: 1, list: 1, o: ['FAIBLE', 'MOYEN', 'ELEVE', 'CRITIQUE'] }),
        f('statut', 'Statut', 'select', { list: 1, o: ['NOUVELLE', 'A_EXAMINER', 'PRISE_EN_CHARGE', 'SURVEILLANCE', 'RESOLUE', 'CLASSEE'], def: 'NOUVELLE' }),
        f('assignee_label', 'Prise en charge par', 'text', { list: 1 })
      ]
    },
    accompagnements_eleves: {
      label: 'Accompagnements', singulier: 'Accompagnement', icone: '🤗',
      champs: [
        f('inscription_id', 'Inscription', 'ref', { ref: 'inscriptions_eleves', req: 1, list: 1 }),
        f('responsable_label', 'Responsable', 'text', { list: 1 }),
        f('motif', 'Motif', 'textarea'),
        f('date_ouverture', 'Ouverture', 'date', { req: 1, list: 1 }),
        f('date_cloture', 'Clôture', 'date'),
        f('statut', 'Statut', 'select', { list: 1, o: ['OUVERT', 'EN_COURS', 'CLOTURE'], def: 'OUVERT' }),
        f('conclusion', 'Conclusion', 'textarea')
      ]
    },
    actions_accompagnement: {
      label: 'Actions d\'accompagnement', singulier: 'Action', icone: '✍️',
      champs: [
        f('accompagnement_id', 'Accompagnement', 'ref', { ref: 'accompagnements_eleves', req: 1, list: 1 }),
        f('type_action', 'Type', 'select', { req: 1, list: 1, o: ['VISITE_FAMILLE', 'APPEL', 'ENTRETIEN', 'SOUTIEN_SCOLAIRE', 'AIDE_MATERIELLE', 'AUTRE'] }),
        f('description', 'Description', 'textarea'),
        f('date_action', 'Date', 'date', { req: 1, list: 1 }),
        f('resultat', 'Résultat', 'textarea'),
        f('prochaine_action', 'Prochaine action', 'date')
      ]
    },
    types_alertes: {
      label: 'Types d\'alertes', singulier: 'Type d\'alerte', icone: '🏷️',
      titre: r => r.libelle,
      champs: [
        f('code', 'Code', 'text', { req: 1, list: 1 }),
        f('categorie', 'Catégorie', 'text', { list: 1 }),
        f('libelle', 'Libellé', 'text', { req: 1, list: 1 }),
        f('severite_defaut', 'Sévérité par défaut', 'select', { list: 1, o: ['INFO', 'FAIBLE', 'MOYENNE', 'ELEVEE', 'CRITIQUE'] }),
        f('actif', 'Actif', 'bool', { def: true })
      ]
    },
    alertes: {
      label: 'Alertes', singulier: 'Alerte', icone: '🔔',
      titre: r => r.titre,
      champs: [
        f('type_code', 'Type', 'text', { req: 1, list: 1 }),
        f('severite', 'Sévérité', 'select', { req: 1, list: 1, o: ['INFO', 'FAIBLE', 'MOYENNE', 'ELEVEE', 'CRITIQUE'] }),
        f('titre', 'Titre', 'text', { req: 1, list: 1 }),
        f('description', 'Description', 'textarea'),
        f('ecole_id', 'École', 'ref', { ref: 'ecoles', scope: 1, list: 1 }),
        f('statut', 'Statut', 'select', { list: 1, o: ['NOUVELLE', 'AFFECTEE', 'PRISE_EN_CHARGE', 'EN_ATTENTE', 'RESOLUE', 'CLOTUREE', 'IGNOREE'], def: 'NOUVELLE' }),
        f('detectee_at', 'Détectée le', 'datetime', { list: 1 })
      ]
    },
    actions_alertes: {
      label: 'Actions sur alertes', singulier: 'Action', icone: '🧰',
      champs: [
        f('alerte_id', 'Alerte', 'ref', { ref: 'alertes', req: 1, list: 1 }),
        f('type_action', 'Type', 'text', { list: 1 }),
        f('description', 'Description', 'textarea', { req: 1, list: 1 }),
        f('responsable_label', 'Responsable', 'text'),
        f('date_action', 'Date', 'date', { list: 1 }),
        f('resultat', 'Résultat', 'textarea')
      ]
    },

    /* ---------------- VISITES ---------------- */
    visites: {
      label: 'Visites', singulier: 'Visite', icone: '🧭',
      titre: r => (r.type_code || 'Visite') + ' — ' + (r.date_visite || ''),
      champs: [
        f('type_code', 'Type', 'select', { req: 1, list: 1, o: ['VISITE_CLASSE', 'VISITE_ECOLE', 'INSPECTION', 'SUIVI'] }),
        f('ecole_id', 'École', 'ref', { ref: 'ecoles', req: 1, scope: 1, list: 1 }),
        f('annee_scolaire_id', 'Année', 'ref', { ref: 'annees_scolaires', annee: 1 }),
        f('personnel_visite_id', 'Agent visité', 'ref', { ref: 'personnels', list: 1 }),
        f('classe_id', 'Classe', 'ref', { ref: 'classes' }),
        f('visiteur_label', 'Visiteur', 'text', { list: 1 }),
        f('date_visite', 'Date', 'date', { req: 1, list: 1 }),
        f('objet', 'Objet', 'textarea'),
        f('conclusion', 'Conclusion', 'textarea'),
        f('statut', 'Statut', 'select', { list: 1, o: ['BROUILLON', 'EN_COURS', 'A_CONTRESIGNER', 'VALIDEE', 'SUIVI', 'CLOTUREE'], def: 'BROUILLON' })
      ]
    },
    observations_visites: {
      label: 'Observations de visite', singulier: 'Observation', icone: '👁️',
      champs: [
        f('visite_id', 'Visite', 'ref', { ref: 'visites', req: 1, list: 1 }),
        f('categorie', 'Catégorie', 'text', { list: 1 }),
        f('niveau', 'Niveau', 'select', { list: 1, o: ['POSITIF', 'INFORMATION', 'A_AMELIORER', 'URGENT'] }),
        f('observation', 'Observation', 'textarea', { req: 1, list: 1 })
      ]
    },
    recommandations: {
      label: 'Recommandations', singulier: 'Recommandation', icone: '📌',
      champs: [
        f('visite_id', 'Visite', 'ref', { ref: 'visites', req: 1, list: 1 }),
        f('texte', 'Recommandation', 'textarea', { req: 1, list: 1 }),
        f('priorite', 'Priorité', 'select', { req: 1, list: 1, o: ['FAIBLE', 'NORMALE', 'ELEVEE', 'URGENTE'], def: 'NORMALE' }),
        f('echeance', 'Échéance', 'date', { list: 1 }),
        f('statut', 'Statut', 'select', { list: 1, o: ['A_FAIRE', 'EN_COURS', 'REALISEE', 'A_VERIFIER', 'VALIDEE', 'NON_APPLICABLE'], def: 'A_FAIRE' })
      ]
    },
    plans_amelioration: {
      label: 'Plans d\'amélioration', singulier: 'Plan', icone: '🗺️',
      titre: r => r.titre,
      champs: [
        f('ecole_id', 'École', 'ref', { ref: 'ecoles', req: 1, scope: 1, list: 1 }),
        f('annee_scolaire_id', 'Année', 'ref', { ref: 'annees_scolaires', annee: 1 }),
        f('titre', 'Titre', 'text', { req: 1, list: 1 }),
        f('origine', 'Origine', 'text'),
        f('date_debut', 'Début', 'date', { list: 1 }),
        f('date_fin_prevue', 'Fin prévue', 'date', { list: 1 }),
        f('statut', 'Statut', 'select', { list: 1, o: ['BROUILLON', 'EN_COURS', 'CLOTURE'], def: 'BROUILLON' })
      ]
    },
    actions_plan_amelioration: {
      label: 'Actions de plan', singulier: 'Action', icone: '✔️',
      champs: [
        f('plan_id', 'Plan', 'ref', { ref: 'plans_amelioration', req: 1, list: 1 }),
        f('titre', 'Titre', 'text', { req: 1, list: 1 }),
        f('description', 'Description', 'textarea'),
        f('responsable_label', 'Responsable', 'text', { list: 1 }),
        f('echeance', 'Échéance', 'date', { list: 1 }),
        f('statut', 'Statut', 'select', { list: 1, o: ['A_FAIRE', 'EN_COURS', 'REALISEE', 'ABANDONNEE'], def: 'A_FAIRE' }),
        f('resultat', 'Résultat', 'textarea')
      ]
    },

    /* ---------------- DOCUMENTS ---------------- */
    types_documents: {
      label: 'Types de documents', singulier: 'Type de document', icone: '🏷️',
      titre: r => r.nom,
      champs: [
        f('code', 'Code', 'text', { req: 1, list: 1 }),
        f('nom', 'Nom', 'text', { req: 1, list: 1 }),
        f('categorie', 'Catégorie', 'text', { list: 1 }),
        f('signature_requise', 'Signature requise', 'bool', { list: 1 }),
        f('verification_qr', 'Vérification par QR', 'bool', { list: 1 })
      ]
    },
    documents: {
      label: 'Documents', singulier: 'Document', icone: '📄',
      titre: r => r.titre,
      champs: [
        f('numero', 'Numéro', 'text', { list: 1 }),
        f('type_code', 'Type', 'text', { req: 1, list: 1 }),
        f('titre', 'Titre', 'text', { req: 1, list: 1 }),
        f('ecole_id', 'École', 'ref', { ref: 'ecoles', scope: 1 }),
        f('classe_id', 'Classe concernée', 'ref', { ref: 'classes' }),
        f('annee_scolaire_id', 'Année', 'ref', { ref: 'annees_scolaires', annee: 1 }),
        f('sensibilite', 'Sensibilité', 'select', { o: ['PUBLIC', 'INTERNE', 'CONFIDENTIEL', 'SENSIBLE'], def: 'INTERNE' }),
        f('statut', 'Statut', 'select', { list: 1, o: ['BROUILLON', 'GENERE', 'A_SIGNER', 'SIGNE', 'VALIDE', 'VERROUILLE', 'ARCHIVE', 'ANNULE'], def: 'GENERE' }),
        f('hash_sha256', 'Empreinte', 'text', { list: 1 }),
        f('contenu_html', 'Contenu', 'textarea')
      ]
    },

    /* ---------------- RAPPORTS ---------------- */
    signatures_documents: {
      label: 'Signatures de documents', singulier: 'Signature', icone: '✍️', lectureSeule: true,
      champs: [
        f('document_id', 'Document', 'ref', { ref: 'documents', list: 1 }),
        f('signataire_label', 'Signataire', 'text', { list: 1 }),
        f('role_signature', 'Qualité', 'text', { list: 1 }),
        f('type_signature', 'Type', 'select', { list: 1, o: ['NUMERIQUE', 'MANUSCRITE', 'CACHET'] }),
        f('hash_document', 'Empreinte signée', 'text', { list: 1 }),
        f('signed_at', 'Signé le', 'datetime', { list: 1 })
      ]
    },
    modeles_rapports: {
      label: 'Modèles de rapports', singulier: 'Modèle', icone: '🗂️',
      titre: r => r.nom,
      champs: [
        f('code', 'Code', 'text', { req: 1, list: 1 }),
        f('nom', 'Nom', 'text', { req: 1, list: 1 }),
        f('type', 'Type', 'select', { list: 1, o: ['OFFICIEL', 'PARAMETRABLE', 'SYSTEME'] }),
        f('description', 'Description', 'textarea'),
        f('configuration', 'Configuration', 'json'),
        f('actif', 'Actif', 'bool', { def: true })
      ]
    },
    generations_rapports: {
      label: 'Rapports générés', singulier: 'Rapport généré', icone: '📤', lectureSeule: true,
      champs: [
        f('nom', 'Rapport', 'text', { list: 1 }),
        f('format', 'Format', 'text', { list: 1 }),
        f('statut', 'Statut', 'text', { list: 1 }),
        f('created_at', 'Généré le', 'datetime', { list: 1 })
      ]
    },

    /* ---------------- SYNCHRO ---------------- */
    educmaster_sync_queue: {
      label: 'File EDUCMaster', singulier: 'Élément de file', icone: '🔄', lectureSeule: true,
      champs: [
        f('entity_type', 'Entité', 'text', { list: 1 }),
        f('entity_id', 'Identifiant', 'text', { list: 1 }),
        f('operation', 'Opération', 'text', { list: 1 }),
        f('statut', 'Statut', 'text', { list: 1 }),
        f('attempts', 'Tentatives', 'number', { list: 1 }),
        f('erreur', 'Erreur', 'text')
      ]
    },
    conflits_synchronisation: {
      label: 'Conflits de synchronisation', singulier: 'Conflit', icone: '⚔️',
      champs: [
        f('systeme', 'Système', 'text', { list: 1 }),
        f('entity_type', 'Entité', 'text', { list: 1 }),
        f('entity_id', 'Identifiant', 'text', { list: 1 }),
        f('type_conflit', 'Type', 'text', { list: 1 }),
        f('donnees_locales', 'Données locales', 'json'),
        f('donnees_distantes', 'Données distantes', 'json'),
        f('statut', 'Statut', 'select', { list: 1, o: ['OUVERT', 'RESOLU'], def: 'OUVERT' }),
        f('resolution', 'Résolution', 'text')
      ]
    },
    device_sync_status: {
      label: 'Appareils', singulier: 'Appareil', icone: '📱', lectureSeule: true,
      champs: [
        f('device_id', 'Appareil', 'text', { list: 1 }),
        f('user_label', 'Utilisateur', 'text', { list: 1 }),
        f('pending_count', 'En attente', 'number', { list: 1 }),
        f('last_sync_at', 'Dernière synchro', 'datetime', { list: 1 }),
        f('app_version', 'Version', 'text', { list: 1 })
      ]
    },

    /* ---------------- SUPPORT ---------------- */
    support_tickets: {
      label: 'Tickets de support', singulier: 'Ticket', icone: '🛠️',
      titre: r => r.reference + ' — ' + (r.titre || ''),
      champs: [
        f('reference', 'Référence', 'text', { list: 1 }),
        f('module', 'Module', 'text', { list: 1 }),
        f('severite', 'Sévérité', 'select', { list: 1, o: ['P0', 'P1', 'P2', 'P3'], def: 'P2' }),
        f('titre', 'Titre', 'text', { req: 1, list: 1 }),
        f('description', 'Description', 'textarea'),
        f('statut', 'Statut', 'select', { list: 1, o: ['OUVERT', 'EN_COURS', 'RESOLU', 'FERME'], def: 'OUVERT' })
      ]
    },
    maintenances: {
      label: 'Maintenances', singulier: 'Maintenance', icone: '🧯',
      titre: r => r.titre,
      champs: [
        f('titre', 'Titre', 'text', { req: 1, list: 1 }),
        f('debut', 'Début', 'datetime', { req: 1, list: 1 }),
        f('fin_prevue', 'Fin prévue', 'datetime', { req: 1, list: 1 }),
        f('impact', 'Impact', 'select', { o: ['AUCUN', 'PARTIEL', 'TOTAL'], list: 1 }),
        f('message', 'Message', 'textarea'),
        f('actif', 'Active', 'bool', { def: true })
      ]
    },
    feature_flags: {
      label: 'Fonctionnalités', singulier: 'Fonctionnalité', icone: '🚦',
      titre: r => r.code,
      champs: [
        f('code', 'Code', 'text', { req: 1, list: 1 }),
        f('enabled', 'Activée', 'bool', { list: 1 }),
        f('scope_type', 'Portée', 'text', { list: 1 }),
        f('configuration', 'Configuration', 'json')
      ]
    }
  };

  global.EG = global.EG || {};
  global.EG.SCHEMA = SCHEMA;
  global.EG.MODULES = MODULES;
  global.EG.NIVEAUX = NIVEAUX;
  global.EG.NIVEAUX_PRIM = NIVEAUX_PRIM;
  global.EG.NIVEAUX_MAT = NIVEAUX_MAT;
  global.EG.CYCLES = CYCLES;
  global.EG.STORES = Object.keys(SCHEMA);
})(window);
