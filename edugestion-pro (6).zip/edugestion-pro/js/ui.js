/* ÉduGestion Pro — composants d'interface, routeur, formulaires. */
(function (global) {
  'use strict';
  const EG = global.EG;

  /* ---------- Fabrique d'éléments ---------- */
  function el(tag, props, enfants) {
    const n = document.createElement(tag);
    if (props) Object.keys(props).forEach(k => {
      const v = props[k];
      if (v === null || v === undefined || v === false) return;
      if (k === 'class') n.className = v;
      else if (k === 'html') n.innerHTML = v;
      else if (k === 'text') n.textContent = v;
      else if (k === 'dataset') Object.keys(v).forEach(d => { n.dataset[d] = v[d]; });
      else if (k.slice(0, 2) === 'on' && typeof v === 'function') n.addEventListener(k.slice(2), v);
      else n.setAttribute(k, v === true ? '' : v);
    });
    (Array.isArray(enfants) ? enfants : (enfants === undefined || enfants === null ? [] : [enfants]))
      .forEach(c => {
        if (c === null || c === undefined || c === false) return;
        n.appendChild(typeof c === 'string' || typeof c === 'number' ? document.createTextNode(String(c)) : c);
      });
    return n;
  }
  const $ = sel => document.querySelector(sel);

  /* ---------- Formatage ---------- */
  const MOIS = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
  function dateFR(v) {
    if (!v) return '—';
    const d = new Date(v);
    if (isNaN(d.getTime())) return v;
    return d.getDate() + ' ' + MOIS[d.getMonth()] + ' ' + d.getFullYear();
  }
  function dateCourte(v) {
    if (!v) return '—';
    const d = new Date(v);
    if (isNaN(d.getTime())) return v;
    return String(d.getDate()).padStart(2, '0') + '/' + String(d.getMonth() + 1).padStart(2, '0') + '/' + d.getFullYear();
  }
  function heure(v) {
    if (!v) return '—';
    const d = new Date(v);
    return dateCourte(v) + ' à ' + String(d.getHours()).padStart(2, '0') + 'h' + String(d.getMinutes()).padStart(2, '0');
  }
  function fcfa(n) {
    if (n === null || n === undefined || n === '') return '—';
    return Number(n).toLocaleString('fr-FR') + ' F CFA';
  }
  function nombre(n) {
    if (n === null || n === undefined || isNaN(n)) return '—';
    return Number(n).toLocaleString('fr-FR');
  }
  /* Les codes techniques sont stockés en majuscules sans accent ; ce lexique
     rend l'affichage lisible et correctement orthographié pour l'utilisateur. */
  const LEXIQUE = {
    PREPARATION: 'Préparation', OUVERTE: 'Ouverte', CLOTURE_EN_COURS: 'Clôture en cours',
    CLOTUREE: 'Clôturée', CLOTURE: 'Clôturé', ARCHIVEE: 'Archivée', ARCHIVE: 'Archivé',
    VALIDEE: 'Validée', VALIDE: 'Validé', VERROUILLEE: 'Verrouillée', VERROUILLE: 'Verrouillé',
    GENERE: 'Généré', A_SIGNER: 'À signer', SIGNE: 'Signé', ANNULE: 'Annulé', ANNULEE: 'Annulée',
    SOUMIS: 'Soumis', SOUMISE: 'Soumise', CONTRESIGNEE: 'Contresignée',
    A_COMPLETER: 'À compléter', A_CORRIGER: 'À corriger', A_CONFIRMER: 'À confirmer',
    A_CONTROLER: 'À contrôler', A_CONTRESIGNER: 'À contresigner', PRET: 'Prêt', CALCULE: 'Calculé',
    NOUVELLE: 'Nouvelle', AFFECTEE: 'Affectée', PRISE_EN_CHARGE: 'Prise en charge',
    EN_ATTENTE: 'En attente', EN_COURS: 'En cours', RESOLUE: 'Résolue', IGNOREE: 'Ignorée',
    A_EXAMINER: 'À examiner', SURVEILLANCE: 'Surveillance', CLASSEE: 'Classée',
    A_FAIRE: 'À faire', REALISEE: 'Réalisée', A_VERIFIER: 'À vérifier',
    NON_APPLICABLE: 'Non applicable', ABANDONNEE: 'Abandonnée', SUIVI: 'Suivi',
    PASSAGE: 'Passage', REDOUBLEMENT: 'Redoublement',
    SORTIE_PRIMAIRE: 'Sortie du primaire', SORTIE_PRIMAIRE_CEP: 'Sortie du primaire (CEP)',
    PRESENT: 'Présent', ABSENT: 'Absent', RETARD: 'Retard', JOURNEE: 'Journée',
    APRES_MIDI: 'Après-midi', MATIN: 'Matin',
    NOUVELLE_INSCRIPTION: 'Nouvelle inscription', REINSCRIPTION: 'Réinscription',
    TRANSFERT_ENTRANT: 'Transfert entrant', TRANSFERT_SORTANT: 'Transfert sortant',
    TRANSFERE: 'Transféré', ABANDON: 'Abandon', ACCEPTE: 'Accepté', REFUSE: 'Refusé',
    TERMINE: 'Terminé', PROPOSEE: 'Proposée', CONFIRMEE: 'Confirmée', EXPIREE: 'Expirée',
    REVOQUE: 'Révoqué', BROUILLON: 'Brouillon', PROVISOIRE: 'Provisoire', OFFICIEL: 'Officiel',
    PLANIFIE: 'Planifié', ENVOYE: 'Envoyé', LIVRE: 'Livré', ECHEC: 'Échec',
    ELEVEE: 'Élevée', ELEVE: 'Élevé', MOYENNE: 'Moyenne', MOYEN: 'Moyen', FAIBLE: 'Faible',
    CRITIQUE: 'Critique', INFO: 'Information', URGENTE: 'Urgente', NORMALE: 'Normale',
    POSITIF: 'Positif', A_AMELIORER: 'À améliorer', URGENT: 'Urgent',
    SYNCHRONISE: 'Synchronisé', NON_SYNCHRONISE: 'Non synchronisé', CONFLIT: 'Conflit',
    REJETE: 'Rejeté', ERREUR: 'Erreur', RESOLU: 'Résolu', OUVERT: 'Ouvert', FERME: 'Fermé',
    SUBVENTION_ETAT: 'Subvention de l’État', COTISATION_PARENT: 'Cotisation des parents',
    AUTRE_RESSOURCE: 'Autre ressource', DEPENSE: 'Dépense', AJUSTEMENT: 'Ajustement',
    ENTREE: 'Entrée', REPARATION: 'Réparation', REFORME: 'Réforme', PERTE: 'Perte',
    CORRECTION: 'Correction',
    SALLE_CLASSE: 'Salle de classe', BUREAU: 'Bureau', MAGASIN: 'Magasin', CANTINE: 'Cantine',
    LATRINES: 'Latrines', BIBLIOTHEQUE: 'Bibliothèque', LOGEMENT: 'Logement',
    TABLE_BANC: 'Table-banc', TABLE_MAITRE: 'Table de maître', ETAGERE: 'Étagère',
    CHAISE: 'Chaise', ARMOIRE: 'Armoire', TABLEAU: 'Tableau', NATTE: 'Natte',
    BON: 'Bon', PASSABLE: 'Passable', MAUVAIS: 'Mauvais', HORS_SERVICE: 'Hors service',
    DUR: 'Dur', SEMI_DUR: 'Semi-dur', BANCO: 'Banco', PAILLE: 'Paille', TOLE: 'Tôle', DALLE: 'Dalle',
    ADMIN_MEMP: 'Administrateur MEMP', ADMIN_TECHNIQUE: 'Administrateur technique',
    DDEMP: 'Direction départementale', CS: 'Circonscription scolaire', CP: 'Conseiller pédagogique',
    DIRECTEUR: 'Directeur', ENSEIGNANT: 'Enseignant', PARENT: 'Parent', INSPECTEUR: 'Inspecteur',
    MATERNELLE: 'Maternelle', PRIMAIRE: 'Primaire', MIXTE: 'Mixte', ENSEMBLE: 'Ensemble',
    PUBLIQUE: 'Publique', PRIVEE: 'Privée', COMMUNAUTAIRE: 'Communautaire',
    NATIONAL: 'National', DEPARTEMENT: 'Département', COMMUNE: 'Commune',
    CIRCONSCRIPTION: 'Circonscription', ZONE_PEDAGOGIQUE: 'Zone pédagogique',
    UNITE_PEDAGOGIQUE: 'Unité pédagogique',
    PERE: 'Père', MERE: 'Mère', TUTEUR: 'Tuteur', RESPONSABLE: 'Responsable',
    FRERE_SOEUR: 'Frère ou sœur',
    MOTEUR: 'Moteur', VISUEL: 'Visuel', AUDITIF: 'Auditif', INTELLECTUEL: 'Intellectuel',
    EXACTE: 'Exacte', APPROXIMATIVE: 'Approximative', INCONNUE: 'Inconnue',
    SCOLARISE: 'Scolarisé', RISQUE_DECROCHAGE: 'Risque de décrochage',
    DECROCHAGE_CONFIRME: 'Décrochage confirmé', SITUATION_INCONNUE: 'Situation inconnue',
    SIMPLE: 'Simple', JUMELEE: 'Jumelée', MULTIGRADE: 'Multigrade',
    VISITE_CLASSE: 'Visite de classe', VISITE_ECOLE: 'Visite d’école', INSPECTION: 'Inspection',
    REUNION_APE: 'Réunion de l’APE', AG: 'Assemblée générale', AME: 'AME',
    COMITE_DIRECTION: 'Comité de direction', CONSEIL_MAITRES: 'Conseil des maîtres',
    ACADEMIQUE: 'Académique', PROFESSIONNEL: 'Professionnel',
    INITIALE: 'Initiale', CONTINUE: 'Continue', RECYCLAGE: 'Recyclage',
    VISITE_FAMILLE: 'Visite à la famille', APPEL: 'Appel téléphonique', ENTRETIEN: 'Entretien',
    SOUTIEN_SCOLAIRE: 'Soutien scolaire', AIDE_MATERIELLE: 'Aide matérielle',
    ORDINAIRE: 'Ordinaire', ADAPTE: 'Adapté', INFORMATIQUE: 'Informatique', SPORTIF: 'Sportif',
    PROGRAMME: 'Programme', GUIDE: 'Guide', MANUEL: 'Manuel', BRAILLE: 'Braille',
    TOUS_PARENTS: 'Tous les parents', NIVEAU: 'Un niveau', CLASSE: 'Une classe',
    PERSONNEL: 'Le personnel', PUBLIEE: 'Publiée', PUBLIC: 'Public', INTERNE: 'Interne',
    CONFIDENTIEL: 'Confidentiel', SENSIBLE: 'Sensible',
    OFFICIELLE: 'Officielle', PARAMETRABLE: 'Paramétrable', SYSTEME: 'Système',
    APE: 'APE', ACE: 'ACE', CONTRACTUEL_ETAT: 'Contractuel de l’État',
    ADMINISTRATIF: 'Administratif', AUTRE: 'Autre', ACTIF: 'Actif', ACTIVE: 'Active',
    AUCUN: 'Aucun', PARTIEL: 'Partiel', TOTAL: 'Total', AUTO: 'Automatique', SAISIE: 'Saisie',
    ANNUELLE: 'Annuelle', PENDING: 'En attente', SYNCED: 'Synchronisé', FAILED: 'Échec'
  };

  function libelle(v) {
    if (v === null || v === undefined || v === '') return '—';
    if (v === true) return 'Oui';
    if (v === false) return 'Non';
    const cle = String(v);
    if (LEXIQUE[cle]) return LEXIQUE[cle];
    return cle.replace(/_/g, ' ').toLowerCase().replace(/^./, c => c.toUpperCase());
  }
  function sansAccent(s) {
    return String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  }

  /* ---------- Retours visuels ---------- */
  let minuteurToast;
  function toast(message, variante) {
    let t = $('#toast');
    if (!t) { t = el('div', { id: 'toast' }); document.body.appendChild(t); }
    t.className = 'toast ' + (variante || '') + ' visible';
    t.textContent = message;
    clearTimeout(minuteurToast);
    minuteurToast = setTimeout(() => { t.className = 'toast ' + (variante || ''); }, 3200);
  }

  function modal(titre, contenu, actions) {
    const fond = el('div', { class: 'modal-fond' });
    const boite = el('div', { class: 'modal', role: 'dialog', 'aria-modal': 'true', 'aria-label': titre });
    const fermer = () => fond.remove();
    boite.appendChild(el('div', { class: 'modal-tete' }, [
      el('h2', { text: titre }),
      el('button', { class: 'icone-btn', 'aria-label': 'Fermer', onclick: fermer, text: '✕' })
    ]));
    boite.appendChild(el('div', { class: 'modal-corps' }, contenu));
    if (actions) boite.appendChild(el('div', { class: 'modal-pied' }, actions(fermer)));
    fond.appendChild(boite);
    fond.addEventListener('click', e => { if (e.target === fond) fermer(); });
    document.body.appendChild(fond);
    return fermer;
  }

  function confirmer(titre, message, onOui, libelleOui) {
    modal(titre, el('p', { text: message }), fermer => [
      el('button', { class: 'btn btn-fantome', text: 'Annuler', onclick: fermer }),
      el('button', {
        class: 'btn btn-danger', text: libelleOui || 'Confirmer',
        onclick: () => { fermer(); onOui(); }
      })
    ]);
  }

  function badge(texte, ton) {
    return el('span', { class: 'badge ' + (ton || ''), text: texte });
  }

  const TONS = {
    ACTIF: 'ok', VALIDE: 'ok', VALIDEE: 'ok', PUBLIE: 'ok', PUBLIEE: 'ok', OUVERTE: 'ok', SYNCHRONISE: 'ok',
    PRESENT: 'ok', PASSAGE: 'ok', ADMIS: 'ok', OFFICIEL: 'ok', RESOLUE: 'ok', REALISEE: 'ok', SORTIE_PRIMAIRE: 'info',
    BROUILLON: 'neutre', NOUVELLE: 'info', SOUMIS: 'info', PROVISOIRE: 'info', EN_COURS: 'info', A_COMPLETER: 'attention',
    RETARD: 'attention', MOYEN: 'attention', MOYENNE: 'attention', A_CORRIGER: 'attention', PENDING: 'attention',
    ABSENT: 'danger', REDOUBLEMENT: 'danger', CRITIQUE: 'danger', ELEVE: 'danger', ELEVEE: 'danger', ABANDON: 'danger',
    VERROUILLE: 'verrou', VERROUILLEE: 'verrou', CLOTUREE: 'verrou', CLOTURE: 'verrou'
  };
  function statut(v) {
    if (v === null || v === undefined || v === '') return el('span', { class: 'muet', text: '—' });
    return badge(libelle(v), TONS[String(v).toUpperCase()] || 'neutre');
  }

  function vide(message, action) {
    return el('div', { class: 'etat-vide' }, [
      el('p', { text: message }),
      action || null
    ]);
  }

  function carte(titre, corps, pied) {
    return el('section', { class: 'carte' }, [
      titre ? el('h3', { class: 'carte-titre', text: titre }) : null,
      corps, pied || null
    ]);
  }

  function stat(valeur, etiquette, ton) {
    return el('div', { class: 'stat ' + (ton || '') }, [
      el('div', { class: 'stat-valeur', text: valeur }),
      el('div', { class: 'stat-etiquette', text: etiquette })
    ]);
  }

  function barre(pourcentage, ton) {
    return el('div', { class: 'barre' }, el('span', {
      class: 'barre-remplie ' + (ton || ''), style: 'width:' + Math.max(0, Math.min(100, pourcentage)) + '%'
    }));
  }

  function tableau(colonnes, lignes, options) {
    options = options || {};
    if (!lignes.length) return vide(options.messageVide || 'Rien à afficher pour l’instant.', options.actionVide);
    const t = el('table', { class: 'tableau' });
    t.appendChild(el('thead', {}, el('tr', {}, colonnes.map(c => el('th', { text: c.titre, class: c.classe || '' })))));
    const corps = el('tbody');
    lignes.forEach(r => {
      const tr = el('tr', options.onLigne ? { class: 'cliquable', onclick: () => options.onLigne(r), tabindex: '0',
        onkeydown: e => { if (e.key === 'Enter') options.onLigne(r); } } : {});
      colonnes.forEach(c => {
        const v = c.valeur(r);
        tr.appendChild(el('td', { class: c.classe || '', 'data-th': c.titre },
          v instanceof Node ? v : document.createTextNode(v === null || v === undefined ? '—' : String(v))));
      });
      corps.appendChild(tr);
    });
    t.appendChild(corps);
    return el('div', { class: 'tableau-enveloppe' }, t);
  }

  function champRecherche(placeholder, onSaisie) {
    return el('div', { class: 'recherche' }, [
      el('span', { class: 'recherche-icone', text: '🔍', 'aria-hidden': 'true' }),
      el('input', { type: 'search', placeholder: placeholder, 'aria-label': placeholder, oninput: e => onSaisie(e.target.value) })
    ]);
  }

  function selecteur(etiquette, options, valeur, onChange, opts) {
    opts = opts || {};
    const s = el('select', { 'aria-label': etiquette, onchange: e => onChange(e.target.value) });
    if (opts.vide !== false) s.appendChild(el('option', { value: '', text: opts.libelleVide || 'Tous' }));
    options.forEach(o => {
      const op = el('option', { value: o.value, text: o.label });
      if (String(o.value) === String(valeur)) op.selected = true;
      s.appendChild(op);
    });
    return el('label', { class: 'filtre' }, [el('span', { text: etiquette }), s]);
  }

  /* ---------- Formulaire générique piloté par le schéma ---------- */
  function formulaire(entite, valeurs, refs, options) {
    options = options || {};
    const def = EG.SCHEMA[entite];
    const form = el('form', { class: 'formulaire', novalidate: true });
    const controles = {};
    const donnees = Object.assign({}, valeurs || {});

    def.champs.forEach(c => {
      if (options.masquer && options.masquer.indexOf(c.n) >= 0) return;
      let ctrl;
      const idc = 'f_' + c.n;
      const val = donnees[c.n] !== undefined && donnees[c.n] !== null ? donnees[c.n] : (c.def !== undefined ? c.def : '');
      if (c.t === 'textarea' || c.t === 'json') {
        ctrl = el('textarea', { id: idc, rows: c.t === 'json' ? 4 : 3 });
        ctrl.value = c.t === 'json' && typeof val === 'object' && val ? JSON.stringify(val, null, 2) : (val || '');
      } else if (c.t === 'bool') {
        ctrl = el('input', { type: 'checkbox', id: idc });
        ctrl.checked = !!val;
      } else if (c.t === 'select') {
        ctrl = el('select', { id: idc });
        ctrl.appendChild(el('option', { value: '', text: '— Choisir —' }));
        (c.o || []).filter(o => o !== '').forEach(o => {
          const op = el('option', { value: o, text: libelle(o) });
          if (String(val) === String(o)) op.selected = true;
          ctrl.appendChild(op);
        });
      } else if (c.t === 'ref') {
        ctrl = el('select', { id: idc });
        ctrl.appendChild(el('option', { value: '', text: '— Choisir —' }));
        ((refs && refs[c.ref]) || []).forEach(r => {
          const op = el('option', { value: r.id, text: EG.UI.titreDe(c.ref, r) });
          if (String(val) === String(r.id)) op.selected = true;
          ctrl.appendChild(op);
        });
      } else if (c.t === 'password') {
        ctrl = el('input', { type: 'password', id: idc, autocomplete: 'new-password' });
      } else {
        const type = c.t === 'number' || c.t === 'money' ? 'number'
          : (c.t === 'date' ? 'date' : (c.t === 'datetime' ? 'datetime-local' : 'text'));
        ctrl = el('input', { type: type, id: idc, placeholder: c.ph || '' });
        if (c.min !== undefined) ctrl.min = c.min;
        if (c.max !== undefined) ctrl.max = c.max;
        if (c.step) ctrl.step = c.step;
        ctrl.value = c.t === 'datetime' && val ? String(val).slice(0, 16) : (val === null ? '' : val);
      }
      if (c.req) ctrl.required = true;
      controles[c.n] = { ctrl, def: c };
      form.appendChild(el('div', { class: 'champ ' + (c.t === 'bool' ? 'champ-bool' : '') },
        c.t === 'bool'
          ? [ctrl, el('label', { for: idc, text: c.l })]
          : [el('label', { for: idc, text: c.l + (c.req ? ' *' : '') }), ctrl]));
    });

    form.lire = function () {
      const out = Object.assign({}, donnees);
      const erreurs = [];
      Object.keys(controles).forEach(k => {
        const { ctrl, def: c } = controles[k];
        let v;
        if (c.t === 'bool') v = ctrl.checked;
        else if (c.t === 'number' || c.t === 'money') v = ctrl.value === '' ? null : Number(ctrl.value);
        else if (c.t === 'json') {
          if (!ctrl.value.trim()) v = null;
          else { try { v = JSON.parse(ctrl.value); } catch (e) { erreurs.push(c.l + ' : le format JSON est invalide.'); v = null; } }
        } else v = ctrl.value === '' ? null : ctrl.value;
        if (c.req && (v === null || v === '' || v === undefined)) erreurs.push(c.l + ' est obligatoire.');
        if ((c.t === 'number' || c.t === 'money') && v !== null) {
          if (c.min !== undefined && v < c.min) erreurs.push(c.l + ' doit être au minimum ' + c.min + '.');
          if (c.max !== undefined && v > c.max) erreurs.push(c.l + ' doit être au maximum ' + c.max + '.');
        }
        if (c.t === 'password' && !v) return; // mot de passe laissé vide : inchangé
        out[k] = v;
      });
      return { valeurs: out, erreurs };
    };
    return form;
  }

  /* ---------- Routeur ---------- */
  const Routeur = {
    routes: {},
    definir(nom, rendu) { Routeur.routes[nom] = rendu; },
    /** Navigue vers une route. Demander la route déjà affichée la redessine :
        c'est ce qui permet à un écran de se rafraîchir après un enregistrement. */
    aller(chemin) {
      const cible = '#/' + String(chemin).replace(/^#?\/?/, '');
      if (location.hash === cible) window.dispatchEvent(new Event('hashchange'));
      else location.hash = cible;
    },
    lire() {
      const brut = location.hash.replace(/^#\/?/, '');
      const [chemin, requete] = brut.split('?');
      const segments = chemin ? chemin.split('/') : [];
      const params = {};
      (requete || '').split('&').filter(Boolean).forEach(p => {
        const [k, v] = p.split('=');
        params[decodeURIComponent(k)] = decodeURIComponent(v || '');
      });
      return { vue: segments[0] || 'accueil', args: segments.slice(1), params };
    }
  };

  EG.UI = {
    el, $, dateFR, dateCourte, heure, fcfa, nombre, libelle, sansAccent,
    toast, modal, confirmer, badge, statut, vide, carte, stat, barre, tableau,
    champRecherche, selecteur, formulaire, Routeur,
    titreDe(entite, r) {
      const d = EG.SCHEMA[entite];
      if (!r) return '—';
      if (d && d.titre) { try { return d.titre(r) || r.id.slice(0, 8); } catch (e) { /* champ manquant */ } }
      return r.nom || r.libelle || r.code || r.titre || (r.id || '').slice(0, 8);
    }
  };
})(window);
