/* ÉduGestion Pro — pièces officielles : cachet, signature, carte scolaire, fiche CEP. */
(function (global) {
  'use strict';
  const EG = global.EG, DB = EG.DB, U = EG.UI;
  const el = U.el;

  const echapper = v => String(v === null || v === undefined ? '' : v)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

  /* =======================================================================
     Cachet de l'établissement
     ======================================================================= */

  /**
   * Cachet circulaire dessiné à la volée à partir des données de l'école.
   * Il n'a pas valeur de sceau humide : il identifie l'émetteur et se vérifie
   * par le numéro et l'empreinte portés en pied de document.
   */
  function cachet(ecole, options) {
    options = options || {};
    const nom = (ecole && ecole.nom ? ecole.nom : 'ÉCOLE').toUpperCase();
    const code = (ecole && ecole.code_ecole) || '';
    /* Le nom en bas de cachet doit tenir sur l'arc : au-delà, on abrège. */
    const bas = nom.length > 30 ? nom.slice(0, 29) + '…' : nom;
    const taille = options.taille || 118;
    const id = 'c' + Math.random().toString(36).slice(2, 8);

    return '<svg class="cachet" width="' + taille + '" height="' + taille + '" viewBox="0 0 200 200"'
      + ' xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Cachet de ' + echapper(nom) + '">'
      + '<defs>'
      + '<path id="haut' + id + '" d="M 30,100 A 70,70 0 0 1 170,100"/>'
      + '<path id="bas' + id + '" d="M 36,100 A 64,64 0 0 0 164,100"/>'
      + '</defs>'
      + '<circle cx="100" cy="100" r="94" fill="none" stroke="#1B4D8F" stroke-width="4"/>'
      + '<circle cx="100" cy="100" r="80" fill="none" stroke="#1B4D8F" stroke-width="1.5"/>'
      + '<text font-size="15.5" font-weight="700" fill="#1B4D8F" text-anchor="middle"'
      + ' font-family="Helvetica, Arial, sans-serif">'
      + '<textPath href="#haut' + id + '" startOffset="50%">RÉPUBLIQUE DU BÉNIN</textPath></text>'
      + '<text font-size="11" font-weight="600" fill="#1B4D8F" text-anchor="middle"'
      + ' font-family="Helvetica, Arial, sans-serif">'
      + '<textPath href="#bas' + id + '" startOffset="50%">' + echapper(bas) + '</textPath></text>'
      + '<path d="M100 52 l6.6 20.3h21.4l-17.3 12.6 6.6 20.3L100 93.2 82.7 105.2l6.6-20.3L72 72.3h21.4z"'
      + ' fill="#008751"/>'
      + '<text x="100" y="126" font-size="17" font-weight="700" fill="#1B4D8F" text-anchor="middle"'
      + ' font-family="Helvetica, Arial, sans-serif" letter-spacing="1">MEMP</text>'
      + (code ? '<text x="100" y="142" font-size="11" font-weight="600" fill="#1B4D8F" text-anchor="middle"'
        + ' font-family="Helvetica, Arial, sans-serif">' + echapper(code) + '</text>' : '')
      + '</svg>';
  }

  /* =======================================================================
     Code QR de vérification
     ======================================================================= */

  /** Adresse de vérification portée par chaque pièce éditée. */
  function adresseVerification(numero, empreinte) {
    /* Chemin explicite plutôt qu'une réécriture d'URL : la page fonctionne ainsi
       sur n'importe quel hébergement statique, y compris GitHub Pages. */
    const base = (global.location && location.origin && location.origin !== 'null')
      ? location.origin + location.pathname.replace(/[^/]*$/, '')
      : 'https://edugestion.bj/';
    return base + 'verification.html?n=' + encodeURIComponent(numero)
      + (empreinte ? '#' + empreinte : '');
  }

  /** QR code d'un document : il mène à l'adresse de vérification. */
  function qrDocument(numero, empreinte, taille) {
    try {
      return '<div class="bloc-qr">' + EG.QR.svg(adresseVerification(numero, empreinte),
        { taille: taille || 82, niveau: 'M', description: 'Vérification du document ' + numero })
        + '<span>Vérifier</span></div>';
    } catch (e) { return ''; }
  }

  /** QR code d'un élève : identité minimale, lisible par un lecteur ordinaire. */
  function qrEleve(eleve, ins, ecole, annee, taille) {
    const charge = [
      'EGP-ELEVE',
      (eleve.educmaster_matricule || eleve.id || '').slice(0, 36),
      ((eleve.nom || '') + ' ' + (eleve.prenoms || '')).trim(),
      eleve.sexe || '',
      eleve.date_naissance || '',
      ins ? ins.niveau : '',
      ecole ? (ecole.code_ecole || ecole.nom) : '',
      annee || ''
    ].join('|');
    try {
      return EG.QR.svg(charge, { taille: taille || 76, niveau: 'M', description: 'Identité de l’élève' });
    } catch (e) { return ''; }
  }

  /* =======================================================================
     Signature numérique du responsable
     ======================================================================= */

  /** Une case de signature : mention, tracé s'il existe, nom en dessous. */
  function caseSignature(personne, mention) {
    const image = personne && personne.signature_image
      ? '<img class="signature-trace" src="' + personne.signature_image + '" alt="Signature">'
      : '<div class="signature-vide">Signature manuscrite</div>';
    return '<div class="signature-case">'
      + '<div class="signature-mention">' + echapper(mention || '') + '</div>'
      + image
      + '<div class="signature-nom">'
      + echapper((((personne && personne.prenoms) || '') + ' ' + ((personne && personne.nom) || '')).trim())
      + '</div></div>';
  }

  /**
   * Pied de signature. Le titulaire de la classe y figure à gauche pour toute
   * pièce rattachée à son cours : c'est lui qui répond de ce qui y est écrit.
   */
  function blocSignature(user, ecole, mention, titulaire) {
    return '<div class="bloc-signature">'
      + (titulaire ? caseSignature(titulaire, 'Le titulaire de la classe') : '')
      + caseSignature(user, mention === '' ? '' : (mention || 'Le directeur'))
      + '<div class="cachet-case">' + cachet(ecole) + '</div>'
      + '</div>';
  }

  /**
   * Capture d'une signature au doigt ou à la souris. Sert au responsable qui
   * édite, mais aussi à l'apprenant et à l'enseignant, dont la signature est
   * ensuite apposée sur les pièces qui les concernent.
   * options : { table, titre, mention }
   */
  function capturerSignature(enregistrement, apres, options) {
    options = options || {};
    const table = options.table || 'users';
    const user = enregistrement;
    const largeur = 520, hauteur = 200;
    const toile = el('canvas', { width: largeur, height: hauteur, class: 'toile-signature',
      'aria-label': 'Zone de signature' });
    const ctx = toile.getContext('2d');
    ctx.lineWidth = 2.4; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.strokeStyle = '#17201B';
    let trace = false, vide = true;

    if (user && user.signature_image) {
      const img = new Image();
      img.onload = () => { ctx.drawImage(img, 0, 0, largeur, hauteur); vide = false; };
      img.src = user.signature_image;
    }

    function point(e) {
      const r = toile.getBoundingClientRect();
      const src = e.touches ? e.touches[0] : e;
      return { x: (src.clientX - r.left) * (largeur / r.width), y: (src.clientY - r.top) * (hauteur / r.height) };
    }
    function debut(e) { e.preventDefault(); trace = true; vide = false; const p = point(e); ctx.beginPath(); ctx.moveTo(p.x, p.y); }
    function bouge(e) { if (!trace) return; e.preventDefault(); const p = point(e); ctx.lineTo(p.x, p.y); ctx.stroke(); }
    function fin() { trace = false; }
    ['mousedown', 'touchstart'].forEach(t => toile.addEventListener(t, debut, { passive: false }));
    ['mousemove', 'touchmove'].forEach(t => toile.addEventListener(t, bouge, { passive: false }));
    ['mouseup', 'mouseleave', 'touchend'].forEach(t => toile.addEventListener(t, fin));

    U.modal(options.titre || 'Ma signature', el('div', {}, [
      el('p', { class: 'muet', text: options.mention
        || 'Signez avec le doigt ou la souris. La signature est conservée sur cet appareil et apposée sur les documents que vous éditez.' }),
      toile,
      el('p', { class: 'muet petit', text: 'Elle vaut identification de l’émetteur, pas signature électronique qualifiée : chaque document reste vérifiable par son numéro et son empreinte.' })
    ]), fermer => [
      el('button', { class: 'btn btn-fantome', text: 'Annuler', onclick: fermer }),
      el('button', {
        class: 'btn btn-fantome', text: 'Effacer', onclick: () => {
          ctx.clearRect(0, 0, largeur, hauteur); vide = true;
        }
      }),
      el('button', {
        class: 'btn btn-primaire', text: 'Enregistrer', onclick: () => {
          if (vide) { U.toast('La zone de signature est vide', 'attention'); return; }
          const image = toile.toDataURL('image/png');
          DB.put(table, Object.assign({}, user, { signature_image: image }))
            .then(enregistre => {
              if (table === 'users' && EG.session.user.id === enregistre.id) EG.session.user = enregistre;
              return DB.audit('SIGNATURE_ENREGISTREE', table, enregistre.id);
            })
            .then(() => { fermer(); U.toast('Signature enregistrée'); EG.majSynchro(); if (apres) apres(); });
        }
      })
    ]);
  }

  /* =======================================================================
     En-tête officiel
     ======================================================================= */

  /** Bandeau du ministère, repris du modèle transmis par la DDEMP. */
  function enteteMEMP(departement, service) {
    const logo = (global.location && location.href)
      ? new URL('assets/entete-memp.jpg', location.href).href : 'assets/entete-memp.jpg';
    return '<div class="entete-memp">'
      + '<img src="' + logo + '" alt="Ministère des Enseignements Maternel et Primaire — République du Bénin">'
      + '<div class="entete-coordonnees">'
      + '01 BP 10 Porto-Novo<br>Tél. : +229 20 21 52 22 • Fax : +229 20 21 52 22<br>'
      + 'E-mail : mempmatprim@gmail.com</div>'
      + '</div>'
      + '<div class="entete-direction">Direction Départementale des Enseignements Maternel et Primaire : '
      + '<strong>' + echapper(departement || '—') + '</strong><br>'
      + echapper(service || 'Service des Examens et Concours') + '</div>';
  }

  /**
   * En-tête administratif court, apposé sur toutes les pièces éditées qui n'ont
   * pas déjà leur propre en-tête officiel.
   */
  function enteteAdministratif(ecole, contexte) {
    contexte = contexte || {};
    return '<div class="entete-admin">'
      + '<img class="entete-armoiries" src="' + ressource('armoiries-benin.png')
      + '" alt="Armoiries de la République du Bénin">'
      + '<div class="entete-admin-centre">'
      + '<strong>RÉPUBLIQUE DU BÉNIN</strong>'
      + '<span>Ministère des Enseignements Maternel et Primaire</span>'
      + (contexte.departement ? '<span>Direction Départementale de ' + echapper(contexte.departement) + '</span>' : '')
      + (contexte.circonscription ? '<span>Circonscription scolaire de '
        + echapper(String(contexte.circonscription).replace(/^CS\s+/i, '')) + '</span>' : '')
      + '<span class="entete-ecole">' + echapper(ecole ? ecole.nom : '') + '</span>'
      + '</div>'
      + '<img class="entete-logo" src="' + ressource('entete-memp.jpg')
      + '" alt="Ministère des Enseignements Maternel et Primaire">'
      + '</div>';
  }

  /* =======================================================================
     Carte d'identité scolaire
     ======================================================================= */

  function ressource(nom) {
    return (global.location && location.href)
      ? new URL('assets/' + nom, location.href).href : 'assets/' + nom;
  }

  /**
   * Carte d'identité scolaire, du CI au CM2 comme en maternelle.
   * Pourtour aux couleurs nationales, armoiries et drapeau en tête, sceau en
   * filigrane, et deux emplacements de signature : l'élève et le directeur.
   */
  function carteScolaire(eleve, ins, ecole, annee, numero, signataire) {
    const initiales = (((eleve.prenoms || ' ')[0] || '') + ((eleve.nom || ' ')[0] || '')).toUpperCase();
    const sceau = ressource('armoiries-benin.png');

    const signature = (personne, mention) => '<div class="carte-signature">'
      + (personne && personne.signature_image
        ? '<img src="' + personne.signature_image + '" alt="Signature">'
        : '<span class="carte-signature-vide"></span>')
      + '<small>' + echapper(mention) + '</small></div>';

    return '<div class="carte-scolaire">'
      + '<div class="carte-interieur">'
      + '<img class="carte-filigrane" src="' + sceau + '" alt="">'

      + '<div class="carte-bandeau">'
      + '<img class="carte-sceau" src="' + sceau + '" alt="Armoiries de la République du Bénin">'
      + '<div class="carte-bandeau-texte">'
      + '<strong>RÉPUBLIQUE DU BÉNIN</strong>'
      + '<span>Ministère des Enseignements Maternel et Primaire</span>'
      + '</div>'
      + '<span class="carte-drapeau" aria-label="Drapeau du Bénin"></span>'
      + '</div>'

      + '<div class="carte-titre">CARTE D’IDENTITÉ SCOLAIRE · ' + echapper(annee) + '</div>'

      + '<div class="carte-corps">'
      + '<div class="carte-photo"><span>' + echapper(initiales) + '</span><small>Photo</small></div>'
      + '<table class="carte-champs"><tbody>'
      + '<tr><td>Nom</td><th>' + echapper((eleve.nom || '').toUpperCase()) + '</th></tr>'
      + '<tr><td>Prénoms</td><th>' + echapper(eleve.prenoms) + '</th></tr>'
      + '<tr><td>Né(e) le</td><th>' + echapper(U.dateCourte(eleve.date_naissance))
      + ' à ' + echapper(eleve.lieu_naissance || '—') + '</th></tr>'
      + '<tr><td>Sexe</td><th>' + (eleve.sexe === 'F' ? 'Féminin' : 'Masculin') + '</th></tr>'
      + '<tr><td>Classe</td><th>' + echapper(ins.niveau) + '</th></tr>'
      + '<tr><td>École</td><th>' + echapper(ecole ? ecole.nom : '—') + '</th></tr>'
      + '<tr><td>Matricule</td><th>' + echapper(eleve.educmaster_matricule || eleve.npi || 'en cours') + '</th></tr>'
      + '</tbody></table>'
      + '<div class="carte-qr">' + qrEleve(eleve, ins, ecole, annee, 68) + '</div>'
      + '</div>'

      + '<div class="carte-signatures">'
      + signature(eleve, 'L’élève')
      + '<div class="carte-cachet">' + cachet(ecole, { taille: 54 }) + '</div>'
      + signature(signataire, 'Le Directeur')
      + '</div>'

      + '<div class="carte-pied"><span>N° ' + echapper(numero) + '</span>'
      + '<span>Valable pour l’année scolaire ' + echapper(annee) + '</span></div>'
      + '</div></div>';
  }

  /* =======================================================================
     Certificat de scolarité — un exemplaire par feuille A4
     ======================================================================= */

  /**
   * Certificat de scolarité, un exemplaire par feuille A4.
   * Il porte les insignes du ministère, le NIP et le matricule EDUCMaster,
   * puis la signature du directeur et le cachet de l'établissement.
   */
  function certificatScolarite(eleve, ins, ecole, annee, numero, contexte, appreciations, signataire) {
    appreciations = appreciations || {};
    const p = v => '<span class="pointilles">' + echapper(v || '') + '</span>';

    return '<div class="certificat">'
      + '<div class="cert-entete">'
      + '<div class="cert-armoiries"><img src="' + ressource('entete-memp.jpg')
      + '" alt="Ministère des Enseignements Maternel et Primaire — République du Bénin"></div>'
      + '<div class="cert-colonnes">'
      + '<div class="cert-gauche">DIRECTION DÉPARTEMENTALE DES<br>ENSEIGNEMENTS MATERNEL ET PRIMAIRE<br>DE '
      + p(contexte.departement) + '</div>'
      + '<div class="cert-droite">CIRCONSCRIPTION SCOLAIRE<br>DE : ' + p(contexte.circonscription)
      + '<div class="cert-etoiles">*-*-*-*-*-*-*-*</div>'
      + 'EM/EPP DE : ' + p(ecole ? ecole.nom : '') + '</div>'
      + '</div></div>'

      + '<h2 class="cert-titre">CERTIFICAT DE SCOLARITÉ</h2>'
      + '<p class="cert-numero">N° ' + p(numero) + '</p>'

      + '<div class="cert-corps">'
      + '<p>L… Direct……. de l’EM/EPP de : ' + p(ecole ? ecole.nom : '') + '</p>'
      + '<p>Certifie que l’élève : ' + p(((eleve.nom || '').toUpperCase() + ' ' + (eleve.prenoms || '')).trim()) + '</p>'
      + '<p>Né(e) le ' + p(U.dateCourte(eleve.date_naissance)) + ' à ' + p(eleve.lieu_naissance) + '</p>'
      + '<p>Commune de : ' + p(eleve.commune_naissance || contexte.commune)
      + ' fils(fille) de ' + p(eleve.nom_pere) + '</p>'
      + '<p>et de ' + p(eleve.nom_mere) + '</p>'
      + '<p>Est effectivement inscrit(e) dans ladite école sous le numéro matricule '
      + p(eleve.matricule_ecole || eleve.npi) + '</p>'
      + '<p>depuis le ' + p(U.dateCourte(ins.date_inscription))
      + ' et y poursuit actuellement ses études en Classe de ' + p(ins.niveau) + '</p>'
      + '<p class="cert-appreciations">Avec les appréciations suivantes :<br>'
      + '— ASSIDUITÉ ' + p(appreciations.assiduite) + '<br>'
      + '— CONDUITE ' + p(appreciations.conduite) + '<br>'
      + '— TRAVAIL ' + p(appreciations.travail) + '</p>'
      + '<table class="cert-identite"><tbody>'
      + '<tr><td>NIP</td><th>' + echapper(eleve.npi || '—') + '</th>'
      + '<td rowspan="2" class="cert-qr">' + qrEleve(eleve, ins, ecole, annee, 70) + '</td></tr>'
      + '<tr><td>MATRICULE EDUCMASTER</td><th>' + echapper(eleve.educmaster_matricule || '—') + '</th></tr>'
      + '</tbody></table>'
      + '<p class="cert-sous-titre">Observations particulières</p>'
      + '<p>' + p(appreciations.observations) + '</p>'
      + '<p>' + p('') + '</p>'
      + '<p class="cert-lieu">' + echapper(contexte.commune || '') + ', le '
      + echapper(U.dateCourte(new Date().toISOString())) + '</p>'
      + '</div>'
      + '<div class="bloc-signature cert-signature">'
      + caseSignature(signataire, 'Le Directeur')
      + '<div class="cachet-case">' + cachet(ecole) + '</div>'
      + '</div>'
      + '</div>';
  }

  /* =======================================================================
     Fiche d'évaluation de l'agent — modèle de la Direction de
     l'Administration et des Finances
     ======================================================================= */

  /* Les onze critères notés, avec leur barème et leur regroupement. */
  const CRITERES_EVALUATION = [
    { groupe: 'Compétence professionnelle', total: 8, criteres: [
      { code: 'realisation', nom: 'Taux de réalisation des attentes assignées à l’agent', bareme: 8 }
    ] },
    { groupe: 'Conscience professionnelle', total: 7, criteres: [
      { code: 'ponctualite', nom: 'Ponctualité', bareme: 2 },
      { code: 'assiduite', nom: 'Assiduité', bareme: 2 },
      { code: 'ethique', nom: 'Éthique professionnelle', bareme: 1.5 },
      { code: 'valeurs', nom: 'Sens des valeurs', bareme: 1.5 }
    ] },
    { groupe: 'Le sens du service public', total: 5, criteres: [
      { code: 'sacrifice', nom: 'Esprit de sacrifice', bareme: 1 },
      { code: 'bien_public', nom: 'Respect du bien public', bareme: 2 },
      { code: 'hierarchie', nom: 'Respect de la hiérarchie', bareme: 2 }
    ] }
  ];

  /** Classe de performance officielle, à partir de la note sur 20. */
  function classePerformance(note) {
    if (note === null || note === undefined) return '—';
    if (note >= 18) return 'Très performant';
    if (note >= 16) return 'Performant';
    if (note >= 14) return 'Assez performant';
    if (note >= 10) return 'Peu performant';
    return 'Non performant';
  }

  function tableauCriteres(notes) {
    notes = notes || {};
    let corps = '';
    CRITERES_EVALUATION.forEach((g, ig) => {
      g.criteres.forEach((c, i) => {
        corps += '<tr>'
          + (i === 0 ? '<td rowspan="' + g.criteres.length + '">' + g.groupe + ' (' + g.total + ')</td>' : '')
          + '<td>' + c.nom + '</td>'
          + '<td class="note-critere">' + (notes[c.code] === undefined || notes[c.code] === null
            ? '……..…' : notes[c.code]) + ' / ' + String(c.bareme).replace('.', ',') + '</td>'
          + (i === 0 ? '<td rowspan="' + g.criteres.length + '" class="note-critere">'
            + (notes['_' + g.groupe] === undefined ? '' : notes['_' + g.groupe]) + ' / ' + g.total + '</td>' : '')
          + (ig === 0 && i === 0 ? '<td rowspan="8" class="note-critere">'
            + echapper(notes._classe || '') + '</td>' : '')
          + '</tr>';
      });
    });
    return '<table class="tableau-criteres"><thead><tr><th></th><th>Critères de performance</th>'
      + '<th>Note par critère</th><th>Total</th><th>Classe de performance</th></tr></thead>'
      + '<tbody>' + corps + '</tbody></table>';
  }

  function ficheEvaluationAgent(agent, evaluation, ecole, contexte) {
    evaluation = evaluation || {};
    const p = v => '<span class="pointilles">' + echapper(v || '') + '</span>';

    return '<div class="fiche-agent">'
      + enteteMEMP(contexte.departement, 'Direction de l’Administration et des Finances')
      + '<h2>FICHE D’ÉVALUATION DE L’AGENT</h2>'
      + '<p class="option"><em>(Agent contractuel de l’État n’ayant pas la qualité '
      + 'de supérieur hiérarchique immédiat)</em></p>'

      + '<h3 class="rubrique">1 — Identification de l’agent</h3>'
      + '<div class="identite-agent">'
      + '<p>Nom et prénom(s) : ' + p(((agent.nom || '').toUpperCase() + ' ' + (agent.prenoms || '')).trim()) + '</p>'
      + '<p>Lieu et date de naissance : ' + p((agent.lieu_naissance || '') + ' , le ' + U.dateCourte(agent.date_naissance)) + '</p>'
      + '<p>Tél : ' + p(agent.telephone) + ' &nbsp; E-mail : ' + p(agent.email) + '</p>'
      + '<p>Situation familiale : ' + p(U.libelle(agent.situation_familiale)) + '</p>'
      + '<p>Situation militaire : ' + p(agent.situation_militaire) + '</p>'
      + '<p>Diplôme de recrutement : ' + p(agent.diplome_recrutement) + '</p>'
      + '<p><strong>NIP : ' + p(agent.nip) + '</strong></p>'
      + '<p>Matricule : ' + p(agent.matricule) + '</p>'
      + '<p>Adresse : ' + p(agent.adresse) + '</p>'
      + '</div>'

      + '<h3 class="rubrique">2 — Situation administrative de l’agent</h3>'
      + '<p>Date de première prise de service : ' + p(U.dateCourte(agent.date_premiere_prise_service)) + '</p>'
      + '<p>Grade actuel : ' + p(agent.grade) + ' Catégorie : ' + p(agent.categorie)
      + ' Échelle : ' + p(agent.echelle) + ' Échelon : ' + p(agent.echelon) + '</p>'
      + '<p>Emploi : ' + p(agent.emploi || U.libelle(agent.fonction)) + '</p>'
      + '<p><em>Référence des actes de carrière :</em></p>'
      + '<p>Contrat initial : ' + p(agent.contrat_initial) + '</p>'
      + '<p>Contrat de travail renouvelé : ' + p(agent.contrat_renouvele) + '</p>'
      + '<p>Contrat à durée indéterminée : ' + p(agent.contrat_indetermine) + '</p>'
      + '<p>Avenant : ' + p(agent.avenant) + '</p>'
      + '<p class="lieu-date">Fait à ' + echapper(contexte.commune || '') + ' , le '
      + echapper(U.dateCourte(new Date().toISOString())) + '</p>'
      + '<div class="bloc-signature fiche-signature">'
      + caseSignature(agent, 'L’agent')
      + '<div class="cachet-case">' + cachet(ecole) + '</div>'
      + '</div>'

      + '<div class="saut-page"></div>'
      + '<h3 class="rubrique">3 — Évaluation</h3>'
      + '<p>Période de référence : ' + p(U.dateCourte(evaluation.periode_debut))
      + ' à ' + p(U.dateCourte(evaluation.periode_fin)) + '</p>'
      + '<p><strong>3.1 — Rappel des objectifs sur la période</strong></p>'
      + '<div class="zone-libre">' + echapper(evaluation.objectifs || '') + '</div>'
      + '<p><strong>3.2 — Résultats de la période</strong></p>'
      + '<div class="zone-libre">' + echapper(evaluation.resultats || '') + '</div>'
      + '<p><strong>3.3 — Contraintes et difficultés</strong></p>'
      + '<div class="zone-libre">' + echapper(evaluation.contraintes || '') + '</div>'
      + '<p><strong>3.4 — Note et appréciation du supérieur hiérarchique</strong></p>'
      + tableauCriteres(evaluation.notes_hierarchique)
      + '<p><strong>3.5 — Note et appréciation du comité de direction</strong></p>'
      + tableauCriteres(evaluation.notes_comite)
      + '<table class="signatures-fiche"><tr>'
      + '<td>Préciser le titre du supérieur hiérarchique<div class="espace-signature"></div>'
      + 'Prénoms et Nom du supérieur hiérarchique</td>'
      + '<td>Préciser le titre du responsable de la structure<div class="espace-signature"></div>'
      + 'Prénoms et Nom du responsable de la structure</td>'
      + '</tr></table>'
      + '</div>';
  }

  /* =======================================================================
     Fiche d'inscription au CEP — modèle officiel de la DDEMP
     ======================================================================= */

  const case_ = coche => '<span class="case-a-cocher">' + (coche ? '×' : '') + '</span>';
  const ligne_ = valeur => '<span class="pointilles' + (valeur ? '' : ' vide') + '">'
    + echapper(valeur || '') + '</span>';

  /**
   * Reprend la mise en page de la fiche transmise par la Direction
   * Départementale : mêmes rubriques, mêmes mentions, même ordre.
   */
  function ficheCEP(eleve, ins, ecole, annee, fiche, cep, contexte, signataire) {
    contexte = contexte || {};
    fiche = fiche || {};
    const session = fiche.session || ('JUIN ' + (new Date().getFullYear() + 1));
    const publique = !ecole || ecole.statut !== 'PRIVEE';

    return '<div class="fiche-cep">'
      + enteteMEMP(contexte.departement)
      + '<h2>FICHE D’INSCRIPTION À L’EXAMEN DU<br>CERTIFICAT D’ÉTUDES PRIMAIRES (CEP)</h2>'
      + '<p class="option">OPTION : CEP + entrée en 6ᵉ '
      + case_(fiche.option_6e !== false) + ' &nbsp;&nbsp; CEP seul ' + case_(fiche.option_6e === false)
      + ' <em>(rayer la mention inutile)</em></p>'
      + '<table class="bandeau-session"><tr>'
      + '<td>SESSION DE : <strong>' + echapper(session) + '</strong></td>'
      + '<td>CENTRE DE : <strong>' + echapper(fiche.centre || '—') + '</strong></td>'
      + '</tr></table>'

      + '<h3 class="rubrique">ÉCOLE DE PROVENANCE</h3>'
      + '<table class="fiche-champs">'
      + '<tr><td>COMMUNE DE</td><th>' + ligne_(contexte.commune) + '</th></tr>'
      + '<tr><td>CIRCONSCRIPTION SCOLAIRE DE</td><th>' + ligne_(contexte.circonscription) + '</th></tr>'
      + '<tr><td>NOM DE L’ÉCOLE</td><th>' + ligne_(ecole ? ecole.nom : '') + '</th></tr>'
      + '<tr><td>STATUT DE L’ÉCOLE</td><th>'
      + case_(publique) + ' Publique &nbsp;&nbsp;&nbsp;' + case_(!publique) + ' Privée</th></tr>'
      + '<tr><td>NOM ET PRÉNOM DU DIRECTEUR OU DE LA DIRECTRICE</td><th>'
      + ligne_(contexte.directeur) + '</th></tr>'
      + '<tr><td>CONTACT TÉLÉPHONIQUE DU DIRECTEUR OU DE LA DIRECTRICE</td><th>'
      + ligne_(contexte.directeurContact) + '</th></tr>'
      + '</table>'

      + '<h3 class="rubrique">CANDIDAT (E)</h3>'
      + '<div class="candidat">'
      + '<table class="fiche-champs">'
      + '<tr><td>NOM <em>(à écrire en lettres capitales)</em></td><th>'
      + ligne_((eleve.nom || '').toUpperCase()) + '</th></tr>'
      + '<tr><td>PRÉNOMS <em>(tous les prénoms sans abréviation, suivant l’ordre et l’orthographe '
      + 'de la pièce d’état civil)</em></td><th>' + ligne_(eleve.prenoms) + '</th></tr>'
      + '<tr><td>SEXE</td><th>' + ligne_(eleve.sexe === 'F' ? 'Féminin' : 'Masculin') + '</th></tr>'
      + '<tr><td>DATE ET LIEU DE NAISSANCE</td><th>'
      + ligne_(U.dateCourte(eleve.date_naissance) + ' à ' + (eleve.lieu_naissance || '')) + '</th></tr>'
      + '<tr><td>NUMÉRO EDUCMASTER</td><th>' + ligne_(eleve.educmaster_matricule) + '</th></tr>'
      + '</table>'
      + '<div class="candidat-visuels">'
      + '<div class="photo-candidat"><small>Photo du candidat</small></div>'
      + qrEleve(eleve, ins, ecole, annee, 78)
      + '</div>'
      + '</div>'

      + '<table class="fiche-champs">'
      + '<tr><td>ÉTABLISSEMENTS CHOISIS <em>(trois établissements par ordre de préférence, '
      + 'sans abréviation)</em></td><th>'
      + '1 - ' + ligne_(fiche.etablissement_1) + '<br>'
      + '2 - ' + ligne_(fiche.etablissement_2) + '<br>'
      + '3 - ' + ligne_(fiche.etablissement_3) + '</th></tr>'
      + '<tr><td>RÉSIDENCE DES PARENTS</td><th>' + ligne_(fiche.residence_parents) + '</th></tr>'
      + '<tr><td>DISPENSE D’ÂGE</td><th>'
      + case_(fiche.dispense_age) + ' Oui &nbsp;&nbsp;&nbsp;' + case_(!fiche.dispense_age) + ' Non</th></tr>'
      + '<tr><td>DISPENSE DE SPORT</td><th>'
      + case_(fiche.dispense_sport) + ' Oui &nbsp;&nbsp;&nbsp;' + case_(!fiche.dispense_sport) + ' Non</th></tr>'
      + (cep && cep.numero_table ? '<tr><td>NUMÉRO DE TABLE</td><th>' + ligne_(cep.numero_table) + '</th></tr>' : '')
      + '</table>'

      + '<p class="certification">Je certifie exacts les renseignements ci-dessus.</p>'
      + '<p class="lieu-date">Fait à ' + echapper(contexte.commune || '') + ' , le '
      + echapper(U.dateCourte(new Date().toISOString())) + '</p>'
      + '<table class="signatures-fiche"><tr>'
      + '<td>NOM, PRÉNOM ET SIGNATURE DU PARENT :<br>' + ligne_(fiche.parent_nom)
      + '<div class="espace-signature"></div></td>'
      + '<td>CONTACT TÉLÉPHONIQUE DU PARENT :<br>' + ligne_(fiche.parent_contact)
      + '<br><em>(degré de parenté : ' + echapper(fiche.degre_parente || '—') + ')</em></td>'
      + '<td>SIGNATURE DU (DE LA) CANDIDAT (E) :'
      + (eleve.signature_image
        ? '<img class="signature-trace" src="' + eleve.signature_image + '" alt="Signature du candidat">'
        : '<div class="espace-signature"></div>') + '</td>'
      + '</tr></table>'

      + '<table class="cadre-ddemp"><tr><th colspan="3">AGENT DE LA DDEMP</th></tr><tr>'
      + '<td>DOSSIER ÉTUDIÉ PAR : ' + ligne_(fiche.dossier_etudie_par) + '</td>'
      + '<td>CODE : ' + ligne_(fiche.code_ddemp) + '</td>'
      + '<td>COLLATIONNÉ PAR : ' + ligne_(fiche.collationne_par) + '</td>'
      + '</tr></table>'

      + '<div class="tres-important"><strong>TRÈS IMPORTANT :</strong>'
      + '<ul>'
      + '<li>Les Directeurs d’écoles doivent remplir les fiches d’inscription conformément aux '
      + 'informations telles qu’inscrites sur les actes de naissance. Ils doivent collationner les '
      + 'différentes listes envoyées par la DDEMP afin que la liste d’inscription porte la bonne '
      + 'graphie des noms et prénoms, date et lieu de naissance, sexe et école de provenance des candidats.</li>'
      + '<li>Les Directeurs doivent s’assurer que sur les listes d’inscription, le nom de leur école '
      + 'est exclusivement porté devant chacun de leurs candidats afin de garantir la fiabilité des '
      + 'statistiques des résultats par école.</li>'
      + '<li>Les Directeurs doivent associer les parents d’élèves aux choix des établissements '
      + 'd’accueil de l’enseignement secondaire en cas de succès.</li>'
      + '</ul></div>'

      + '<p class="lieu-date">Certifié à ' + echapper(contexte.commune || '') + ' , le '
      + echapper(U.dateCourte(new Date().toISOString())) + '</p>'
      + '<div class="bloc-signature fiche-signature">'
      + caseSignature(signataire, 'Le Directeur')
      + '<div class="cachet-case">' + cachet(ecole) + '</div>'
      + '</div>'
      + '</div>';
  }

  /* Feuille de style embarquée dans la fenêtre d'impression. */
  const stylesImpression = `
    @page { size: A4 portrait; margin: 10mm; }
    body { font-family: Georgia, "Times New Roman", serif; margin: 0; color: #17201B; }
    h1 { color: #006B3F; font-size: 20px; margin: 0 0 4px; }
    h2 { color: #006B3F; font-size: 17px; }
    h3 { font-size: 15px; margin-top: 18px; }
    table { border-collapse: collapse; width: 100%; margin: 14px 0; }
    th, td { border: 1px solid #D8E0DB; padding: 6px 9px; text-align: left; font-size: 13px; }
    .pied { margin-top: 10px; border-top: 1px solid #D8E0DB; padding-top: 5px; font-size: 9px; color: #647067; }
    .bloc-signature { display: flex; justify-content: space-between; align-items: flex-end;
      gap: 24px; margin-top: 10px; }
    .signature-case { text-align: center; min-width: 180px; }
    .signature-mention { font-size: 10px; color: #647067; margin-bottom: 2px; }
    .signature-trace { display: block; height: 34px; margin: 0 auto; }
    .signature-vide { height: 62px; border-bottom: 1px solid #647067; }
    .signature-nom { font-size: 10.5px; margin-top: 2px; font-weight: 700; }
    .cachet-case { flex: none; }
    .cachet { transform: rotate(-8deg); opacity: .92; }
    .fiche-signature .cachet, .cert-signature .cachet { width: 72px; height: 72px; }
    .carte-scolaire {
      width: 92mm; padding: 3.6mm; border-radius: 4mm; page-break-inside: avoid;
      font-family: system-ui, "Segoe UI", Roboto, Arial, sans-serif;
      /* Le pourtour reprend le drapeau national : bande verte à gauche,
         jaune en haut à droite, rouge en bas à droite. */
      background:
        linear-gradient(to bottom, #FCD116 0 50%, #E8112D 50% 100%) right / 64% 100% no-repeat,
        #008751;
      box-shadow: 0 1px 3px rgba(0,0,0,.18);
    }
    .carte-interieur { position: relative; overflow: hidden; background: #fff;
      border-radius: 2.6mm; padding: 3mm 3.4mm 2.4mm; }
    .carte-filigrane { position: absolute; left: 50%; top: 58%; width: 40mm;
      transform: translate(-50%, -50%); opacity: .045; pointer-events: none; }
    .carte-bandeau { display: flex; align-items: center; gap: 2mm; }
    .carte-sceau { height: 11mm; flex: none; }
    .carte-bandeau-texte { flex: 1; text-align: center; line-height: 1.25; }
    .carte-bandeau-texte strong { display: block; font-size: 8.5px; letter-spacing: .04em; color: #006B3F; }
    .carte-bandeau-texte span { display: block; font-size: 6.6px; color: #3B453E; }
    .carte-drapeau { width: 12mm; height: 8mm; border-radius: 1px; flex: none;
      border: .3mm solid #D8E0DB;
      background: linear-gradient(to bottom, #FCD116 0 50%, #E8112D 50% 100%) right / 60% 100% no-repeat, #008751; }
    .carte-titre { background: #008751; color: #fff; font-size: 8px; font-weight: 700;
      text-align: center; padding: 1.1mm; border-radius: 1mm; margin: 1.8mm 0 1.6mm;
      letter-spacing: .06em; position: relative; }
    .carte-corps { display: flex; gap: 2.2mm; position: relative; align-items: flex-start; }
    .carte-photo { width: 17mm; height: 22mm; border: .3mm solid #B9C6BE; border-radius: 1mm;
      display: flex; flex-direction: column; align-items: center; justify-content: center;
      background: rgba(245,247,246,.8); flex: none; }
    .carte-photo span { font-size: 15px; font-weight: 700; color: #008751; }
    .carte-photo small { font-size: 5.4px; color: #647067; }
    .carte-champs { margin: 0; flex: 1; }
    .carte-champs td, .carte-champs th { border: 0; border-bottom: .2mm dotted #C9D4CD;
      padding: .5mm 1mm; font-size: 7.4px; text-align: left; }
    .carte-champs td { color: #647067; width: 15mm; }
    .carte-champs th { font-weight: 700; }
    .carte-qr { flex: none; align-self: center; }
    .carte-signatures { display: flex; align-items: flex-end; justify-content: space-between;
      gap: 2mm; margin-top: 1.6mm; position: relative; }
    .carte-signature { flex: 1; text-align: center; }
    .carte-signature img { display: block; height: 8mm; margin: 0 auto; }
    .carte-signature-vide { display: block; height: 8mm; }
    .carte-signature small { display: block; font-size: 5.8px; color: #647067;
      border-top: .2mm solid #647067; padding-top: .4mm; }
    .carte-cachet { flex: none; opacity: .78; }
    .carte-pied { display: flex; justify-content: space-between; font-size: 5.8px;
      color: #647067; margin-top: 1.2mm; border-top: .2mm solid #D8E0DB; padding-top: .8mm;
      position: relative; }
    .entete-admin { display: flex; align-items: center; gap: 12px;
      border-bottom: 2px solid #008751; padding-bottom: 8px; margin-bottom: 12px; }
    .entete-armoiries { height: 46px; flex: none; }
    .entete-logo { height: 40px; flex: none; }
    .entete-admin-centre { flex: 1; text-align: center; line-height: 1.35; }
    .entete-admin-centre strong { display: block; font-size: 11px; letter-spacing: .05em; color: #006B3F; }
    .entete-admin-centre span { display: block; font-size: 9.5px; color: #3B453E; }
    .entete-admin-centre .entete-ecole { font-weight: 700; color: #17201B; margin-top: 2px; }
    .entete-memp { display: flex; justify-content: space-between; align-items: flex-start; gap: 16px; }
    .entete-memp img { height: 46px; }
    .entete-coordonnees { font-size: 8.5px; text-align: right; color: #3B453E; line-height: 1.4; }
    .entete-direction { font-size: 10px; margin-top: 4px; padding-bottom: 4px;
      border-bottom: 2px solid #008751; }
    .fiche-cep { font-size: 9.3px; line-height: 1.3; max-width: 190mm; margin: 0 auto; }
    .fiche-cep h2 { text-align: center; font-size: 12px; letter-spacing: .02em; margin: 6px 0 3px; }
    .fiche-cep table { margin: 3px 0; }
    .fiche-cep th, .fiche-cep td { padding: 1.5px 5px; }
    .fiche-cep .option { text-align: center; font-size: 9.5px; margin: 0 0 4px; }
    .fiche-cep .rubrique { background: #E6F5EE; color: #006B3F; font-size: 9.5px;
      padding: 2px 7px; margin: 5px 0 3px; letter-spacing: .04em; }
    .bandeau-session td { text-align: center; font-size: 11px; }
    .fiche-champs { margin: 6px 0; }
    .fiche-champs td { width: 40%; font-size: 9px; color: #3B453E; vertical-align: top; }
    .fiche-champs th { font-size: 9.5px; font-weight: 400; }
    .fiche-champs em { color: #647067; font-size: 8px; }
    .pointilles { display: inline-block; min-width: 55%; border-bottom: 1px dotted #647067;
      font-weight: 700; padding: 0 2px; }
    .pointilles.vide { min-width: 140px; }
    .signature-mention:empty { display: none; }
    .case-a-cocher { display: inline-block; width: 13px; height: 13px; border: 1px solid #17201B;
      text-align: center; line-height: 12px; font-weight: 700; vertical-align: -2px; }
    .candidat { display: flex; gap: 12px; align-items: flex-start; }
    .candidat .fiche-champs { flex: 1; }
    .candidat-visuels { flex: none; display: flex; flex-direction: column; gap: 6px; align-items: center; }
    .photo-candidat { width: 56px; height: 70px; border: 1px solid #647067;
      display: flex; align-items: flex-end; justify-content: center; padding-bottom: 4px; }
    .photo-candidat small { font-size: 8px; color: #647067; }
    .certification { margin-top: 5px; font-size: 9.5px; }
    .lieu-date { font-size: 9.5px; margin: 3px 0; }
    .signatures-fiche td { font-size: 8.5px; vertical-align: top; width: 33%; }
    .espace-signature { height: 20px; }
    .cadre-ddemp { margin-top: 6px; }
    .cadre-ddemp th { background: #F5F7F6; text-align: center; font-size: 9px; letter-spacing: .05em; }
    .cadre-ddemp td { font-size: 8.5px; }
    .tres-important { margin-top: 4px; font-size: 7.2px; line-height: 1.28; }
    .tres-important ul { margin: 3px 0 0; padding-left: 14px; column-count: 2; column-gap: 14px; }
    .tres-important li { margin-bottom: 2px; text-align: justify; }
    .mention-directeur { text-align: right; font-size: 12px; margin-top: 10px; }
    .pied-qr { display: flex; justify-content: space-between; align-items: center; gap: 20px; }
    .certificat { max-width: 190mm; margin: 0 auto; font-size: 11.5px; line-height: 1.7; }
    .cert-entete { border-bottom: 2px solid #008751; padding-bottom: 8px; }
    .cert-armoiries { text-align: center; }
    .cert-armoiries img { height: 52px; }
    .cert-colonnes { display: flex; justify-content: space-between; gap: 20px;
      font-size: 9.5px; line-height: 1.45; margin-top: 6px; }
    .cert-gauche { flex: 1; }
    .cert-droite { flex: 1; text-align: center; }
    .cert-etoiles { letter-spacing: 1px; margin: 3px 0; }
    .cert-titre { text-align: center; font-size: 16px; letter-spacing: .05em; margin: 10px 0 0; }
    .cert-numero { text-align: right; font-size: 11px; margin-bottom: 6px; }
    .cert-corps p { margin: 0 0 4px; display: flex; flex-wrap: wrap; align-items: baseline; gap: 0 6px; }
    .certificat .cert-corps p.cert-appreciations { margin-top: 6px; display: block; }
    .cert-identite { margin: 6px 0; }
    .cert-identite td, .cert-identite th { font-size: 11px; padding: 4px 8px; }
    .cert-identite td:first-child { width: 34%; color: #3B453E; }
    .cert-qr { width: 84px; text-align: center; vertical-align: middle; }
    .certificat .cert-corps p.cert-sous-titre { text-align: center; font-weight: 700;
      margin-top: 10px; display: block; }
    .certificat .cert-corps p.cert-lieu { text-align: right; margin-top: 8px; display: block; }
    .cert-signature, .fiche-signature { justify-content: flex-end; margin-top: 4px; }
    /* Les valeurs du certificat sont courtes : des tirets plus étroits évitent
       que chaque mention passe à la ligne. */
    .certificat .pointilles { min-width: 26%; flex: 1 1 26%; }
    .fiche-agent h2 { text-align: center; font-size: 15px; margin: 14px 0 4px; }
    .identite-agent p, .fiche-agent p { font-size: 11.5px; margin: 0 0 4px; }
    .tableau-criteres th, .tableau-criteres td { font-size: 10.5px; padding: 5px 7px; }
    .tableau-criteres .note-critere { text-align: center; white-space: nowrap; }
    .zone-libre { border: 1px solid #D8E0DB; min-height: 46px; padding: 6px 8px;
      margin-bottom: 8px; font-size: 11px; white-space: pre-wrap; }
    .mention-droite { text-align: right; font-size: 11px; }
    .saut-page { page-break-after: always; }
    .saut-page:last-child { page-break-after: auto; }
    @media print { .carte-scolaire { break-inside: avoid; } }
  `;

  EG.Docs = { cachet, blocSignature, caseSignature, capturerSignature, carteScolaire, ficheCEP, echapper,
    stylesImpression, qrDocument, qrEleve, adresseVerification, enteteMEMP, enteteAdministratif,
    certificatScolarite, ficheEvaluationAgent, CRITERES_EVALUATION, classePerformance };

})(window);
