# ÉduGestion Pro V5.2

Application de gestion des écoles maternelles et primaires du Bénin, conforme à la
spécification V5.2. Elle s'installe sur téléphone, tablette et ordinateur, et
fonctionne **entièrement sans connexion** : les données sont stockées sur l'appareil
et transmises quand le réseau revient.

---

## 1. Mettre l'application en service

L'application est un site statique : aucun serveur applicatif, aucune base à
installer. Trois façons de la publier, de la plus simple à la plus robuste.

### a) Essai immédiat sur un ordinateur

Depuis le dossier `edugestion-pro` :

```bash
python3 -m http.server 8080
```

Puis ouvrez `http://localhost:8080` dans Chrome, Edge ou Firefox.

> N'ouvrez pas `index.html` par double-clic. Les navigateurs bloquent le stockage
> local sur les adresses `file://` : l'application ne pourrait rien enregistrer.

### b) Mise en ligne (recommandée pour un pilote)

Une seule commande depuis le dossier :

```bash
npx vercel --prod
```

Les configurations Vercel, Netlify et GitHub Pages sont déjà dans le dossier.
Voir **DEPLOIEMENT.md** pour les autres hébergeurs et pour la liste des
vérifications à faire une fois en ligne. HTTPS est indispensable : c'est lui qui
autorise l'installation sur l'appareil et le fonctionnement hors ligne.

Exemple avec Nginx :

```nginx
server {
    listen 443 ssl;
    server_name ecole.exemple.bj;
    root /var/www/edugestion-pro;
    index index.html;
    location / { try_files $uri $uri/ /index.html; }
}
```

### c) Réseau local d'une circonscription

Un petit ordinateur ou un Raspberry Pi dans le bureau du CS suffit à servir
l'application aux écoles qui passent s'y connecter, avec un certificat interne.

## 2. Installer sur les appareils

| Appareil | Marche à suivre |
|---|---|
| **Android** (Chrome) | Ouvrir l'adresse → bandeau « Installer ÉduGestion Pro », ou menu ⋮ → *Ajouter à l'écran d'accueil* |
| **iPhone / iPad** (Safari) | Bouton Partager → *Sur l'écran d'accueil* |
| **Windows / macOS / Linux** (Chrome, Edge) | Icône d'installation dans la barre d'adresse |

Une fois installée, l'application se lance depuis l'écran d'accueil, en plein écran,
sans barre de navigateur, et démarre même en mode avion.

## 3. Comptes de démonstration

Le premier lancement installe un jeu de données complet : circonscription de
Natitingou, trois écoles, 102 élèves, 14 agents, notes, présences, patrimoine,
budget et campagne de recensement.

| Identifiant | Mot de passe | Rôle |
|---|---|---|
| `dir.ep001` | `demo123` | Directeur d'école |
| `ens.cm2` | `demo123` | Enseignant |
| `cs.natitingou` | `demo123` | Circonscription scolaire |
| `ddemp.atacora` | `demo123` | Direction départementale |
| `parent.demo` | `demo123` | Parent d'élève |
| `admin` | `admin123` | Administrateur MEMP |

**Avant tout déploiement réel :** créez vos propres comptes dans
*Plus → Utilisateurs & sécurité*, puis désactivez ceux-ci.

## 4. Ce que contient l'application

Les 26 modules de la spécification sont accessibles et opérationnels. Trente et un
disposent d'un espace de travail dédié ; les 96 tables du modèle de données ont
toutes un écran de consultation, de création, de modification et d'export CSV.

### Les neuf matières du primaire

| N° | Épreuve | Code |
|---|---|---|
| 1 | Dictée | `DICT` |
| 2 | Communication écrite | `COMM_ECR` |
| 3 | Compréhension de l'écrit | `COMP_ECR` |
| 4 | Mathématiques | `MATH` |
| 5 | Éducation sociale | `ESC` |
| 6 | Éducation scientifique et technologique | `EST` |
| 7 | EA Plastique | `EA_PLAST` |
| 8 | EA Vivant | `EA_VIV` |
| 9 | Éducation physique et sportive | `EPS` |

La dictée est une épreuve à part entière, distincte de la communication écrite.
C'est ce total de neuf qui fonde la règle des six maîtrises aux examens blancs —
six sur huit lorsque l'EPS est dispensée. Le référentiel se réaligne au démarrage
sur les appareils déjà installés, sans perdre les notes déjà saisies.

**Espaces de travail dédiés**

- **Élèves** — inscription avec contrôle des doublons avant création, dossier permanent (identité, résultats par matière, assiduité, famille, handicap, risque), transfert et abandon tracés
- **Personnel** — dossier de l'agent : carrière, affectations, diplômes, formations, unités pédagogiques, visites reçues, évaluation annuelle, échéance de retraite
- **Patrimoine** — locaux et leur état, accessibilité, mobilier et places assises, équipements, ressources pédagogiques, services (eau, électricité, latrines)
- **Visites** — conduite d'une visite, observations, recommandations avec échéance et suivi, plans d'amélioration, procès-verbal
- **Gouvernance** — instances (APE, AME, comités), réunions consignées, moyens d'information des familles
- **Présences** — appel de classe en trois touches, repérage des absences répétées
- **Évaluations** — grille de notes par matière, moyennes et maîtrises calculées en direct, validation puis verrouillage
- **Bulletins et décisions** — moyenne pondérée, mention, rang, décision de passage motivée
- **CEP** — examens blancs (règle des 6 maîtrises sur 9, ou 6 sur 8 si l'EPS est dispensée) et résultats officiels
- **Retraite** — prévisions à 1, 3, 5 et 10 ans, campagnes de notification
- **Recensement** — formulaire pré-rempli depuis les données déjà saisies, contrôles de cohérence, transmission
- **Budget** — quatre composantes de ressources, exécution, circuit de validation
- **Cantine** — pointage quotidien, et un écran de contributions qui donne, par élève, ce qui est dû et ce qui est réglé au jour, à la semaine, au mois et à l'année, avec liste de paiement à émarger
- **Registre d'appel** — le calendrier des jours de classe croisé avec la liste alphabétique : sans marque l'élève est compté présent et la case affiche **P** en vert, une touche la passe à **A** en rouge. Les jours chômés sont en rouge et sortent du calcul. Le calendrier de septembre à juin s'engendre en un geste — lundi au vendredi, moins les fêtes civiles et chrétiennes calculées, Pâques et ses dérivées comprises ; les fêtes musulmanes, fixées chaque année par décret, se déclarent depuis l'écran
- **Relevé mensuel de fréquentation** — le registre officiel de septembre à juin : demi-journées de classe, élèves ayant fréquenté, présences possibles, absences, présences effectives, pourcentage, élèves à quatre absences ou moins, élèves au-delà et absences qui leur sont imputables. Les lignes Total et Moyenne se calculent seules, la moyenne ne portant que sur les mois effectivement tenus
- **Bilan de présence** — taux par cours et par mois, puis récapitulatif annuel avec absences justifiées et retards
- **Tableau d'affichage de classe** — courbe des âges filles/garçons contre l'âge théorique du cours, courbe d'assiduité mensuelle, courbe de la moyenne de classe évaluation après évaluation ; à imprimer et à afficher
- **Risques** — score explicable de 0 à 100, ouverture d'accompagnements
- **Alertes** — détection automatique sur six familles de situations
- **EDUCMaster** — matricules, analyse du fichier à la recherche de doublons, fusion de dossiers, arbitrage des conflits
- **Clôture d'année** — contrôles, calcul des décisions, création de l'année suivante, préinscriptions, bascule
- **Calendrier scolaire** — jours ouvrables, fermetures motivées
- **Synthèse officielle de l'évaluation** — le document qui remonte à la circonscription et à la DDEMP : en-tête d'identification complet (zone pédagogique, unité pédagogique, école, CS, DDEMP, année, directeur, CCS, titulaires, type d'évaluation, nombre de classes), tableau par matière avec inscrits et composants par sexe, maîtrise partielle, maîtrise minimale, taux de réussite et élèves à renforcer, ligne « Ensemble », participation et réussite au seuil par sexe, puis les quatre sections — analyse quantitative par cours, analyse qualitative avec appréciations, analyse des écarts de genre, conclusion — chacune accompagnée de son commentaire rédigé à partir des chiffres. Se calcule à la classe, à l'école ou à l'unité pédagogique
- **Panneau de pilotage des évaluations** — vue d'exploration qui agrège de la classe au national, en passant par le cours, l'école, la zone pédagogique, la circonscription et le département : analyse quantitative (inscrits, composants, absents, maîtrise minimale et partielle, réussite, moyenne, écart-type), analyse qualitative avec appréciation et suite à donner, écarts entre filles et garçons, épreuves fortes et faibles
- **Examen blanc en centre** — plusieurs écoles composent ensemble : les neuf épreuves, le total, la moyenne, le nombre de maîtrises et un rang calculé à l'échelle du centre, avec relevé de centre et export Excel
- **Présence du personnel** — pointage quotidien sur sept positions (présent, absent, retard, mission, congé, formation, maladie), relevé mensuel et bilan annuel
- **Attribution des classes** — chaque classe reçoit un titulaire ; l'écran signale les classes sans titulaire et les enseignants sur deux classes
- **Statistiques**, **Rapports**, **Portail parents**, **Synchronisation**

**Pièces officielles**

Chaque édition porte un numéro, une empreinte, un **code QR de vérification**, le
cachet de l'établissement dessiné à partir de ses données, et la signature du
responsable si celui-ci l'a enregistrée (*Mon compte → Ma signature*, tracée au
doigt ou à la souris).

- **Fiche d'inscription au CEP** — une feuille A4 par candidat, aux insignes du
  ministère, reprise du modèle transmis par la Direction Départementale : en-tête du ministère, session et centre, école de provenance,
  identité du candidat, trois établissements choisis, dispenses d'âge et de sport,
  engagement du parent, cadre réservé à l'agent de la DDEMP et les trois mentions
  « TRÈS IMPORTANT ». La signature du candidat et celle du directeur y sont
  apposées automatiquement, chacune une seule fois, à l'emplacement prévu par le
  modèle. Les renseignements propres au candidat se saisissent dans l'application
  et sont conservés d'une édition à l'autre.
- **Carte d'identité scolaire** — **recto et verso**. Le verso porte la photo de l'école, son nom, sa localisation dans le territoire — DDEMP, circonscription, commune, arrondissement, village ou quartier — et la mention de propriété avec la conduite à tenir en cas de perte, contacts de l'école compris. Tout s'y remplit depuis la fiche de l'établissement. Sur une planche de classe, les rectos s'impriment d'abord, puis les versos dans le même ordre. Le recto garde son pourtour aux couleurs du drapeau national,
  armoiries de la République en tête à gauche et drapeau à droite, sceau en
  filigrane, code QR de l'élève, cachet de l'école et deux emplacements de
  signature : l'élève et le directeur. À l'unité depuis le dossier d'un élève, par
  classe, ou pour toute l'école d'un coup — du CI au CM2 comme en maternelle.
- **Certificat de scolarité** — un exemplaire par feuille A4, aux insignes du
  ministère. Filiation, matricule de l'école, appréciations d'assiduité, de conduite
  et de travail, le **NIP** et le matricule EDUCMaster dans le cadre
  d'identification, puis la signature du directeur et le cachet de l'école en pied.
- **Fiche d'évaluation de l'agent** — modèle de la Direction de l'Administration et
  des Finances : identification avec NIP, situation administrative, actes de
  carrière, puis les onze critères notés aux deux niveaux — supérieur hiérarchique
  et comité de direction — avec la classe de performance calculée.
- **Bulletin**, **liste de classe**, **liste de paiement de la cantine**, **bilan de
  présence**, **relevé de centre**, **synthèse d'évaluation**, **répartition des
  classes**, **relevé de présence du personnel**, **tableau d'affichage**,
  **PV de visite**, **fiche de carrière**, **état budgétaire**, **état du patrimoine**.

**Certificats administratifs du personnel**

Sept modèles officiels, dans le compte du directeur (*Personnel → Certificats
administratifs*) : présence au poste, prise de service, reprise de service et
prise de service des AME avec leur cadre de visas, attestation de direction,
certificat de travail, certificat de prise en charge. Matricule, NIP, grade et
dates sont repris du dossier de l'agent ; seules les références d'actes se
saisissent. Chaque pièce porte la ligne « SO N° … / école / CS-… / DDEMP-… / SP »,
la signature du directeur avec son nom en dessous, et le cachet à côté.

**Cachet paramétrable**

*Personnel → Cachet de l'établissement* compose le cachet en trois mentions :
l'arc supérieur, le texte central et l'arc inférieur, les deux arcs séparés par
une étoile. Chaque directeur saisit les siennes et choisit l'encre, bleue ou
rouge, avec un aperçu à l'échelle d'impression.

**Identification des écoles**

La fiche d'un établissement suit le feuillet officiel du MEMP : identification
administrative (type, région pédagogique, année et référence de création,
arrondissement, village ou quartier), environnement et accessibilité (six
distances de référence, accès permanent, inondabilité, électrification, source
d'eau, pollution), domaine et équipements collectifs (titre de propriété,
superficie, clôture, point d'eau, latrines et leur détail, bibliothèque, terrain
de sport, aménagements pour le handicap), structure pédagogique (classes
autorisées et existantes, salles, classes simples, jumelées, multigrades),
langues d'enseignement et instances de gestion (APE, AME, comité de direction,
conseil des maîtres). Une photo de l'école peut y être jointe : elle est
redimensionnée sur l'appareil et ne part jamais sur le réseau.

**Signatures**

Trois personnes peuvent signer. Le **responsable qui édite** enregistre sa signature
dans *Mon compte*. L'**enseignant** le fait depuis son dossier : son nom et sa
signature figurent alors au pied de chaque document de sa classe, à côté de ceux du
directeur, et le pied de page rappelle la classe et son titulaire. L'**élève** signe
depuis son dossier ; sa signature est reportée sur sa fiche d'inscription au CEP.
Toutes sont tracées au doigt ou à la souris et restent sur l'appareil.

Deux codes QR cohabitent. Celui de l'**élève** porte son identité minimale —
matricule, nom, sexe, date de naissance, cours, école, année — et se lit avec
n'importe quel téléphone : il figure sur la carte scolaire et sur la fiche CEP.
Celui du **document** mène à son adresse de vérification et porte son empreinte ;
il est en pied de chaque pièce éditée. Le générateur est conforme à la norme
ISO/IEC 18004 et n'appelle aucune bibliothèque.

Toute pièce administrative éditée part sous les armoiries de la République et le
logo du ministère, avec la direction départementale, la circonscription et le nom
de l'école. Les pièces qui ont leur propre en-tête officiel — fiche CEP,
certificat, fiche d'évaluation de l'agent, carte scolaire — gardent le leur.

Le code QR d'un document ouvre `verification.html`, une page qui interroge la base
de l'appareil et rend l'un de quatre verdicts : *document authentique* quand le
numéro figure au registre et que l'empreinte concorde ; *l'empreinte ne correspond
pas* quand la pièce a été modifiée ou rééditée ; *document introuvable sur cet
appareil* sur le téléphone d'un parent, qui ne détient pas la base — avec les
références à présenter à l'école ; et un message clair si le stockage est
inaccessible. La page ne consulte aucun serveur et ne transmet rien.

Le cachet identifie l'émetteur ; il ne remplace pas un sceau humide. L'authenticité
se vérifie par le numéro, l'empreinte et le code QR, tous enregistrés avec la
signature dans la table des signatures de documents.

**Notes sous Excel**

Depuis l'écran des évaluations : *Télécharger en Excel* produit un vrai fichier
`.xlsx` — une feuille de notes avec une colonne par matière et l'identifiant de
chaque élève, plus une feuille rappelant les codes et coefficients. L'enseignant le
remplit hors ligne, puis *Importer depuis Excel* replace les notes dans la grille,
où il les vérifie avant d'enregistrer. Les valeurs hors de 0–20 et les lignes sans
correspondance sont signalées et écartées. Le `.csv` est accepté aussi. Lecture et
écriture se font sur l'appareil, sans aucune bibliothèque externe.

**Règles métier appliquées**

| Règle | Mise en œuvre |
|---|---|
| Passage automatique | EM1, EM2, Petits, Moyens, Grands |
| Moyenne ≥ 10/20 | CI, CE1, CM1 |
| 2/3 de maîtrises | CP, CE2, CM2 |
| CEP officiel admis | **Prioritaire** : sortie du primaire, quelle que soit la décision pédagogique |
| Perfectionnement | 10–14 : +1 pt · 15–17 : +1,5 pt · 18–20 : +2 pts |
| Retraite | C1 : 55 ans · B1 : 58 ans · A1, A2, A3 : 60 ans, échelons 1 à 15 |

Les règles sont regroupées dans `js/rules.js` : une seule source de vérité,
versionnée (`MEMP-2026.1`), modifiable sans toucher au reste de l'application.

## 5. Fonctionnement hors ligne

Chaque écriture est enregistrée dans la base locale de l'appareil (IndexedDB) et
déposée dans une file d'attente avec une clé d'idempotence. L'indicateur en haut à
droite affiche en permanence l'état : *À jour*, *N en attente*, ou *Hors ligne*.

L'écran **Synchronisation** permet de transmettre la file, de sauvegarder toutes les
données dans un fichier JSON, et de restaurer une sauvegarde — utile pour transférer
un poste ou remonter les données d'une école sans réseau par clé USB.

## 6. Brancher le serveur national

L'application est prête à parler à l'API décrite dans la spécification. Deux points
d'entrée à modifier :

- `js/db.js` — la fonction `outboxClear` est le point où la file d'attente doit être
  envoyée à `POST /sync/push` avant d'être vidée ;
- `js/app.js` — l'authentification locale se remplace par `POST /auth/login` avec les
  jetons d'accès (15 min) et de rafraîchissement (30 j).

Le modèle local reprend exactement les noms de tables et de champs PostgreSQL de la
spécification : la correspondance avec le serveur est directe, sans traduction. Le
statut EDUCMaster est déjà porté par chaque élève, et les élèves sans matricule sont
listés dans l'écran Synchronisation.

## 7. Organisation des fichiers

```
edugestion-pro/
├── index.html              page d'entrée
├── verification.html       vérification publique d'un document
├── manifest.webmanifest    installation sur l'appareil
├── sw.js                   fonctionnement hors ligne
├── css/app.css             design system
├── assets/                 en-tête officiel du ministère
├── icons/                  icônes d'application
└── js/
    ├── schema.js           96 entités, 26 modules
    ├── db.js               base locale, file d'attente, audit
    ├── rules.js            règles métier officielles
    ├── seed.js             référentiels et données de démonstration
    ├── ui.js               composants, routeur, formulaires
    ├── screens.js          tableau de bord, scolarité, pilotage
    ├── screens2.js         élèves, personnel, patrimoine, visites, gouvernance
    ├── screens3.js         EDUCMaster, clôture d'année, calendrier
    ├── screens4.js         fiches CEP, cantine payante, bilans, affichage
    ├── screens5.js         synthèses, centre d'examen, présence du personnel
    ├── screens6.js         certificats du personnel, cachet de l'établissement
    ├── screens7.js         relevé mensuel de fréquentation
    ├── screens8.js         registre d'appel et calendrier engendré
    ├── screens9.js         synthèse officielle de l'évaluation
    ├── tableur.js          lecture et écriture des classeurs .xlsx et .csv
    ├── qr.js               générateur de codes QR (ISO/IEC 18004)
    ├── docs-socle.js       cachet, codes QR, signatures, en-têtes
    ├── docs-modeles.js     carte scolaire, certificat, fiche CEP, fiche agent
    ├── docs-styles.js      feuille de style des pièces imprimées
    └── app.js              session, droits, navigation
```

## 8. Sécurité — état actuel

Ce qui est en place : rôles et périmètres (un directeur ne voit que son école), un
journal d'audit alimenté à chaque action sensible, le verrouillage des évaluations,
budgets, résultats CEP et fiches de recensement, et l'empreinte de chaque document
édité.

Ce qui relève du serveur, à la mise en réseau : le chiffrement des données au repos,
le Row-Level Security PostgreSQL, l'authentification à double facteur pour les rôles
sensibles, et la révocation des sessions. Tant que l'application tourne seule sur un
appareil, protégez l'appareil lui-même par un code de verrouillage.

## 9. Contrôle des doublons d'élèves

À chaque inscription, l'application compare le nom, les prénoms, la date de
naissance et le sexe avec tous les dossiers existants. Au-delà de 60 % de
ressemblance, elle affiche les dossiers proches avant de créer quoi que ce soit :
l'agent choisit alors de **réinscrire** l'élève existant — son historique reste
intact jusqu'au CEP — ou de confirmer qu'il s'agit bien d'un autre enfant. C'est le
point où se jouent la plupart des doublons dans un fichier national.

## 10. Le cycle d'une année scolaire

L'application accompagne l'année du début à la fin, et la boucle est fermée :

1. **Rentrée** — inscriptions, avec contrôle des doublons ; ou confirmation en bloc
   des élèves attendus d'après les décisions de l'année précédente.
2. **En cours d'année** — appel, notes des neuf évaluations, cantine, visites,
   recensement, budget.
3. **Fin d'année** — l'écran *Clôture* vérifie que les évaluations sont verrouillées,
   que chaque élève a une décision et que les résultats du CEP sont officiels.
4. **Décisions** — calculées d'un coup pour toute l'école, selon les règles du
   niveau, le CEP officiel primant sur tout le reste.
5. **Année suivante** — création de l'année, reprise des classes, puis génération
   des préinscriptions : passage au niveau supérieur, redoublement au même niveau,
   et sortie du primaire pour les admis au CEP.
6. **Bascule** — la clôture fige l'année, ouvre la suivante et fait basculer
   l'application dessus. Les préinscriptions attendent alors leur confirmation
   dans l'écran *Élèves*.

## 11. Réinitialiser un appareil

*Synchronisation → Réinitialiser l'appareil* efface toutes les données locales et
réinstalle le jeu de démonstration. Sauvegardez avant si les données comptent.
